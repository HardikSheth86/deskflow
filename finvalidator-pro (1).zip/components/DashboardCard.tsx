
import React, { ReactNode } from 'react';

interface DashboardCardProps {
  title: string;
  children: ReactNode;
  className?: string;
  actions?: ReactNode;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, children, className = '', actions }) => {
  return (
    <div className={`bg-white shadow-lg rounded-xl p-6 ${className}`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-slate-700">{title}</h3>
        {actions && <div className="flex space-x-2">{actions}</div>}
      </div>
      <div>{children}</div>
    </div>
  );
};

export default DashboardCard;
