import React, { useState, useEffect } from 'react';
import { SignOffProductLine, SignOffStrategy, ProcessStatus, ActivityLogItem } from '../types';
import Modal from './Modal';
import Tabs, { TabItem } from './Tabs'; 
import { 
    CheckCircleIcon, XCircleIcon, InformationCircleIcon, 
    CalculatorIcon, ListBulletIcon, PencilIcon, BranchIcon, EyeIcon
} from './icons';

// Helper function to format currency
const formatCurrency = (value: number, currency: string, showSign: boolean = false) => {
  const sign = value >= 0 && showSign ? '+' : '';
  return sign + new Intl.NumberFormat('en-US', { style: 'currency', currency: currency, minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
};

// Helper function to calculate Day-over-Day change
const calculateDoDChange = (current: number, previous: number) => {
  if (previous === 0) return { amount: current, percentage: current !== 0 ? 100 : 0, isPositive: current >= 0 };
  const amountChange = current - previous;
  const percentageChange = (amountChange / Math.abs(previous)) * 100;
  return { amount: amountChange, percentage: parseFloat(percentageChange.toFixed(2)), isPositive: amountChange >= 0 };
};

interface FinancialMetricDisplayProps {
  label: string;
  sodValue: number;
  eodValue: number;
  currency: string;
  isPnL?: boolean;
}

const FinancialMetricDisplay: React.FC<FinancialMetricDisplayProps> = ({ label, sodValue, eodValue, currency, isPnL = false }) => {
  const dodChange = calculateDoDChange(eodValue, sodValue);
  const varianceColor = dodChange.isPositive ? (isPnL ? 'text-green-600' : 'text-green-600') : 'text-red-600';

  return (
    <div className="py-2">
      <h5 className="text-sm font-semibold text-slate-700 mb-1">{label}</h5>
      <div className="grid grid-cols-3 gap-x-2 text-xs">
        <div><span className="text-slate-500 block">SOD:</span>{formatCurrency(sodValue, currency)}</div>
        <div><span className="text-slate-500 block">EOD:</span>{formatCurrency(eodValue, currency)}</div>
        <div className={varianceColor}><span className="text-slate-500 block">Variance:</span>{formatCurrency(dodChange.amount, currency, true)}<span className="block">({dodChange.percentage}%)</span></div>
      </div>
    </div>
  );
};

interface BreakdownItemProps {
    label: string;
    value: number;
    currency: string;
}

const BreakdownItem: React.FC<BreakdownItemProps> = ({label, value, currency}) => {
    const valueColor = value >= 0 ? 'text-green-700' : 'text-red-700';
    return (
        <div className="flex justify-between py-1 text-xs">
            <span className="text-slate-600">{label}:</span>
            <span className={`font-medium ${valueColor}`}>{formatCurrency(value, currency, true)}</span>
        </div>
    );
};

interface SignOffDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: SignOffProductLine | SignOffStrategy | null;
  level: 'ProductLine' | 'Strategy';
  onSignOffAction: (itemId: string, level: 'ProductLine' | 'Strategy', attestation: string, comments: string, approved: boolean) => void;
  onOpenStrategyModal: (strategy: SignOffStrategy) => void;
}

const SignOffDetailModal: React.FC<SignOffDetailModalProps> = ({ 
    isOpen, onClose, item, level, onSignOffAction, onOpenStrategyModal 
}) => {
  const [attestationChecked, setAttestationChecked] = useState(false);
  const [comments, setComments] = useState('');
  const [initialTabIndex, setInitialTabIndex] = useState(0);

  useEffect(() => {
    if (isOpen && item) { // ensure item is not null when modal is open
      setAttestationChecked(false);
      setComments('');
      
      if (level === 'ProductLine') {
        const productLine = item as SignOffProductLine;
        if (productLine.status === ProcessStatus.AWAITING_SIGN_OFF) {
          setInitialTabIndex(2); // Product Line Attestation
        } else if (productLine.status === ProcessStatus.IN_PROGRESS) {
          setInitialTabIndex(1); // Strategies Status
        } else {
          setInitialTabIndex(0); // Product Line Summary (for SIGNED_OFF or REJECTED)
        }
      } else {
        setInitialTabIndex(0); // Default to first tab (Summary) for Strategy level
      }
    }
  }, [item, level, isOpen]);

  if (!item) return null;

  const handleSubmitAttestation = (approved: boolean) => {
    if (!attestationChecked) {
      alert('Please check the attestation box to confirm your review.');
      return;
    }
    if (!approved && comments.trim() === '') {
        alert('Comments are required for rejection.');
        return;
    }
    onSignOffAction(item.id, level, "User has reviewed the data and confirms its accuracy.", comments, approved);
  };
  
  const getStatusColorPill = (status: ProcessStatus) => {
    switch (status) {
      case ProcessStatus.SIGNED_OFF: return 'bg-green-100 text-green-700';
      case ProcessStatus.AWAITING_SIGN_OFF: return 'bg-yellow-100 text-yellow-700';
      case ProcessStatus.IN_PROGRESS: return 'bg-sky-100 text-sky-700';
      case ProcessStatus.REJECTED: return 'bg-red-100 text-red-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const currentItem = item; 

  const summaryTabContent = (
    <div className="space-y-4 text-sm">
        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
          <h4 className="font-semibold text-slate-700 mb-1">Current Status: 
            <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColorPill(currentItem.status)}`}>
              {currentItem.status}
            </span>
          </h4>
          <p className="text-xs text-slate-500">Last Updated: {new Date(currentItem.lastUpdated).toLocaleString()}</p>
        </div>
         <div className="bg-slate-50 p-3 rounded-md border border-slate-200 divide-y divide-slate-200">
            <FinancialMetricDisplay 
              label="Net P&L" 
              sodValue={currentItem.previousNetPnL} 
              eodValue={currentItem.currentNetPnL} 
              currency={currentItem.currency}
              isPnL={true} 
            />
            <FinancialMetricDisplay 
              label="Total Assets" 
              sodValue={currentItem.previousTotalAssets} 
              eodValue={currentItem.currentTotalAssets} 
              currency={currentItem.currency} 
            />
            <FinancialMetricDisplay 
              label="Total Liabilities" 
              sodValue={currentItem.previousTotalLiabilities} 
              eodValue={currentItem.currentTotalLiabilities} 
              currency={currentItem.currency} 
            />
        </div>
    </div>
  );

  const breakdownTabContent = level === 'Strategy' && currentItem && 'pnlTrading' in currentItem ? (
     <div className="space-y-3 text-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
              <h5 className="font-medium text-slate-600 mb-1 text-xs">P&L Breakdown</h5>
              <BreakdownItem label="Trading P&L" value={(currentItem as SignOffStrategy).pnlTrading} currency={currentItem.currency} />
              <BreakdownItem label="FX Revaluation P&L" value={(currentItem as SignOffStrategy).pnlFxReval} currency={currentItem.currency} />
              <BreakdownItem label="Adjustments & Fees P&L" value={(currentItem as SignOffStrategy).pnlAdjustments} currency={currentItem.currency} />
              <hr className="my-1 border-slate-300"/>
              <BreakdownItem label="Total P&L Change" value={currentItem.currentNetPnL - currentItem.previousNetPnL} currency={currentItem.currency} />
            </div>
            <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
              <h5 className="font-medium text-slate-600 mb-1 text-xs">Asset Movement</h5>
              <BreakdownItem label="Trading Activity" value={(currentItem as SignOffStrategy).assetChangeTrading} currency={currentItem.currency} />
              <BreakdownItem label="FX Revaluation" value={(currentItem as SignOffStrategy).assetChangeFxReval} currency={currentItem.currency} />
              <BreakdownItem label="Adjustments & Other" value={(currentItem as SignOffStrategy).assetChangeAdjustments} currency={currentItem.currency} />
               <hr className="my-1 border-slate-300"/>
              <BreakdownItem label="Total Asset Change" value={currentItem.currentTotalAssets - currentItem.previousTotalAssets} currency={currentItem.currency} />
            </div>
            <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
              <h5 className="font-medium text-slate-600 mb-1 text-xs">Liability Movement</h5>
              <BreakdownItem label="Trading & Settlements" value={(currentItem as SignOffStrategy).liabilityChangeTrading} currency={currentItem.currency} />
              <BreakdownItem label="FX Revaluation" value={(currentItem as SignOffStrategy).liabilityChangeFxReval} currency={currentItem.currency} />
              <BreakdownItem label="Adjustments & Other" value={(currentItem as SignOffStrategy).liabilityChangeAdjustments} currency={currentItem.currency} />
               <hr className="my-1 border-slate-300"/>
              <BreakdownItem label="Total Liability Change" value={currentItem.currentTotalLiabilities - currentItem.previousTotalLiabilities} currency={currentItem.currency} />
            </div>
          </div>
     </div>
  ) : <p className="text-slate-500 text-sm">Detailed financial breakdown is available at the Strategy level.</p>;

  const activityLog = level === 'Strategy' && currentItem && 'activityLog' in currentItem ? (currentItem as SignOffStrategy).activityLog : [];
  const activityLogTabContent = level === 'Strategy' ? (
    <div className="text-sm">
      {activityLog && activityLog.length > 0 ? (
        <div className="bg-slate-50 p-1 rounded-md border border-slate-200 max-h-96 overflow-y-auto">
          <table className="min-w-full text-xs">
            <thead className="sticky top-0 bg-slate-100 z-10">
              <tr>
                <th className="px-2 py-1.5 text-left font-medium text-slate-600">Time</th>
                <th className="px-2 py-1.5 text-left font-medium text-slate-600">Type</th>
                <th className="px-2 py-1.5 text-left font-medium text-slate-600">Description</th>
                <th className="px-2 py-1.5 text-left font-medium text-slate-600 hidden sm:table-cell">User</th>
                <th className="px-2 py-1.5 text-right font-medium text-slate-600 hidden md:table-cell">Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {activityLog.map((log) => (
                <tr key={log.id} className="hover:bg-slate-100">
                  <td className="px-2 py-1 whitespace-nowrap">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="px-2 py-1 whitespace-nowrap">
                    <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${
                        log.type === 'Trade' ? 'bg-blue-100 text-blue-700' :
                        log.type === 'Adjustment' ? 'bg-yellow-100 text-yellow-700' :
                        log.type === 'FX Reval' ? 'bg-purple-100 text-purple-700' :
                        log.type === 'Fee' ? 'bg-orange-100 text-orange-700' :
                        log.type === 'Commentary' ? 'bg-teal-100 text-teal-700' :
                        'bg-slate-200 text-slate-700'
                    }`}>{log.type}</span>
                  </td>
                  <td className="px-2 py-1">{log.description}</td>
                  <td className="px-2 py-1 whitespace-nowrap hidden sm:table-cell">{log.user || 'System'}</td>
                  <td className="px-2 py-1 whitespace-nowrap text-right hidden md:table-cell">
                    {log.financialImpact && formatCurrency(log.financialImpact.amount, log.financialImpact.currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-slate-500 text-center py-4 bg-slate-50 rounded-md border border-slate-200">No activity log entries found.</p>
      )}
    </div>
  ) : <p className="text-slate-500 text-sm">Detailed activity log is available at the Strategy level.</p>;

  const strategies = level === 'ProductLine' && currentItem && 'strategies' in currentItem ? (currentItem as SignOffProductLine).strategies : [];
  const strategiesTabContent = level === 'ProductLine' ? (
    <div className="space-y-3">
        {strategies.map(strategy => (
            <div key={strategy.id} className="p-3 border border-slate-200 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-center">
                    <div>
                        <h5 className="font-semibold text-slate-800">{strategy.name}</h5>
                        <p className="text-xs text-slate-500">
                            Status: <span className={`font-medium ${getStatusColorPill(strategy.status)} px-1.5 py-0.5 rounded-full`}>{strategy.status}</span> | 
                            P&L: {formatCurrency(strategy.currentNetPnL, strategy.currency)}
                        </p>
                    </div>
                    <button 
                        onClick={() => onOpenStrategyModal(strategy)}
                        className="px-3 py-1 bg-sky-500 text-white rounded-md hover:bg-sky-600 text-xs font-medium flex items-center"
                    >
                       <EyeIcon className="w-4 h-4 mr-1"/> Review Strategy
                    </button>
                </div>
            </div>
        ))}
        {strategies.length === 0 && <p className="text-slate-500 text-center py-4">No strategies found for this product line.</p>}
    </div>
  ) : null;

  const canProductLineBeSignedOff = level === 'ProductLine' ? strategies.every(s => s.status === ProcessStatus.SIGNED_OFF) : true;
  const isCurrentlySignedOff = currentItem.status === ProcessStatus.SIGNED_OFF;

  const attestationTabContent = (
     <div className="space-y-4 text-sm">
        <div className="bg-slate-50 p-4 rounded-md border border-slate-200 space-y-3">
            <div className="flex items-start">
              <input
                type="checkbox"
                id={`attestation-${currentItem.id}`}
                checked={attestationChecked}
                onChange={(e) => setAttestationChecked(e.target.checked)}
                className="mt-1 h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                disabled={isCurrentlySignedOff || (level === 'ProductLine' && !canProductLineBeSignedOff)}
              />
              <label htmlFor={`attestation-${currentItem.id}`} className="ml-2 text-sm text-slate-700">
                I confirm that I have reviewed the financial data for <strong>{currentItem.name}</strong> as of {new Date().toLocaleDateString()} and am satisfied with its accuracy based on the information available.
              </label>
            </div>
            <div>
              <label htmlFor={`comments-${currentItem.id}`} className="block text-sm font-medium text-slate-700 mb-1">
                Additional Comments (optional for approval, required for rejection):
              </label>
              <textarea
                id={`comments-${currentItem.id}`}
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={2}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
                placeholder="Enter any comments regarding this sign-off..."
                disabled={isCurrentlySignedOff}
              />
            </div>
            {level === 'ProductLine' && !canProductLineBeSignedOff && !isCurrentlySignedOff && (
                <p className="text-xs text-red-600 font-medium">Product Line cannot be signed off until all its strategies are signed off.</p>
            )}
        </div>
        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4">
          <button
            onClick={() => handleSubmitAttestation(true)}
            disabled={!attestationChecked || isCurrentlySignedOff || (level === 'ProductLine' && !canProductLineBeSignedOff)}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center disabled:opacity-50"
          >
            <CheckCircleIcon className="w-5 h-5 mr-2" /> Approve Sign-Off
          </button>
          <button
            onClick={() => handleSubmitAttestation(false)}
            disabled={!attestationChecked || isCurrentlySignedOff}
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors text-sm font-medium flex items-center justify-center disabled:opacity-50"
          >
            <XCircleIcon className="w-5 h-5 mr-2" /> Reject Sign-Off
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium"
          >
            Cancel
          </button>
        </div>
     </div>
  );

  let TABS: TabItem[] = [];
  if (level === 'ProductLine') {
      TABS = [
          { label: "Product Line Summary", content: summaryTabContent, icon: InformationCircleIcon }, 
          { label: "Strategies Status", content: strategiesTabContent, icon: BranchIcon },        
          { label: "Product Line Attestation", content: attestationTabContent, icon: PencilIcon }, 
      ];
  } else if (level === 'Strategy') {
      TABS = [
          { label: "Strategy Summary", content: summaryTabContent, icon: InformationCircleIcon },
          { label: "Financial Breakdown", content: breakdownTabContent, icon: CalculatorIcon },
          { label: "Activity Log", content: activityLogTabContent, icon: ListBulletIcon },
          { label: "Strategy Attestation", content: attestationTabContent, icon: PencilIcon },
      ];
  }
  
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`${level} Review: ${currentItem.name}`} size="xl">
      <Tabs tabs={TABS} initialActiveTabIndex={initialTabIndex} />
    </Modal>
  );
};

export default SignOffDetailModal;