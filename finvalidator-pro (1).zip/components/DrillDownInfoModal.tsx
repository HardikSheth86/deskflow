import React from 'react';
import Modal from './Modal';
import { DrillDownContentType, PositionDrillDownInfo, TradeDrillDownInfo } from '../types';
import { CurrencyDollarIcon, TableCellsIcon } from './icons';

interface DrillDownInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  content: DrillDownContentType | null;
}

const RenderPositionDetails: React.FC<{ data: PositionDrillDownInfo }> = ({ data }) => (
  <div className="space-y-2">
    <div className="flex items-center text-lg font-semibold text-sky-700 mb-2">
        <CurrencyDollarIcon className="w-6 h-6 mr-2" /> Position Attributes
    </div>
    <ul className="divide-y divide-slate-200">
      {(Object.keys(data) as Array<keyof PositionDrillDownInfo>).map((key) => (
        <li key={key} className="py-2 flex justify-between">
          <span className="font-medium text-slate-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
          <span className="text-slate-800">{data[key]}</span>
        </li>
      ))}
    </ul>
  </div>
);

const RenderTradeDetails: React.FC<{ data: TradeDrillDownInfo[] }> = ({ data }) => (
  <div className="space-y-2">
    <div className="flex items-center text-lg font-semibold text-sky-700 mb-2">
        <TableCellsIcon className="w-6 h-6 mr-2" /> Associated Trades
    </div>
    {data.length > 0 ? (
      <div className="overflow-x-auto rounded-md border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200 text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-3 py-2 text-left font-medium text-slate-600">Trade ID</th>
              <th className="px-3 py-2 text-left font-medium text-slate-600">Timestamp</th>
              <th className="px-3 py-2 text-left font-medium text-slate-600">Qty</th>
              <th className="px-3 py-2 text-left font-medium text-slate-600">Price</th>
              <th className="px-3 py-2 text-left font-medium text-slate-600">Direction</th>
              <th className="px-3 py-2 text-left font-medium text-slate-600 hidden md:table-cell">Counterparty</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-100">
            {data.map((trade) => (
              <tr key={trade.tradeId}>
                <td className="px-3 py-2 whitespace-nowrap text-sky-600">{trade.tradeId}</td>
                <td className="px-3 py-2 whitespace-nowrap">{new Date(trade.timestamp).toLocaleString()}</td>
                <td className="px-3 py-2 whitespace-nowrap">{trade.quantity.toLocaleString()}</td>
                <td className="px-3 py-2 whitespace-nowrap">{trade.price.toLocaleString(undefined, {style:'currency', currency: trade.currency})}</td>
                <td className={`px-3 py-2 whitespace-nowrap font-medium ${trade.direction === 'Buy' ? 'text-green-600' : 'text-red-600'}`}>{trade.direction}</td>
                <td className="px-3 py-2 whitespace-nowrap hidden md:table-cell">{trade.counterparty}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    ) : (
      <p className="text-slate-500 text-center py-4">No associated trades found for this exception.</p>
    )}
  </div>
);

const DrillDownInfoModal: React.FC<DrillDownInfoModalProps> = ({ isOpen, onClose, title, content }) => {
  if (!isOpen || !content) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="xl">
      <div className="text-sm">
        {content.type === 'position' && <RenderPositionDetails data={content.data} />}
        {content.type === 'trades' && <RenderTradeDetails data={content.data} />}
      </div>
       <div className="mt-6 flex justify-end space-x-3 border-t pt-4">
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-slate-600 text-white rounded-md hover:bg-slate-700 transition-colors text-sm font-medium"
          >
            Close
          </button>
        </div>
    </Modal>
  );
};

export default DrillDownInfoModal;