
import React from 'react';
import { NavLink } from 'react-router-dom';
import { NavItemType, BusinessArea } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import { ALL_BUSINESS_AREAS } from '../constants';
import { DashboardIcon, ExceptionIcon, AdjustmentIcon, SignOffIcon, CommentaryIcon, AnalyticsIcon, CaseManagementIcon, ChevronDownIcon } from './icons';

const navItems: NavItemType[] = [
  { path: '/', name: 'Dashboard', icon: DashboardIcon },
  { path: '/exceptions', name: 'Exceptions', icon: ExceptionIcon },
  { path: '/adjustments', name: 'Adjustments', icon: AdjustmentIcon },
  { path: '/sign-off', name: 'Sign-Off', icon: SignOffIcon },
  { path: '/commentary', name: 'Commentary', icon: CommentaryIcon },
  { path: '/analytics', name: 'Analytics', icon: AnalyticsIcon },
  { path: '/cases', name: 'Case Management', icon: CaseManagementIcon },
];

const TopNav: React.FC = () => {
  const { currentBusinessArea, setCurrentBusinessArea } = useAppContext();

  return (
    <div className="bg-slate-800 text-slate-100 p-3 shadow-lg sticky top-0 z-50 flex items-center justify-between h-16">
      {/* Left Section: App Title and Navigation */}
      <div className="flex items-center space-x-6">
        <div className="text-xl font-semibold text-sky-400">FinValidator Pro</div>
        <nav>
          <ul className="flex items-center space-x-1">
            {navItems.map((item) => (
              <li key={item.name}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-slate-700 transition-colors text-sm ${
                      isActive ? 'bg-sky-600 text-white shadow-md' : 'text-slate-300 hover:text-white'
                    }`
                  }
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Right Section: Business Area Selector and User Info */}
      <div className="flex items-center space-x-4">
        <div className="relative">
          <select
            value={currentBusinessArea}
            onChange={(e) => setCurrentBusinessArea(e.target.value as BusinessArea)}
            className="appearance-none bg-slate-700 border border-slate-600 text-slate-200 py-2 px-3 pr-8 rounded-md leading-tight focus:outline-none focus:bg-slate-600 focus:border-sky-500 hover:border-slate-500 cursor-pointer text-sm"
            aria-label="Select Business Area"
          >
            {ALL_BUSINESS_AREAS.map((area) => (
              <option key={area} value={area} className="bg-slate-700 text-slate-200">
                {area}
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-400">
            <ChevronDownIcon className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-center space-x-2">
           <img src={`https://picsum.photos/seed/${currentBusinessArea}/32/32`} alt="User Avatar" className="w-8 h-8 rounded-full border-2 border-sky-500" />
           <div>
              <p className="text-sm font-medium text-slate-200">Valerie User</p>
              <p className="text-xs text-slate-400">Back Office Analyst</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default TopNav;
