import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { DistributionList } from '../types';
import { UsersIcon, MailIcon, SendIcon as ActualSendIcon } from './icons'; // Renamed SendIcon to avoid conflict

interface SendReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportTitle: string;
  distributionLists: DistributionList[];
  onConfirmSend: (reportTitle: string, selectedListIds: string[], customEmails: string) => void;
}

const SendReportModal: React.FC<SendReportModalProps> = ({
  isOpen,
  onClose,
  reportTitle,
  distributionLists,
  onConfirmSend,
}) => {
  const [selectedListIds, setSelectedListIds] = useState<string[]>([]);
  const [customEmailsInput, setCustomEmailsInput] = useState('');

  useEffect(() => {
    if (isOpen) {
      setSelectedListIds([]);
      setCustomEmailsInput('');
    }
  }, [isOpen]);

  const handleListSelectionChange = (listId: string) => {
    setSelectedListIds(prev =>
      prev.includes(listId) ? prev.filter(id => id !== listId) : [...prev, listId]
    );
  };

  const handleSubmit = () => {
    if (selectedListIds.length === 0 && !customEmailsInput.trim()) {
      alert('Please select at least one distribution list or enter a custom email.');
      return;
    }
    onConfirmSend(reportTitle, selectedListIds, customEmailsInput.trim());
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Send Report: ${reportTitle}`} size="lg">
      <div className="space-y-6 text-sm">
        <div>
          <h4 className="font-semibold text-slate-700 mb-2 flex items-center">
            <UsersIcon className="w-5 h-5 mr-2 text-sky-600" />
            Select Distribution Lists
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto p-2 bg-slate-50 border border-slate-200 rounded-md">
            {distributionLists.map(list => (
              <div key={list.id} className="flex items-center">
                <input
                  type="checkbox"
                  id={`distlist-${list.id}`}
                  checked={selectedListIds.includes(list.id)}
                  onChange={() => handleListSelectionChange(list.id)}
                  className="h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                />
                <label htmlFor={`distlist-${list.id}`} className="ml-2 text-slate-700">
                  {list.name}
                  {list.description && <span className="text-xs text-slate-500 ml-1">({list.description})</span>}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-slate-700 mb-2 flex items-center">
            <MailIcon className="w-5 h-5 mr-2 text-sky-600" />
            Or Enter Custom Emails
          </h4>
          <textarea
            value={customEmailsInput}
            onChange={(e) => setCustomEmailsInput(e.target.value)}
            rows={3}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
            placeholder="Enter email addresses, separated by commas (e.g., user1@example.com, user2@example.com)"
          />
        </div>

        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 border-t pt-4">
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center justify-center"
          >
            <ActualSendIcon className="w-5 h-5 mr-2" /> Send Report
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium"
          >
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default SendReportModal;
