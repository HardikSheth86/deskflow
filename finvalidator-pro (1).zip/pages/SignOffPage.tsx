
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { MOCK_PRODUCT_LINES_BY_AREA } from '../constants';
import { ProcessStatus, SignOffProductLine, SignOffStrategy, BusinessArea } from '../types';
import SignOffDetailModal from '../components/SignOffDetailModal'; 

// Helper function to format currency
const formatCurrency = (value: number, currency: string) => {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: currency, minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
};

// Helper function to calculate Day-over-Day change
const calculateDoDChange = (current: number, previous: number) => {
  if (previous === 0) {
    return { amount: current, percentage: current !== 0 ? 100 : 0, isPositive: current >= 0 };
  }
  const amountChange = current - previous;
  const percentageChange = (amountChange / Math.abs(previous)) * 100; // Use Math.abs for correct percentage if previous is negative
  return { amount: amountChange, percentage: parseFloat(percentageChange.toFixed(2)), isPositive: amountChange >= 0 };
};

// Helper function to get color for variance
const getVarianceColorText = (isPositive: boolean, isPnL: boolean = false) => {
  if (isPnL) { // For P&L, positive is green, negative is red
    return isPositive ? 'text-green-600' : 'text-red-600';
  }
  return isPositive ? 'text-green-600' : 'text-red-600';
};


const SignOffPage: React.FC = () => {
  const { currentBusinessArea, setCurrentPageTitle } = useAppContext();
  
  // Store the entire mock data and derive displayedProductLines
  const [productLinesByArea, setProductLinesByArea] = 
    useState<Record<BusinessArea, SignOffProductLine[]>>(JSON.parse(JSON.stringify(MOCK_PRODUCT_LINES_BY_AREA)));

  const displayedProductLines = useMemo(() => {
    return productLinesByArea[currentBusinessArea] || [];
  }, [productLinesByArea, currentBusinessArea]);

  const [selectedItem, setSelectedItem] = useState<SignOffProductLine | SignOffStrategy | null>(null);
  const [modalLevel, setModalLevel] = useState<'ProductLine' | 'Strategy' | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  useEffect(() => {
    setCurrentPageTitle('Sign-Off');
  }, [setCurrentPageTitle]);


  const getStatusColorPill = (status: ProcessStatus) => {
    switch (status) {
      case ProcessStatus.SIGNED_OFF: return 'bg-green-100 text-green-700';
      case ProcessStatus.AWAITING_SIGN_OFF: return 'bg-yellow-100 text-yellow-700';
      case ProcessStatus.IN_PROGRESS: return 'bg-sky-100 text-sky-700';
      case ProcessStatus.REJECTED: return 'bg-red-100 text-red-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const handleOpenModal = (item: SignOffProductLine | SignOffStrategy, level: 'ProductLine' | 'Strategy') => {
    setSelectedItem(item);
    setModalLevel(level);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedItem(null);
    setModalLevel(null);
    setIsModalOpen(false);
  };

  const determineParentProductLineStatus = (strategies: SignOffStrategy[]): ProcessStatus => {
    if (strategies.some(s => s.status === ProcessStatus.REJECTED)) return ProcessStatus.REJECTED;
    if (strategies.some(s => s.status === ProcessStatus.IN_PROGRESS)) return ProcessStatus.IN_PROGRESS;
    if (strategies.every(s => s.status === ProcessStatus.SIGNED_OFF)) return ProcessStatus.AWAITING_SIGN_OFF;
    // If some are AWAITING_SIGN_OFF and others are SIGNED_OFF, it's still IN_PROGRESS for the parent until all are SIGNED_OFF
    if (strategies.some(s => s.status === ProcessStatus.AWAITING_SIGN_OFF)) return ProcessStatus.IN_PROGRESS;
    return ProcessStatus.IN_PROGRESS; // Default
  };

  const handleSignOffAction = useCallback((itemId: string, level: 'ProductLine' | 'Strategy', attestation: string, comments: string, approved: boolean) => {
    setProductLinesByArea(prevAreaState => {
      const newAreaState = JSON.parse(JSON.stringify(prevAreaState)); // Deep copy
      const productLinesForCurrentArea: SignOffProductLine[] = newAreaState[currentBusinessArea];

      if (level === 'Strategy') {
        let parentProductLine: SignOffProductLine | undefined;
        for (const pl of productLinesForCurrentArea) {
          const strategyIndex = pl.strategies.findIndex(s => s.id === itemId);
          if (strategyIndex !== -1) {
            pl.strategies[strategyIndex].status = approved ? ProcessStatus.SIGNED_OFF : ProcessStatus.REJECTED;
            pl.strategies[strategyIndex].lastUpdated = new Date().toISOString();
            parentProductLine = pl;
            break;
          }
        }
        if (parentProductLine) {
           // If product line was signed_off but a child strategy gets rejected, PL status should change.
          if (parentProductLine.status === ProcessStatus.SIGNED_OFF && !approved) {
             parentProductLine.status = ProcessStatus.IN_PROGRESS; // or REJECTED based on rules
          } else if (parentProductLine.status !== ProcessStatus.SIGNED_OFF) { // Only update parent if it's not already signed off itself.
            parentProductLine.status = determineParentProductLineStatus(parentProductLine.strategies);
          }
          parentProductLine.lastUpdated = new Date().toISOString();
        }
      } else if (level === 'ProductLine') {
        const productLineIndex = productLinesForCurrentArea.findIndex(pl => pl.id === itemId);
        if (productLineIndex !== -1) {
          // Product line sign-off is only possible if all strategies are signed off.
          // The modal enables this. Here we just set the status.
          productLinesForCurrentArea[productLineIndex].status = approved ? ProcessStatus.SIGNED_OFF : ProcessStatus.REJECTED;
          productLinesForCurrentArea[productLineIndex].lastUpdated = new Date().toISOString();
        }
      }
      return newAreaState;
    });
    
    handleCloseModal();
    alert(`${level} ${itemId} has been ${approved ? 'Approved' : 'Rejected'}. Attestation: ${attestation}. Comments: ${comments}`);
  }, [currentBusinessArea]);


  return (
    <div className="space-y-6">
      <DashboardCard title={`Sign-Off Status for ${currentBusinessArea}`}>
        <p className="text-slate-600 mb-4">
          Review Product Line financial summaries and Day-over-Day movements. Click "Review Product Line" for detailed strategy breakdown and attestation.
        </p>
         {displayedProductLines.length > 0 ? (
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Product Line</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Net P&L</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">P&L DoD</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total Assets</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Assets DoD</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider hidden md:table-cell">Last Updated</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {displayedProductLines.map((pl) => {
                  const pnlDoD = calculateDoDChange(pl.currentNetPnL, pl.previousNetPnL);
                  const assetsDoD = calculateDoDChange(pl.currentTotalAssets, pl.previousTotalAssets);
                  const canSignOffProductLine = pl.strategies.every(s => s.status === ProcessStatus.SIGNED_OFF);

                  return (
                    <tr key={pl.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-slate-800">{pl.name}</td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-600">{formatCurrency(pl.currentNetPnL, pl.currency)}</td>
                      <td className={`px-3 py-3 whitespace-nowrap text-sm font-medium ${getVarianceColorText(pnlDoD.isPositive, true)}`}>
                        {pnlDoD.amount >= 0 ? '+' : ''}{formatCurrency(pnlDoD.amount, pl.currency)} ({pnlDoD.percentage}%)
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-600">{formatCurrency(pl.currentTotalAssets, pl.currency)}</td>
                      <td className={`px-3 py-3 whitespace-nowrap text-sm font-medium ${getVarianceColorText(assetsDoD.isPositive)}`}>
                         {assetsDoD.amount >= 0 ? '+' : ''}{formatCurrency(assetsDoD.amount, pl.currency)} ({assetsDoD.percentage}%)
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColorPill(pl.status)}`}>
                          {pl.status}
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-500 hidden md:table-cell">{new Date(pl.lastUpdated).toLocaleString()}</td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                          {(pl.status === ProcessStatus.AWAITING_SIGN_OFF || pl.status === ProcessStatus.REJECTED || pl.status === ProcessStatus.IN_PROGRESS) && (
                               <button 
                                  onClick={() => handleOpenModal(pl, 'ProductLine')}
                                  className="px-3 py-1 bg-sky-600 text-white rounded-md hover:bg-sky-700 text-xs font-medium"
                                  disabled={pl.status === ProcessStatus.AWAITING_SIGN_OFF && !canSignOffProductLine}
                                  title={pl.status === ProcessStatus.AWAITING_SIGN_OFF && !canSignOffProductLine ? "All strategies must be signed off first" : "Review Product Line"}
                               >
                                  Review Product Line
                              </button>
                          )}
                           {pl.status === ProcessStatus.SIGNED_OFF && (
                               <span className="text-xs text-green-700 font-semibold">Signed Off</span>
                          )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
             <p className="text-slate-500 text-center py-4">No Product Lines to display for {currentBusinessArea}.</p>
        )}
      </DashboardCard>

      {selectedItem && modalLevel && (
        <SignOffDetailModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          item={selectedItem}
          level={modalLevel}
          onSignOffAction={handleSignOffAction}
          onOpenStrategyModal={(strategy) => handleOpenModal(strategy, 'Strategy')}
        />
      )}
    </div>
  );
};

export default SignOffPage;