
import React, { useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';

const CaseManagementPage: React.FC = () => {
  const { setCurrentPageTitle } = useAppContext();
  
  useEffect(() => {
    setCurrentPageTitle('Case Management');
  }, [setCurrentPageTitle]);

  return (
    <div className="space-y-6">
      <DashboardCard title="Case Management">
        <p className="text-slate-600">
          Track and manage follow-up actions on identified issues. Create cases, assign them, track status, and manage escalations.
        </p>
        <div className="mt-4">
            <button className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700">Create New Case</button>
        </div>
         <div className="mt-6 h-48 bg-slate-200 rounded-md flex items-center justify-center">
          <p className="text-slate-500">Case list / tracking table will appear here.</p>
        </div>
      </DashboardCard>
    </div>
  );
};

export default CaseManagementPage;
