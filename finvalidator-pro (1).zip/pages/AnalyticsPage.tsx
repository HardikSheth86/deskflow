import React, { useEffect, useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { EyeIcon, SendIcon, DocumentReportIcon } from '../components/icons';
import SendReportModal from '../components/SendReportModal'; // New import
import { MOCK_DISTRIBUTION_LISTS } from '../constants'; // New import
import { DistributionList } from '../types'; // New import

// For actual charts, you would import from 'recharts' or similar
// import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ReportItem {
  id: string;
  title: string;
  description: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => React.ReactNode;
}

const preCannedReports: ReportItem[] = [
  {
    id: 'daily_summary',
    title: 'Daily P&L and Balance Sheet Summary',
    description: 'A high-level overview of profit & loss and balance sheet figures for senior management.',
    icon: DocumentReportIcon,
  },
  {
    id: 'exception_aging',
    title: 'Exception Aging Report',
    description: 'Tracks the resolution time of outstanding exceptions, highlighting overdue items.',
    icon: DocumentReportIcon,
  },
  {
    id: 'top_movers',
    title: 'Top 10 P&L Movers',
    description: 'Highlights the most significant P&L changes by position or instrument.',
    icon: DocumentReportIcon,
  },
  {
    id: 'adjustment_analysis',
    title: 'Adjustment Analysis Report',
    description: 'Summarizes the volume and value of adjustments by type and business area.',
    icon: DocumentReportIcon,
  },
];


const AnalyticsPage: React.FC = () => {
  const { setCurrentPageTitle } = useAppContext();
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [reportToSend, setReportToSend] = useState<ReportItem | null>(null);
  
  useEffect(() => {
    setCurrentPageTitle('Analytics & Reporting');
  }, [setCurrentPageTitle]);

  // Mock data for a chart
  const mockChartData = [
    { name: 'Jan', PnL: 4000, Exceptions: 24 },
    { name: 'Feb', PnL: 3000, Exceptions: 13 },
    { name: 'Mar', PnL: 2000, Exceptions: 98 },
    { name: 'Apr', PnL: 2780, Exceptions: 39 },
    { name: 'May', PnL: 1890, Exceptions: 48 },
    { name: 'Jun', PnL: 2390, Exceptions: 38 },
  ];

  const handleViewReport = (reportTitle: string) => {
    alert(`Simulating view for: ${reportTitle}\n(In a real app, this would display the report)`);
  };

  const handleOpenSendModal = (report: ReportItem) => {
    setReportToSend(report);
    setIsSendModalOpen(true);
  };

  const handleConfirmSendReport = (
    title: string,
    selectedListIds: string[],
    customEmails: string
  ) => {
    const selectedListNames = MOCK_DISTRIBUTION_LISTS
      .filter(list => selectedListIds.includes(list.id))
      .map(list => list.name)
      .join(', ');

    let message = `Simulating send for report: "${title}".\n`;
    if (selectedListNames) {
      message += `Selected Distribution Lists: ${selectedListNames}\n`;
    }
    if (customEmails) {
      message += `Custom Emails: ${customEmails}\n`;
    }
    if (!selectedListNames && !customEmails) {
        message += "No recipients specified.\n"
    }
    
    alert(message + "(In a real app, this would dispatch the report via email/chosen channels)");
    setIsSendModalOpen(false);
    setReportToSend(null);
  };


  return (
    <div className="space-y-6">
      <DashboardCard title="Pre-canned Reports">
        <p className="text-slate-600 mb-6">
          Access a library of standard reports. Click 'View' to see a report or 'Send' to share it.
        </p>
        <div className="space-y-4">
          {preCannedReports.map((report) => (
            <div key={report.id} className="p-4 border border-slate-200 rounded-lg bg-white hover:shadow-md transition-shadow">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                <div className="flex items-start mb-3 sm:mb-0">
                  <report.icon className="w-8 h-8 text-sky-600 mr-4 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-md font-semibold text-slate-800">{report.title}</h3>
                    <p className="text-sm text-slate-500">{report.description}</p>
                  </div>
                </div>
                <div className="flex space-x-2 flex-shrink-0 mt-2 sm:mt-0 sm:ml-4">
                  <button
                    onClick={() => handleViewReport(report.title)}
                    className="px-3 py-1.5 bg-sky-500 text-white rounded-md hover:bg-sky-600 transition-colors text-sm font-medium flex items-center"
                    aria-label={`View ${report.title}`}
                  >
                    <EyeIcon className="w-4 h-4 mr-1.5" />
                    View
                  </button>
                  <button
                    onClick={() => handleOpenSendModal(report)}
                    className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium flex items-center"
                    aria-label={`Send ${report.title}`}
                  >
                    <SendIcon className="w-4 h-4 mr-1.5" />
                    Send
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </DashboardCard>
      
      <DashboardCard title="Analytics Playground">
        <p className="text-slate-600 mb-4">
          Interactively slice and dice data, and visualize trends. (Chart below is a placeholder)
        </p>
        <div className="h-64 bg-slate-200 rounded-md flex items-center justify-center">
          <p className="text-slate-500">Analytics chart rendering area (e.g., using Recharts or D3.js)</p>
          {/* Example of where a Recharts chart would go:
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={mockChartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="PnL" fill="#8884d8" />
              <Bar dataKey="Exceptions" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
          */}
        </div>
      </DashboardCard>

      {reportToSend && (
        <SendReportModal
          isOpen={isSendModalOpen}
          onClose={() => {
            setIsSendModalOpen(false);
            setReportToSend(null);
          }}
          reportTitle={reportToSend.title}
          distributionLists={MOCK_DISTRIBUTION_LISTS}
          onConfirmSend={handleConfirmSendReport}
        />
      )}
    </div>
  );
};

export default AnalyticsPage;
