
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../hooks/useAppContext';
import { MOCK_KPIS, MOCK_PROCESS_STAGES, MOCK_EXCEPTIONS, MOCK_PRODUCT_LINES_BY_AREA } from '../constants';
import { KPI, ProcessStage, ExceptionCategory, SignOffProductLine, ProcessStatus, ExceptionStatus } from '../types';
import DashboardCard from '../components/DashboardCard';
import ProgressBar from '../components/ProgressBar';
import { EyeIcon } from '../components/icons';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
// Note: Recharts is a dependency. Ensure it's installed (`npm install recharts`) or available via CDN.


const DashboardPage: React.FC = () => {
  const { currentBusinessArea, setCurrentPageTitle } = useAppContext();
  const [kpis, setKpis] = useState<KPI[]>([]);
  const [processStages, setProcessStages] = useState<ProcessStage[]>([]);
  const [exceptionSummaryData, setExceptionSummaryData] = useState<{ name: string; value: number }[]>([]);
  const [signOffSummary, setSignOffSummary] = useState<SignOffProductLine[]>([]);
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  useEffect(() => {
    setCurrentPageTitle('Dashboard');
  }, [setCurrentPageTitle]);

  useEffect(() => {
    setKpis(MOCK_KPIS[currentBusinessArea] || []);
    setProcessStages(MOCK_PROCESS_STAGES); // Assuming process stages are generic for now
    
    const exceptionsForArea = MOCK_EXCEPTIONS.filter(ex => ex.businessArea === currentBusinessArea);
    const summary: Record<ExceptionCategory, number> = {
      [ExceptionCategory.FOBO]: 0,
      [ExceptionCategory.VRS]: 0,
      [ExceptionCategory.DOD]: 0,
      [ExceptionCategory.ATTRIBUTION]: 0,
      [ExceptionCategory.CUSTOM_RULES]: 0,
    };
    exceptionsForArea.forEach(ex => {
      if (ex.status !== ExceptionStatus.CLOSED && ex.status !== ExceptionStatus.RESOLVED) {
        summary[ex.category] = (summary[ex.category] || 0) + 1;
      }
    });
    setExceptionSummaryData(Object.entries(summary)
        .map(([name, value]) => ({ name, value }))
        .filter(item => item.value > 0) // Only show categories with exceptions
    );

    setSignOffSummary(MOCK_PRODUCT_LINES_BY_AREA[currentBusinessArea] || []);

  }, [currentBusinessArea]);

  const getStatusColor = (status: ProcessStatus) => {
    switch (status) {
      case ProcessStatus.SIGNED_OFF: return 'bg-green-100 text-green-700';
      case ProcessStatus.AWAITING_SIGN_OFF: return 'bg-yellow-100 text-yellow-700';
      case ProcessStatus.IN_PROGRESS: return 'bg-sky-100 text-sky-700';
      case ProcessStatus.REJECTED: return 'bg-red-100 text-red-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      <DashboardCard title={`Business Area Summary: ${currentBusinessArea}`} className="bg-gradient-to-r from-sky-500 to-indigo-500 text-white shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi) => (
            <div key={kpi.label} className="bg-white/20 p-4 rounded-lg backdrop-blur-sm">
              <p className="text-sm text-sky-100">{kpi.label}</p>
              <p className="text-2xl font-bold">{kpi.value}</p>
              <p className={`text-xs ${
                kpi.varianceType === 'positive' ? 'text-green-300' :
                kpi.varianceType === 'negative' ? 'text-red-300' : 'text-sky-100'
              }`}>{kpi.variance}</p>
            </div>
          ))}
        </div>
      </DashboardCard>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <DashboardCard title="Daily Process Update" className="lg:col-span-2">
            <ProgressBar stages={processStages} currentStageName={processStages.find(s => s.status === 'in-progress')?.name} />
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-xs">
                {processStages.map(stage => (
                    <div key={stage.id} className="text-center">
                        <p className="font-medium text-slate-600">{stage.name}</p>
                        <p className="text-slate-500">
                            {stage.status === 'completed' && stage.completedAt ? new Date(stage.completedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : stage.status.replace('-', ' ')}
                        </p>
                    </div>
                ))}
            </div>
        </DashboardCard>

        <DashboardCard title="Exception Summary" actions={
            <Link to="/exceptions" className="text-sm text-sky-600 hover:text-sky-800 font-medium flex items-center">
                View Details <EyeIcon className="w-4 h-4 ml-1" />
            </Link>
        }>
          {exceptionSummaryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={exceptionSummaryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} label>
                  {exceptionSummaryData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="vertical" align="right" verticalAlign="middle" iconSize={10} wrapperStyle={{fontSize: "12px"}}/>
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-500 text-center py-8">No outstanding exceptions for {currentBusinessArea}.</p>
          )}
        </DashboardCard>
      </div>

      <DashboardCard title="Sign-off Status">
        {signOffSummary.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Entity/Segment</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Last Updated</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {signOffSummary.map((entity) => (
                  <tr key={entity.id}>
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-800">{entity.name}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(entity.status)}`}>
                        {entity.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{new Date(entity.lastUpdated).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
             <p className="text-slate-500 text-center py-4">No sign-off entities configured for {currentBusinessArea}.</p>
        )}
      </DashboardCard>
    </div>
  );
};

export default DashboardPage;