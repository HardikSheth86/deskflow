import React, { useEffect, useState, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { MOCK_ADJUSTMENTS } from '../constants';
import { Adjustment, AdjustmentType, AdjustmentStatus } from '../types';
import AdjustmentModal from '../components/AdjustmentModal';
import { PencilIcon, PlusCircleIcon } from '../components/icons';

const AdjustmentsPage: React.FC = () => {
  const { currentBusinessArea, setCurrentPageTitle } = useAppContext();
  const [adjustments, setAdjustments] = useState<Adjustment[]>(MOCK_ADJUSTMENTS);
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
  const [editingAdjustment, setEditingAdjustment] = useState<Adjustment | null>(null);

  useEffect(() => {
    setCurrentPageTitle('Adjustments Management');
  }, [setCurrentPageTitle]);

  const handleOpenNewAdjustmentModal = () => {
    setEditingAdjustment(null);
    setIsAdjustmentModalOpen(true);
  };
  
  const handleOpenEditAdjustmentModal = (adjustment: Adjustment) => {
    setEditingAdjustment(adjustment);
    setIsAdjustmentModalOpen(true);
  };

  const handleSaveAdjustment = useCallback((savedAdjustment: Adjustment) => {
    setAdjustments(prev => {
      const index = prev.findIndex(adj => adj.id === savedAdjustment.id);
      if (index > -1) {
        const updated = [...prev];
        updated[index] = savedAdjustment;
        return updated;
      }
      return [...prev, savedAdjustment];
    });
    // Also update MOCK_ADJUSTMENTS if this was a real backend call
    const mockIndex = MOCK_ADJUSTMENTS.findIndex(adj => adj.id === savedAdjustment.id);
    if (mockIndex > -1) {
      MOCK_ADJUSTMENTS[mockIndex] = savedAdjustment;
    } else {
      MOCK_ADJUSTMENTS.push(savedAdjustment);
    }

    setIsAdjustmentModalOpen(false);
    setEditingAdjustment(null);
    alert(`Adjustment ${savedAdjustment.id} has been saved with status: ${savedAdjustment.status}`);
  }, []);

  const getStatusColorPill = (status: AdjustmentStatus) => {
    switch (status) {
      case 'APPROVED': return 'bg-green-100 text-green-700';
      case 'SUBMITTED':
      case 'PENDING_REVIEW': return 'bg-sky-100 text-sky-700';
      case 'DRAFT': return 'bg-slate-100 text-slate-700';
      case 'REJECTED':
      case 'CANCELLED': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };


  return (
    <div className="space-y-6">
      <DashboardCard title="Adjustment Workflow & Control">
        <div className="flex justify-between items-center">
            <p className="text-slate-600 mb-4">
            Create, review, and manage financial adjustments with full audit trail and role-based access.
            </p>
            <button 
                onClick={handleOpenNewAdjustmentModal}
                className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors flex items-center text-sm font-medium"
            >
                <PlusCircleIcon className="w-5 h-5 mr-2"/>
                Create New Adjustment
            </button>
        </div>
      </DashboardCard>
      <DashboardCard title="Recent Adjustments">
        {adjustments.length > 0 ? (
             <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">ID</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Type</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Exception ID</th>
                  <th className="px-3 py-2 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Amount</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden md:table-cell">Created By</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden lg:table-cell">Created At</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {adjustments.slice().sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((adj) => (
                  <tr key={adj.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-3 py-2 whitespace-nowrap text-sm font-medium text-sky-700">{adj.id}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-700">{adj.type}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-700">{adj.relatedExceptionId || 'N/A'}</td>
                    <td className={`px-3 py-2 whitespace-nowrap text-sm font-semibold text-right ${adj.amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {adj.amount.toLocaleString(undefined, {style:'currency', currency: adj.currency})}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColorPill(adj.status)}`}>
                            {adj.status.replace('_', ' ')}
                        </span>
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-600 hidden md:table-cell">{adj.createdBy}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-600 hidden lg:table-cell">{new Date(adj.createdAt).toLocaleDateString()}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-center">
                        <button 
                            onClick={() => handleOpenEditAdjustmentModal(adj)}
                            className="text-yellow-500 hover:text-yellow-700 p-1 rounded-full hover:bg-yellow-100"
                            title="Edit Adjustment"
                        >
                            <PencilIcon className="w-4 h-4" />
                        </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
            <p className="text-slate-500 text-center py-4">No adjustments found. Click "Create New Adjustment" to add one.</p>
        )}
      </DashboardCard>

      {isAdjustmentModalOpen && (
        <AdjustmentModal
            isOpen={isAdjustmentModalOpen}
            onClose={() => {
                setIsAdjustmentModalOpen(false);
                setEditingAdjustment(null);
            }}
            onSave={handleSaveAdjustment}
            existingAdjustment={editingAdjustment}
            businessArea={currentBusinessArea} // Or derive appropriately if adjustments are not BA specific
        />
      )}
    </div>
  );
};

export default AdjustmentsPage;