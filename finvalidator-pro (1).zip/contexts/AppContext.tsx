
import React, { createContext, useState, ReactNode } from 'react';
import { BusinessArea, AppContextType } from '../types';
import { ALL_BUSINESS_AREAS } from '../constants';

export const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [currentBusinessArea, setCurrentBusinessArea] = useState<BusinessArea>(ALL_BUSINESS_AREAS[0]);
  const [currentPageTitle, setCurrentPageTitle] = useState<string>('Dashboard');

  return (
    <AppContext.Provider value={{ currentBusinessArea, setCurrentBusinessArea, currentPageTitle, setCurrentPageTitle }}>
      {children}
    </AppContext.Provider>
  );
};
