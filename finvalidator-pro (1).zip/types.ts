
export enum BusinessArea {
  EQUITIES = 'Equities',
  FIXED_INCOME = 'Fixed Income',
  PRIME_BROKERAGE = 'Prime Brokerage',
  COMMODITIES = 'Commodities',
}

export enum ProcessStatus {
  IN_PROGRESS = 'In Progress',
  AWAITING_SIGN_OFF = 'Awaiting Sign-off',
  SIGNED_OFF = 'Signed Off',
  REJECTED = 'Rejected',
}

export interface ProcessStage {
  id: string;
  name: string;
  completedAt: string | null;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
}

export interface KPI {
  label: string;
  value: string;
  variance: string;
  varianceType: 'positive' | 'negative' | 'neutral';
}

export enum ExceptionCategory {
  FOBO = 'FOBO',
  VRS = 'VRS',
  DOD = 'DOD',
  ATTRIBUTION = 'Attribution',
  CUSTOM_RULES = 'Custom Rules',
}

export enum ExceptionStatus {
  OPEN = 'Open',
  IN_REVIEW = 'In Review',
  PENDING_ADJUSTMENT = 'Pending Adjustment',
  RESOLVED = 'Resolved',
  CLOSED = 'Closed',
}

export interface Exception {
  id: string;
  category: ExceptionCategory;
  positionId: string;
  financialImpact: number;
  currency: string;
  description: string;
  status: ExceptionStatus;
  assignedTo?: string;
  rcaCommentary?: string;
  aiRcaCommentary?: string; // Added field for AI-generated RCA
  dateIdentified: string;
  businessArea: BusinessArea;
  details?: Record<string, string | number>;
  history?: { timestamp: string; action: string; user: string }[];
}

export interface ActivityLogItem {
  id: string;
  timestamp: string;
  type: 'Trade' | 'Adjustment' | 'FX Reval' | 'Fee' | 'System' | 'Commentary';
  description: string;
  financialImpact?: { 
    amount: number; 
    currency: string; 
    pnlEffect?: number; 
    assetEffect?: number; 
    liabilityEffect?: number 
  };
  user?: string;
}

// New types for Multi-Level Sign-Off
export interface SignOffStrategy {
  id: string;
  name: string;
  parentId: string; // ID of the parent SignOffProductLine
  status: ProcessStatus;
  lastUpdated: string;
  currency: string;
  
  // Financials
  currentNetPnL: number;
  previousNetPnL: number;
  currentTotalAssets: number;
  previousTotalAssets: number;
  currentTotalLiabilities: number;
  previousTotalLiabilities: number;

  // Detailed P&L Breakdown
  pnlTrading: number;
  pnlFxReval: number;
  pnlAdjustments: number;

  // Detailed Asset Movement Breakdown
  assetChangeTrading: number;
  assetChangeFxReval: number;
  assetChangeAdjustments: number;

  // Detailed Liability Movement Breakdown
  liabilityChangeTrading: number;
  liabilityChangeFxReval: number;
  liabilityChangeAdjustments: number;
  
  activityLog: ActivityLogItem[];
}

export interface SignOffProductLine {
  id: string;
  name: string; // e.g., "Equities US", "Fixed Income Global"
  businessArea: BusinessArea;
  status: ProcessStatus;
  lastUpdated: string;
  currency: string; // Assuming product line has a primary reporting currency

  // Aggregate Financials (rolled up from strategies)
  currentNetPnL: number;
  previousNetPnL: number;
  currentTotalAssets: number;
  previousTotalAssets: number;
  currentTotalLiabilities: number;
  previousTotalLiabilities: number;

  strategies: SignOffStrategy[];
  // Product-line specific activity log or commentary could be added here if needed
}


export interface NavItemType {
  path: string;
  name: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
}

export enum AdjustmentType {
  PNL_CORRECTION = 'P&L Correction',
  BS_REALIGNMENT = 'Balance Sheet Realignment',
  FEE_POSTING = 'Fee Posting',
  WASH_ACCOUNT_CLEARING = 'Wash Account Clearing',
  TRADE_AMENDMENT = 'Trade Amendment',
  OTHER = 'Other',
}

export type AdjustmentStatus = 'DRAFT' | 'PENDING_REVIEW' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'CANCELLED';


export interface Adjustment {
  id: string;
  relatedExceptionId?: string; // Optional, as adjustments can be standalone
  type: AdjustmentType;
  amount: number;
  currency: string;
  debitAccount: string;
  creditAccount: string;
  justification: string;
  status: AdjustmentStatus;
  createdBy: string;
  createdAt: string;
  lastModifiedAt?: string;
  submittedBy?: string;
  submittedAt?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  rejectionReason?: string;

  // AI Suggestion Fields
  suggestedAmount?: number;
  suggestedCurrency?: string;
  suggestedDebitAccount?: string;
  suggestedCreditAccount?: string;
  suggestedJustification?: string;
}

export interface AppContextType {
  currentBusinessArea: BusinessArea;
  setCurrentBusinessArea: (area: BusinessArea) => void;
  currentPageTitle: string;
  setCurrentPageTitle: (title: string) => void;
}

export interface ContextMenuItemType {
  label?: string;
  icon?: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  onClick?: () => void;
  disabled?: boolean;
  isSeparator?: boolean;
}

export interface PositionDrillDownInfo {
  positionId: string;
  marketValue: string;
  quantity: number;
  costBasis: string;
  lastPrice: string;
  unrealizedPnL: string;
  relatedBook: string;
  assetClass: string;
}

export interface TradeDrillDownInfo {
  tradeId: string;
  timestamp: string;
  quantity: number;
  price: number;
  currency: string;
  direction: 'Buy' | 'Sell';
  counterparty: string;
  relatedExceptionId: string;
}

// Union type for drill-down content
export type DrillDownContentType = 
  | { type: 'position'; data: PositionDrillDownInfo }
  | { type: 'trades'; data: TradeDrillDownInfo[] };

// New Commentary Types
export enum CommentaryType {
  MARKET = 'Market Commentary',
  OPERATIONAL_RISK = 'Operational Risk Commentary',
  BALANCE_SHEET_FLUCTUATION = 'Balance Sheet Fluctuation Commentary',
  T0_T1_COMMENTARY = 'T0/T1 Commentary',
  DAILY_TRADER_PACK = 'Daily Trader Pack',
}

export interface CommentarySection {
  title: string;
  userContent: string;
  aiSuggestion?: string;
}

export interface Commentary {
  id: string;
  type: CommentaryType;
  title: string;
  author: string;
  dateCreated: string;
  businessArea: BusinessArea;
  sections: CommentarySection[];
  linkedItems?: string[]; // e.g., P&L line IDs, Exception IDs
  tags?: string[];
}

export interface CommentaryTemplate {
  type: CommentaryType;
  name: string;
  description: string;
  defaultSections: Array<{ title: string; aiPlaceholder?: string }>;
}

export interface DistributionList {
  id: string;
  name: string;
  description?: string;
}