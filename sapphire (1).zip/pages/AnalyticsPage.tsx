import React, { useEffect, useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { EyeIcon, SendIcon, DocumentReportIcon, ChevronDownIcon, ChevronUpIcon, ChatBubbleLeftRightIcon, PaperAirplaneIcon, LinkIcon } from '../components/icons';
import SendReportModal from '../components/SendReportModal';
import FullScreenReportViewer from '../components/FullScreenReportViewer';
import { MOCK_DISTRIBUTION_LISTS } from '../constants';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

export interface ReportItem {
  id: string;
  title: string;
  description: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => React.ReactNode;
  defaultFormat: 'PDF' | 'Excel' | 'CSV';
  powerBiEmbedUrl?: string;
}

export interface ReportCategory {
  categoryId: string;
  categoryTitle: string;
  reports: ReportItem[];
}

const categorizedReports: ReportCategory[] = [
  // ... (existing report data)
    {
    categoryId: 'pnl_bs_reports',
    categoryTitle: 'P&L and Balance Sheet Reports',
    reports: [
      {
        id: 'daily_summary_bs_pnl',
        title: 'Daily P&L and Balance Sheet Summary',
        description: 'A high-level overview of profit & loss and balance sheet figures for senior management.',
        icon: DocumentReportIcon,
        defaultFormat: 'PDF',
        powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=f6bfd646-b718-44dc-a37a-5409c593f2e1&autoAuth=true&ctid=common', // Example URL
      },
      {
        id: 'daily_pnl_detailed',
        title: 'Daily P&L Report (Detailed)',
        description: 'Comprehensive daily profit and loss statement with breakdowns by desk and product.',
        icon: DocumentReportIcon,
        defaultFormat: 'Excel',
        powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=c5c8e4d7-1b0f-4e1e-9a9c-2f9d1e4a3b7c&autoAuth=true&ctid=common', // Example URL
      },
    ]
  },
];

const AnalyticsPage: React.FC = () => {
  const { setCurrentPageTitle, exceptions, productLinesByArea, currentBusinessArea } = useAppContext();
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [reportToSend, setReportToSend] = useState<ReportItem | null>(null);
  
  const [isFullScreenViewerOpen, setIsFullScreenViewerOpen] = useState(false);
  const [reportToViewInFullScreen, setReportToViewInFullScreen] = useState<ReportItem | null>(null);
  
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({ 'pnl_bs_reports': true });
  
  // State for "Talk to your data"
  const [analyticsQuestion, setAnalyticsQuestion] = useState('');
  const [analyticsAnswer, setAnalyticsAnswer] = useState('');
  const [analyticsSources, setAnalyticsSources] = useState<any[]>([]);
  const [isAsking, setIsAsking] = useState(false);

  useEffect(() => {
    setCurrentPageTitle('Analytics & Reporting');
  }, [setCurrentPageTitle]);
  
  const handleTalkToData = async () => {
    if (!process.env.API_KEY || !analyticsQuestion.trim()) return;

    setIsAsking(true);
    setAnalyticsAnswer('');
    setAnalyticsSources([]);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // Create a summary of available data for context
        const dataContext = `
        The application contains the following data for the ${currentBusinessArea} business area:
        - ${exceptions.length} total exceptions.
        - ${productLinesByArea[currentBusinessArea]?.length || 0} product lines.
        - Key P&L for the top product line is approximately ${productLinesByArea[currentBusinessArea]?.[0]?.currentNetPnL.toLocaleString() || 'N/A'}.
        `;
        
        const prompt = `You are a financial analyst AI for the Sapphire application. Answer the user's question about their data. 
        Use the provided data context and Google Search for real-time information if needed. Always cite your sources from Google Search if you use them.
        Data Context: ${dataContext}
        User Question: "${analyticsQuestion}"`;

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });

        setAnalyticsAnswer(response.text);
        setAnalyticsSources(response.candidates?.[0]?.groundingMetadata?.groundingChunks || []);

    } catch (error) {
        console.error("Error with conversational analytics:", error);
        setAnalyticsAnswer("I'm sorry, I encountered an error trying to answer your question. Please try again.");
    } finally {
        setIsAsking(false);
    }
  };


  const toggleCategory = (categoryId: string) => {
    setOpenCategories(prev => ({ ...prev, [categoryId]: !prev[categoryId] }));
  };

  const handleViewReportFullScreen = (report: ReportItem) => {
    setReportToViewInFullScreen(report);
    setIsFullScreenViewerOpen(true);
  };

  const handleOpenSendModal = (report: ReportItem) => {
    setReportToSend(report);
    setIsSendModalOpen(true);
  };
  
  const handleCloseFullScreenViewer = () => {
    setIsFullScreenViewerOpen(false);
    setReportToViewInFullScreen(null);
  };

  const handleSendFromFullScreen = (report: ReportItem) => {
    setIsFullScreenViewerOpen(false);
    setReportToViewInFullScreen(null);
    handleOpenSendModal(report);
  };

  const handleConfirmSendReport = (
    title: string,
    selectedListIds: string[],
    customEmails: string,
    format: 'PDF' | 'Excel' | 'CSV'
  ) => {
    const selectedListNames = MOCK_DISTRIBUTION_LISTS
      .filter(list => selectedListIds.includes(list.id))
      .map(list => list.name)
      .join(', ');

    let message = `Simulating send for report: "${title}" in ${format} format.\n`;
    if (selectedListNames) message += `Selected Distribution Lists: ${selectedListNames}\n`;
    if (customEmails) message += `Custom Emails: ${customEmails}\n`;
    if (!selectedListNames && !customEmails) message += "No recipients specified.\n";
    
    alert(message + "(In a real app, this would dispatch the report)");
    setIsSendModalOpen(false);
    setReportToSend(null);
  };

  return (
    <div className="space-y-6">
      <DashboardCard title={<div className="flex items-center"><ChatBubbleLeftRightIcon className="w-6 h-6 mr-2"/>Talk to Your Data</div>}>
        <div className="space-y-3">
            <div className="flex space-x-2">
                 <input
                    type="text"
                    value={analyticsQuestion}
                    onChange={(e) => setAnalyticsQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleTalkToData()}
                    placeholder="e.g., What was the biggest market news affecting Equities today?"
                    className="flex-grow w-full p-2 border border-slate-300 rounded-lg focus:ring-sky-500 focus:border-sky-500 text-sm"
                    disabled={isAsking}
                />
                <button
                    onClick={handleTalkToData}
                    disabled={isAsking || !analyticsQuestion.trim()}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg disabled:bg-indigo-300 disabled:cursor-not-allowed hover:bg-indigo-700 transition-colors flex items-center"
                    aria-label="Ask AI Analyst"
                >
                    <PaperAirplaneIcon className="w-5 h-5 mr-2" />
                    {isAsking ? 'Thinking...' : 'Ask'}
                </button>
            </div>
            {(analyticsAnswer || isAsking) && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg animate-fadeIn">
                    {isAsking ? (
                        <p className="text-slate-500">The AI analyst is reviewing your question...</p>
                    ) : (
                        <>
                            <p className="text-slate-700 whitespace-pre-wrap">{analyticsAnswer}</p>
                            {analyticsSources.length > 0 && (
                                <div className="mt-4 pt-2 border-t border-slate-200">
                                    <h5 className="text-xs font-semibold text-slate-600 mb-1 flex items-center"><LinkIcon className="w-3 h-3 mr-1.5"/>Sources:</h5>
                                    <ul className="space-y-1">
                                        {analyticsSources.map((source, index) => source.web && (
                                            <li key={index}>
                                                <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-sky-600 hover:underline">
                                                    {source.web.title || source.web.uri}
                                                </a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </>
                    )}
                </div>
            )}
        </div>
         <style>{`
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
        `}</style>
      </DashboardCard>

      <DashboardCard title="Report Library">
        <div className="space-y-3">
          {categorizedReports.map((category) => (
            <div key={category.categoryId} className="border border-slate-200 rounded-lg bg-slate-50 overflow-hidden">
              <button
                onClick={() => toggleCategory(category.categoryId)}
                className="w-full flex justify-between items-center p-3 text-left bg-slate-100 hover:bg-slate-200"
                aria-expanded={openCategories[category.categoryId]}
              >
                <h2 className="text-md font-semibold text-slate-700">{category.categoryTitle}</h2>
                {openCategories[category.categoryId] ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
              </button>
              {openCategories[category.categoryId] && (
                <div className="p-1 sm:p-3">
                  <div className="space-y-3">
                    {category.reports.map((report) => (
                      <div key={report.id} className="p-3 border border-slate-200 rounded-md bg-white hover:shadow-md transition-shadow">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                          <div className="flex items-start mb-3 sm:mb-0">
                            <report.icon className="w-7 h-7 text-sky-600 mr-3 mt-1" />
                            <div>
                              <h3 className="text-sm font-semibold text-slate-800">{report.title}</h3>
                              <p className="text-xs text-slate-500">{report.description}</p>
                            </div>
                          </div>
                          <div className="flex space-x-2 self-center sm:self-auto sm:ml-4">
                            <button onClick={() => handleViewReportFullScreen(report)} className="px-3 py-1.5 bg-sky-500 text-white rounded-md hover:bg-sky-600 text-xs font-medium flex items-center">
                              <EyeIcon className="w-4 h-4 mr-1" /> View
                            </button>
                            <button onClick={() => handleOpenSendModal(report)} className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 text-xs font-medium flex items-center">
                              <SendIcon className="w-4 h-4 mr-1" /> Send
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </DashboardCard>
      
      {reportToSend && (
        <SendReportModal
          isOpen={isSendModalOpen}
          onClose={() => setIsSendModalOpen(false)}
          reportTitle={reportToSend.title}
          defaultFormat={reportToSend.defaultFormat}
          distributionLists={MOCK_DISTRIBUTION_LISTS}
          onConfirmSend={handleConfirmSendReport}
        />
      )}

      {isFullScreenViewerOpen && reportToViewInFullScreen && (
        <FullScreenReportViewer
          report={reportToViewInFullScreen}
          onClose={handleCloseFullScreenViewer}
          onSend={handleSendFromFullScreen}
        />
      )}
    </div>
  );
};

export default AnalyticsPage;