
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { ProcessStatus, SignOffProductLine, SignOffStrategy, ExceptionStatus, Region } from '../types';
import SignOffDetailModal from '../components/SignOffDetailModal'; 
import { formatCurrency, calculateDoDChange } from '../utils/helpers';
import StatusPill from '../components/StatusPill';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import SignOffBriefingModal from '../components/SignOffBriefingModal';
import { LightbulbIcon } from '../components/icons';


const SignOffPage: React.FC = () => {
  const { 
    currentBusinessArea, 
    setCurrentPageTitle,
    productLinesByArea,
    updateSignOffStatus,
    currentRegion,
    currentProductLineId,
    exceptions
  } = useAppContext();
  
  const displayedProductLines = useMemo(() => {
    const allForArea = productLinesByArea[currentBusinessArea] || [];
    return allForArea.filter(pl => 
      (currentRegion === 'ALL' || pl.region === currentRegion) &&
      (currentProductLineId === 'ALL' || pl.id === currentProductLineId)
    );
  }, [productLinesByArea, currentBusinessArea, currentRegion, currentProductLineId]);

  const [selectedItem, setSelectedItem] = useState<SignOffProductLine | SignOffStrategy | null>(null);
  const [modalLevel, setModalLevel] = useState<'ProductLine' | 'Strategy' | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBriefingModalOpen, setIsBriefingModalOpen] = useState(false);
  const [briefingContent, setBriefingContent] = useState('');
  const [isGeneratingBriefing, setIsGeneratingBriefing] = useState(false);
  const [selectedPlForBriefing, setSelectedPlForBriefing] = useState<SignOffProductLine | null>(null);
  
  useEffect(() => {
    setCurrentPageTitle('Sign-Off');
  }, [setCurrentPageTitle]);

  const handleOpenModal = (item: SignOffProductLine | SignOffStrategy, level: 'ProductLine' | 'Strategy') => {
    setSelectedItem(item);
    setModalLevel(level);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedItem(null);
    setModalLevel(null);
    setIsModalOpen(false);
  };

  const handleSignOffAction = useCallback((itemId: string, level: 'ProductLine' | 'Strategy', attestation: string, comments: string, approved: boolean) => {
    const newStatus = approved ? ProcessStatus.SIGNED_OFF : ProcessStatus.REJECTED;
    updateSignOffStatus(itemId, level, newStatus, approved);
    
    handleCloseModal();
    alert(`${level} ${itemId} has been ${approved ? 'Approved' : 'Rejected'}. Attestation: ${attestation}. Comments: ${comments}`);
  }, [updateSignOffStatus]);
  
  const getVarianceColorText = (isPositive: boolean, isPnL: boolean = false) => {
    if (isPnL) {
      return isPositive ? 'text-green-600' : 'text-red-600';
    }
    return isPositive ? 'text-green-600' : 'text-red-600';
  };

  const handleGenerateBriefing = async (productLine: SignOffProductLine) => {
    if (!process.env.API_KEY) {
        alert("API_KEY is not configured.");
        return;
    }
    setSelectedPlForBriefing(productLine);
    setIsGeneratingBriefing(true);
    setIsBriefingModalOpen(true);
    setBriefingContent('');

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const openExceptions = exceptions.filter(ex => 
          ex.productLineId === productLine.id && 
          ex.status !== ExceptionStatus.CLOSED && 
          ex.status !== ExceptionStatus.RESOLVED
        );

        const context = {
            productLineName: productLine.name,
            status: productLine.status,
            pnl: { current: productLine.currentNetPnL, prev: productLine.previousNetPnL },
            assets: { current: productLine.currentTotalAssets, prev: productLine.previousTotalAssets },
            childStrategies: productLine.strategies.map(s => ({ name: s.name, status: s.status, pnl: s.currentNetPnL })),
            openExceptions: openExceptions.map(ex => ({ id: ex.id, description: ex.description, impact: ex.financialImpact })),
        };
        
        const prompt = `As a senior financial controller, review the following data for the "${context.productLineName}". 
        Generate a concise sign-off briefing note in a clear, bulleted format. 
        Highlight the top 3 risks (e.g., rejected strategies, large open exceptions), summarize key P&L drivers, and list any outstanding items requiring attention before final sign-off.
        Data: ${JSON.stringify(context, null, 2)}`;
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
        });
        
        setBriefingContent(response.text);

    } catch (error) {
        console.error("Error generating briefing:", error);
        setBriefingContent("An error occurred while generating the briefing. Please try again.");
    } finally {
        setIsGeneratingBriefing(false);
    }
  };


  return (
    <div className="space-y-6">
      <DashboardCard title={`Sign-Off Status`}>
        <p className="text-slate-600 mb-4">
          Review Product Line financial summaries and Day-over-Day movements. Click "Review Product Line" for detailed strategy breakdown and attestation.
        </p>
         {displayedProductLines.length > 0 ? (
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Product Line</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Net P&L</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">P&L DoD</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total Assets</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Assets DoD</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">AI Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {displayedProductLines.map((pl) => {
                  const pnlDoD = calculateDoDChange(pl.currentNetPnL, pl.previousNetPnL);
                  const assetsDoD = calculateDoDChange(pl.currentTotalAssets, pl.previousTotalAssets);
                  const canSignOffProductLine = pl.strategies.every(s => s.status === ProcessStatus.SIGNED_OFF);

                  return (
                    <tr key={pl.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-slate-800">{pl.name}</td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-600">{formatCurrency(pl.currentNetPnL, pl.currency)}</td>
                      <td className={`px-3 py-3 whitespace-nowrap text-sm font-medium ${getVarianceColorText(pnlDoD.isPositive, true)}`}>
                        {pnlDoD.amount >= 0 ? '+' : ''}{formatCurrency(pnlDoD.amount, pl.currency)} ({pnlDoD.percentage}%)
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-600">{formatCurrency(pl.currentTotalAssets, pl.currency)}</td>
                      <td className={`px-3 py-3 whitespace-nowrap text-sm font-medium ${getVarianceColorText(assetsDoD.isPositive)}`}>
                         {assetsDoD.amount >= 0 ? '+' : ''}{formatCurrency(assetsDoD.amount, pl.currency)} ({assetsDoD.percentage}%)
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                        <StatusPill status={pl.status} />
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                          {(pl.status === ProcessStatus.AWAITING_SIGN_OFF || pl.status === ProcessStatus.REJECTED || pl.status === ProcessStatus.IN_PROGRESS) && (
                               <button 
                                  onClick={() => handleOpenModal(pl, 'ProductLine')}
                                  className="px-3 py-1 bg-sky-600 text-white rounded-md hover:bg-sky-700 text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                                  disabled={pl.status === ProcessStatus.AWAITING_SIGN_OFF && !canSignOffProductLine}
                                  title={pl.status === ProcessStatus.AWAITING_SIGN_OFF && !canSignOffProductLine ? "All strategies must be signed off first" : "Review Product Line"}
                               >
                                  Review
                              </button>
                          )}
                           {pl.status === ProcessStatus.SIGNED_OFF && (
                               <span className="text-xs text-green-700 font-semibold">Signed Off</span>
                          )}
                      </td>
                       <td className="px-3 py-3 whitespace-nowrap text-sm">
                            <button
                                onClick={() => handleGenerateBriefing(pl)}
                                disabled={isGeneratingBriefing && selectedPlForBriefing?.id === pl.id}
                                className="px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 text-xs font-medium flex items-center disabled:opacity-50"
                                title="Generate AI Sign-Off Briefing"
                            >
                                <LightbulbIcon className="w-4 h-4 mr-1" />
                                {isGeneratingBriefing && selectedPlForBriefing?.id === pl.id ? 'Generating...' : 'Briefing'}
                            </button>
                       </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
             <p className="text-slate-500 text-center py-4">No Product Lines to display for the current filters.</p>
        )}
      </DashboardCard>

      {selectedItem && modalLevel && (
        <SignOffDetailModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          item={selectedItem}
          level={modalLevel}
          onSignOffAction={handleSignOffAction}
          onOpenStrategyModal={(strategy) => handleOpenModal(strategy, 'Strategy')}
        />
      )}

      {isBriefingModalOpen && selectedPlForBriefing && (
        <SignOffBriefingModal
            isOpen={isBriefingModalOpen}
            onClose={() => setIsBriefingModalOpen(false)}
            isLoading={isGeneratingBriefing}
            briefingContent={briefingContent}
            productLineName={selectedPlForBriefing.name}
        />
      )}
    </div>
  );
};

export default SignOffPage;
