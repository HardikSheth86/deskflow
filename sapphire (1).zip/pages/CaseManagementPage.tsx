import React, { useEffect, useState, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Case, CaseStatus, Exception } from '../types';
import DashboardCard from '../components/DashboardCard';
import Tabs, { TabItem } from '../components/Tabs';
import CaseCard from '../components/CaseCard';
import { BriefcaseIcon, CheckCircleIcon, UsersIcon } from '../components/icons';

const CaseManagementPage: React.FC = () => {
  const { 
    setCurrentPageTitle, 
    cases, 
    exceptions, 
    updateCase,
    currentRegion,
  } = useAppContext();
  
  const currentUser = 'Valerie User'; 

  useEffect(() => {
    setCurrentPageTitle('Case Management');
  }, [setCurrentPageTitle]);
  
  const getCasesForTab = (statusFilter: 'my-open' | 'all-open' | 'closed'): { caseItem: Case, exception: Exception | undefined }[] => {
    let filteredCases: Case[] = [];

    const baseFilteredCases = cases.filter(c => currentRegion === 'ALL' || c.region === currentRegion);

    if (statusFilter === 'my-open') {
      filteredCases = baseFilteredCases.filter(c => c.assignedTo === currentUser && c.status !== CaseStatus.CLOSED);
    } else if (statusFilter === 'all-open') {
      filteredCases = baseFilteredCases.filter(c => c.status !== CaseStatus.CLOSED);
    } else { // closed
      filteredCases = baseFilteredCases.filter(c => c.status === CaseStatus.CLOSED);
    }
    
    filteredCases.sort((a, b) => new Date(b.dateOpened).getTime() - new Date(a.dateOpened).getTime());

    return filteredCases.map(caseItem => ({
      caseItem,
      exception: exceptions.find(ex => ex.id === caseItem.exceptionId)
    }));
  };

  const myOpenCases = useMemo(() => getCasesForTab('my-open'), [cases, exceptions, currentUser, currentRegion]);
  const allOpenCases = useMemo(() => getCasesForTab('all-open'), [cases, exceptions, currentRegion]);
  const closedCases = useMemo(() => getCasesForTab('closed'), [cases, exceptions, currentRegion]);


  const CaseList: React.FC<{ caseData: { caseItem: Case, exception: Exception | undefined }[] }> = ({ caseData }) => {
    if (caseData.length === 0) {
      return <p className="text-center text-slate-500 py-8">No cases to display in this view.</p>;
    }
    return (
      <div className="space-y-4">
        {caseData.map(({ caseItem, exception }) => (
          <CaseCard 
            key={caseItem.id} 
            caseItem={caseItem} 
            exception={exception}
            onUpdateCase={updateCase}
            isCurrentUserAssigned={caseItem.assignedTo === currentUser}
          />
        ))}
      </div>
    );
  };
  
  const tabs: TabItem[] = [
    { 
      label: `My Open Cases (${myOpenCases.length})`,
      icon: BriefcaseIcon,
      content: <CaseList caseData={myOpenCases} />
    },
    { 
      label: `All Open Cases (${allOpenCases.length})`,
      icon: UsersIcon,
      content: <CaseList caseData={allOpenCases} />
    },
    { 
      label: `Closed Cases (${closedCases.length})`,
      icon: CheckCircleIcon,
      content: <CaseList caseData={closedCases} />
    },
  ];

  return (
    <div className="space-y-6">
      <DashboardCard title="Case Management Hub">
        <p className="text-slate-600 mb-4">
          Track, respond to, and resolve issues raised by controllers. Your open cases require your action to investigate and comment.
        </p>
        <Tabs tabs={tabs} />
      </DashboardCard>
    </div>
  );
};

export default CaseManagementPage;
