import React, { useEffect, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { BusinessArea, ProcessStatus, Region } from '../types';
import DashboardCard from '../components/DashboardCard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import StatusPill from '../components/StatusPill';
import { ALL_BUSINESS_AREAS } from '../constants';
import { formatCurrency, formatDateDistance } from '../utils/helpers';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const ManagementPage: React.FC = () => {
  const { 
    setCurrentPageTitle, 
    exceptions, 
    productLinesByArea,
    currentBusinessArea,
    currentProductLineId,
    currentStrategyId,
    currentRegion
  } = useAppContext();

  useEffect(() => {
    setCurrentPageTitle('Management Dashboard');
  }, [setCurrentPageTitle]);

  const pnlByArea = useMemo(() => {
    return ALL_BUSINESS_AREAS.map(area => {
      const pnl = (productLinesByArea[area] || [])
        .filter(pl => 
            (currentRegion === 'ALL' || pl.region === currentRegion) &&
            (currentProductLineId === 'ALL' || pl.id === currentProductLineId)
        )
        .flatMap(pl => pl.strategies)
        .filter(s => 
            (currentStrategyId === 'ALL' || s.id === currentStrategyId)
        )
        .reduce((sum, s) => sum + s.currentNetPnL, 0);
        
      return {
        name: area,
        'Net P&L': pnl,
      };
    });
  }, [productLinesByArea, currentRegion, currentProductLineId, currentStrategyId]);

  const exceptionsByArea = useMemo(() => {
    const counts: { [key in BusinessArea]?: number } = {};
    exceptions
    .filter(ex => 
        (currentRegion === 'ALL' || ex.region === currentRegion) &&
        (currentProductLineId === 'ALL' || ex.productLineId === currentProductLineId) &&
        (currentStrategyId === 'ALL' || ex.strategyId === currentStrategyId)
    )
    .forEach(ex => {
      if (ex.status === 'Open' || ex.status === 'In Review') {
        counts[ex.businessArea] = (counts[ex.businessArea] || 0) + 1;
      }
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value: value || 0 })).filter(d => d.value > 0);
  }, [exceptions, currentRegion, currentProductLineId, currentStrategyId]);

  const topExceptions = useMemo(() => {
    return exceptions
        .filter(ex => 
            (ex.status === 'Open' || ex.status === 'In Review') &&
            (currentRegion === 'ALL' || ex.region === currentRegion) &&
            (currentProductLineId === 'ALL' || ex.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || ex.strategyId === currentStrategyId)
        )
        .sort((a, b) => Math.abs(b.financialImpact) - Math.abs(a.financialImpact))
        .slice(0, 5);
  }, [exceptions, currentRegion, currentProductLineId, currentStrategyId]);

  const recentActivity = useMemo(() => {
      const allActivities = Object.values(productLinesByArea).flat().flatMap(pl => 
          pl.strategies.flatMap(s => 
              s.activityLog.map(log => ({ ...log, businessArea: s.businessArea, region: s.region, productLineId: pl.id, strategyId: s.id }))
          )
      );
      return allActivities
          .filter(act => 
            (currentRegion === 'ALL' || act.region === currentRegion) &&
            (currentProductLineId === 'ALL' || act.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || act.strategyId === act.strategyId)
          )
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 7);
  }, [productLinesByArea, currentRegion, currentProductLineId, currentStrategyId]);

  const allProductLines = useMemo(() => {
    return Object.values(productLinesByArea).flat().filter(pl => 
        (currentRegion === 'ALL' || pl.region === currentRegion) &&
        (currentProductLineId === 'ALL' || pl.id === currentProductLineId)
    );
  }, [productLinesByArea, currentRegion, currentProductLineId]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Net P&L Contribution by Business Area">
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={pnlByArea} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tickFormatter={(value) => `$${(Number(value) / 1000000).toFixed(1)}M`} tick={{ fontSize: 12 }}/>
                    <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                    <Legend />
                    <Bar dataKey="Net P&L" fill="#8884d8" />
                </BarChart>
            </ResponsiveContainer>
        </DashboardCard>
        <DashboardCard title="Open Exceptions by Business Area">
            {exceptionsByArea.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie
                            data={exceptionsByArea}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name.split(' ').map(n => n[0]).join('')} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                        >
                            {exceptionsByArea.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value} exceptions`} />
                        <Legend />
                    </PieChart>
                </ResponsiveContainer>
            ) : <p className="text-slate-500 text-center py-4 h-[300px] flex items-center justify-center">No open exceptions match the current filters.</p>}
        </DashboardCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Top Outstanding Exceptions (by Financial Impact)">
          {topExceptions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-50">
                    <tr>
                        <th className="px-3 py-2 text-left font-medium text-slate-500">ID</th>
                        <th className="px-3 py-2 text-left font-medium text-slate-500">Description</th>
                        <th className="px-3 py-2 text-left font-medium text-slate-500">Business Area</th>
                        <th className="px-3 py-2 text-right font-medium text-slate-500">Impact</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100">
                    {topExceptions.map((ex) => (
                        <tr key={ex.id}>
                            <td className="px-3 py-2 whitespace-nowrap font-medium text-sky-700">{ex.id}</td>
                            <td className="px-3 py-2 whitespace-normal max-w-xs truncate">{ex.description}</td>
                            <td className="px-3 py-2 whitespace-nowrap">{ex.businessArea}</td>
                            <td className={`px-3 py-2 whitespace-nowrap text-right font-semibold ${ex.financialImpact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {formatCurrency(ex.financialImpact, ex.position.currency)}
                            </td>
                        </tr>
                    ))}
                </tbody>
              </table>
            </div>
          ) : <p className="text-slate-500 text-center py-4 h-full flex items-center justify-center">No outstanding exceptions to display.</p>}
        </DashboardCard>

        <DashboardCard title="Recent Firm-wide Activity">
          {recentActivity.length > 0 ? (
              <div className="space-y-2">
                  {recentActivity.map(log => (
                      <div key={log.id} className="text-xs p-2 bg-slate-50 rounded-md">
                          <span className="font-semibold text-sky-700">{log.businessArea}: </span>
                          <span className="text-slate-600">{log.description}</span>
                          <span className="text-slate-400"> ({formatDateDistance(log.timestamp)})</span>
                      </div>
                  ))}
              </div>
          ) : <p className="text-slate-500 text-center py-4">No recent activity found.</p>}
        </DashboardCard>
      </div>

      <DashboardCard title="Global Sign-Off Status">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {allProductLines.map(pl => (
                <div key={pl.id} className="p-3 border border-slate-200 rounded-lg text-center">
                    <p className="text-sm font-semibold text-slate-700 truncate" title={pl.name}>{pl.name}</p>
                    <div className="my-2"><StatusPill status={pl.status} /></div>
                    <p className="text-xs text-slate-500">{pl.businessArea}</p>
                </div>
            ))}
            {allProductLines.length === 0 && <p className="col-span-full text-center text-slate-500 py-4">No product lines found for the current filters.</p>}
        </div>
      </DashboardCard>
    </div>
  );
};

export default ManagementPage;
