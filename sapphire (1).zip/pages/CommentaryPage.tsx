
import React, { useEffect, useState, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { MOCK_COMMENTARY_TEMPLATES } from '../constants';
import { Commentary, CommentaryTemplate, CommentaryType, Region } from '../types';
import CommentaryEditorModal from '../components/CommentaryEditorModal';
import { QuillPenIcon, EyeIcon, PencilIcon, LightbulbIcon, CpuChipIcon } from '../components/icons';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";


const CommentaryPage: React.FC = () => {
  const { 
    currentBusinessArea, 
    setCurrentPageTitle, 
    commentaries, 
    saveCommentary,
    currentRegion,
    currentProductLineId,
    currentStrategyId
  } = useAppContext();
  
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingCommentary, setEditingCommentary] = useState<Commentary | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<CommentaryTemplate | null>(null);
  const [isDrafting, setIsDrafting] = useState(false);


  useEffect(() => {
    setCurrentPageTitle('Commentary Management');
  }, [setCurrentPageTitle]);

  const filteredCommentaries = useMemo(() => {
    return commentaries.filter(c => 
      c.businessArea === currentBusinessArea &&
      (currentRegion === 'ALL' || c.region === currentRegion) &&
      (currentProductLineId === 'ALL' || c.productLineId === currentProductLineId || c.productLineId === 'ALL') &&
      (currentStrategyId === 'ALL' || c.strategyId === currentStrategyId || c.strategyId === 'ALL')
    );
  }, [commentaries, currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId]);

  const handleOpenNewCommentaryModal = (template: CommentaryTemplate) => {
    setSelectedTemplate(template);
    setEditingCommentary(null);
    setIsEditorOpen(true);
  };

  const handleOpenEditCommentaryModal = (commentary: Commentary) => {
    setSelectedTemplate(null);
    setEditingCommentary(commentary);
    setIsEditorOpen(true);
  };

  const handleCloseModal = () => {
    setIsEditorOpen(false);
    setEditingCommentary(null);
    setSelectedTemplate(null);
  };
  
  const handleSave = (commentaryToSave: Commentary) => {
    saveCommentary(commentaryToSave);
    handleCloseModal();
  }

  const handleDraftCommentary = async () => {
    if (!process.env.API_KEY) {
        alert("API_KEY is not configured.");
        return;
    }
    setIsDrafting(true);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `What were the most significant market-moving news, events, or economic data releases in the last 24 hours relevant to ${currentBusinessArea}? Summarize the key points and their likely impact on financial markets.`;
        
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });
        
        const summaryText = response.text;
        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        const sourcesText = groundingChunks.map((chunk: any) => chunk.web ? `- ${chunk.web.title}: ${chunk.web.uri}` : '- Source not available').join('\n');

        const newCommentary: Commentary = {
            id: `COM-AI-${Date.now()}`,
            type: CommentaryType.MARKET,
            title: `AI Draft: Market Commentary for ${currentBusinessArea} - ${new Date().toLocaleDateString()}`,
            author: 'Market Scribe Agent',
            dateCreated: new Date().toISOString(),
            businessArea: currentBusinessArea,
            productLineId: 'ALL',
            strategyId: 'ALL',
            region: currentRegion === 'ALL' ? Region.NORTH_AMERICA : currentRegion,
            sections: [
                { title: 'AI-Generated Market Overview', userContent: summaryText, aiSuggestion: "Review and edit this AI-generated summary." },
                { title: 'Sources', userContent: sourcesText || "No sources were returned by the AI.", aiSuggestion: "Sources provided by Google Search." }
            ],
            tags: ['ai-draft', 'market-scribe', currentBusinessArea.toLowerCase().replace(' ', '-')],
        };
        
        saveCommentary(newCommentary);
        alert(`A new draft market commentary has been created by the Market Scribe agent for ${currentBusinessArea}.`);

    } catch (error) {
        console.error("Error drafting commentary:", error);
        alert("An error occurred while drafting the commentary. Please check the console.");
    } finally {
        setIsDrafting(false);
    }
  };


  return (
    <div className="space-y-6">
      <DashboardCard title="Create New Commentary from Template">
        <p className="text-slate-600 mb-4">
          Select a template to start a new commentary. Each template provides predefined sections and AI suggestion placeholders.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {MOCK_COMMENTARY_TEMPLATES.map(template => (
            <div key={template.type} className="p-4 border border-slate-200 rounded-lg bg-white hover:shadow-lg transition-shadow flex flex-col justify-between">
              <div>
                <h3 className="text-md font-semibold text-sky-700 mb-1 flex items-center">
                  <QuillPenIcon className="w-5 h-5 mr-2" />
                  {template.name}
                </h3>
                <p className="text-xs text-slate-500 mb-3">{template.description}</p>
                <div className="mb-3">
                  <p className="text-xs font-medium text-slate-600">Sections:</p>
                  <ul className="list-disc list-inside text-xs text-slate-500">
                    {template.defaultSections.map(s => <li key={s.title}>{s.title}</li>)}
                  </ul>
                </div>
              </div>
              <button
                onClick={() => handleOpenNewCommentaryModal(template)}
                className="w-full mt-2 px-3 py-1.5 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium"
              >
                Create New
              </button>
            </div>
          ))}
        </div>
      </DashboardCard>

       <DashboardCard title={<div className="flex items-center"><CpuChipIcon className="w-5 h-5 mr-2" /> AI Agent Actions</div>}>
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="font-semibold text-slate-700">Market Scribe Agent</h3>
                    <p className="text-sm text-slate-500">Use AI to automatically draft a market commentary using real-time information from Google Search.</p>
                </div>
                 <button
                    onClick={handleDraftCommentary}
                    disabled={isDrafting}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors text-sm font-medium flex items-center disabled:opacity-50"
                >
                    <LightbulbIcon className="w-5 h-5 mr-2" />
                    {isDrafting ? 'Drafting...' : 'Draft Daily Market Commentary'}
                </button>
            </div>
       </DashboardCard>

      <DashboardCard title={`Existing Commentaries`}>
        {filteredCommentaries.length > 0 ? (
          <div className="space-y-4">
            {filteredCommentaries.slice().sort((a,b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime()).map(commentary => (
              <div key={commentary.id} className={`p-4 border border-slate-200 rounded-lg shadow-sm ${commentary.author.includes('Agent') ? 'bg-indigo-50 border-indigo-200' : 'bg-white'}`}>
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-md font-semibold text-slate-800">{commentary.title}</h4>
                    <p className="text-xs text-slate-500">
                      Type: {commentary.type} | Author: {commentary.author} | Date: {new Date(commentary.dateCreated).toLocaleDateString()}
                    </p>
                    {commentary.tags && commentary.tags.length > 0 && (
                      <p className="text-xs text-slate-500 mt-1">
                        Tags: {commentary.tags.map(tag => (
                          <span key={tag} className="mr-1.5 px-1.5 py-0.5 bg-slate-200 text-slate-700 rounded-full text-xs">{tag}</span>
                        ))}
                      </p>
                    )}
                  </div>
                  <div className="flex space-x-2 flex-shrink-0 mt-1">
                    <button 
                      onClick={() => handleOpenEditCommentaryModal(commentary)} 
                      className="text-yellow-500 hover:text-yellow-700 p-1 rounded-full hover:bg-yellow-100" 
                      title="Edit Commentary"
                    >
                      <PencilIcon className="w-5 h-5"/>
                    </button>
                    <button 
                      onClick={() => alert(`Viewing details for: ${commentary.title}\n(Full view not implemented, sections: ${commentary.sections.map(s => s.title).join(', ')})`)}
                      className="text-sky-600 hover:text-sky-800 p-1 rounded-full hover:bg-sky-100" 
                      title="View Details"
                    >
                      <EyeIcon className="w-5 h-5"/>
                    </button>
                  </div>
                </div>
                <div className="mt-2 text-xs text-slate-600">
                  <p className="font-medium">Summary of first section ({commentary.sections[0]?.title || 'Content'}):</p>
                  <p className="italic truncate">{commentary.sections[0]?.userContent || 'No content.'}</p>
                   {commentary.sections[0]?.aiSuggestion && (
                    <p className="text-xs text-sky-600 mt-1 flex items-center">
                        <LightbulbIcon className="w-3 h-3 mr-1 text-yellow-500" />
                        <span className="font-medium">AI Placeholder:</span>&nbsp;
                        <span className="italic truncate">{commentary.sections[0].aiSuggestion.substring(0,100)}...</span>
                    </p>
                   )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 text-center py-4">No commentaries found for the current filter criteria.</p>
        )}
      </DashboardCard>

      {isEditorOpen && (
        <CommentaryEditorModal
          isOpen={isEditorOpen}
          onClose={handleCloseModal}
          onSave={handleSave}
          businessArea={currentBusinessArea}
          existingCommentary={editingCommentary}
          template={selectedTemplate}
        />
      )}
    </div>
  );
};

export default CommentaryPage;
