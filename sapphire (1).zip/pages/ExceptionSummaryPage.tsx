import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Exception, ExceptionCategory, ExceptionStatus, ContextMenuItemType, Adjustment, AdjustmentType } from '../types';
import DashboardCard from '../components/DashboardCard';
import { EyeIcon, AdjustmentIcon, CheckCircleIcon, LightbulbIcon } from '../components/icons';
import ExceptionDetailModal from '../components/ExceptionDetailModal';
import ContextMenu from '../components/ContextMenu'; 
import AdjustmentModal from '../components/AdjustmentModal';
import StatusPill from '../components/StatusPill';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const getCategoryStyle = (category: ExceptionCategory) => {
    switch (category) {
        case ExceptionCategory.FOBO: return "border-red-500 bg-red-50";
        case ExceptionCategory.VRS: return "border-yellow-500 bg-yellow-50";
        case ExceptionCategory.DOD: return "border-purple-500 bg-purple-50";
        case ExceptionCategory.ATTRIBUTION: return "border-indigo-500 bg-indigo-50";
        case ExceptionCategory.CUSTOM_RULES: return "border-teal-500 bg-teal-50";
        default: return "border-gray-300 bg-gray-50";
    }
};

interface ExceptionRowProps {
    exception: Exception;
    isSelected: boolean;
    onToggleSelect: (id: string, checked: boolean) => void;
    onContextMenu: (event: React.MouseEvent, exception: Exception) => void;
    onViewDetails: (exception: Exception, action?: 'analyze' | 'suggest' | null) => void;
}

const ExceptionRow = React.memo(({
    exception,
    isSelected,
    onToggleSelect,
    onContextMenu,
    onViewDetails,
}: ExceptionRowProps) => {
    return (
        <tr 
            className={`hover:bg-sky-50 transition-colors cursor-pointer ${getCategoryStyle(exception.category)} border-l-4 ${isSelected ? 'bg-sky-100' : ''}`}
            onContextMenu={(e) => onContextMenu(e, exception)}
            onClick={() => onViewDetails(exception, null)}
        >
            <td className="px-4 py-3 whitespace-nowrap" onClick={e => e.stopPropagation()}>
                <input 
                    type="checkbox"
                    className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                    checked={isSelected}
                    onChange={(e) => onToggleSelect(exception.id, e.target.checked)}
                    aria-label={`Select exception ${exception.id}`}
                />
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-sky-700">{exception.id}</td>
            <td className="px-4 py-3 whitespace-normal text-sm text-slate-800 max-w-xs">
                <div className="font-medium">{exception.position.cusip}</div>
                <div className="text-xs text-slate-500">
                    {exception.position.tapsAccount} / {exception.position.currency} / {exception.position.counterparty}
                </div>
            </td>
            <td className="px-4 py-3 whitespace-normal text-sm text-slate-600 max-w-sm truncate">{exception.description}</td>
            <td className={`px-4 py-3 whitespace-nowrap text-sm text-right font-semibold ${exception.financialImpact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {exception.financialImpact.toLocaleString(undefined, {style:'currency', currency: exception.position.currency})}
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm">
                <StatusPill status={exception.status} />
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 hidden sm:table-cell">{exception.assignedTo || 'Unassigned'}</td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-center">
                <div className="flex items-center justify-center space-x-1">
                    <button 
                        onClick={(e) => { e.stopPropagation(); onViewDetails(exception, 'analyze'); }}
                        className="p-1 text-sky-600 hover:text-sky-800 rounded-full hover:bg-sky-100 transition-colors"
                        title="Analyze Root Cause & Investigation"
                    >
                        <LightbulbIcon className="w-5 h-5" />
                    </button>
                    <button 
                        onClick={(e) => { e.stopPropagation(); onViewDetails(exception, 'suggest'); }}
                        className="p-1 text-indigo-600 hover:text-indigo-800 rounded-full hover:bg-indigo-100 transition-colors"
                        title="Generate Suggestive Adjustment"
                    >
                        <AdjustmentIcon className="w-5 h-5" />
                    </button>
                </div>
            </td>
        </tr>
    );
});


const ExceptionSummaryPage: React.FC = () => {
    const { 
        setCurrentPageTitle, 
        exceptions, 
        updateException, 
        saveAdjustment,
        currentBusinessArea,
        currentRegion,
        currentProductLineId,
        currentStrategyId
    } = useAppContext();

    const [statusFilter, setStatusFilter] = useState<ExceptionStatus | 'ALL'>('ALL');
    const [categoryFilter, setCategoryFilter] = useState<ExceptionCategory | 'ALL'>('ALL');

    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
    const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
    const [selectedException, setSelectedException] = useState<Exception | null>(null);
    const [actionToTrigger, setActionToTrigger] = useState<'analyze' | 'suggest' | null>(null);
    const [adjustmentForModal, setAdjustmentForModal] = useState<Adjustment | null>(null);
    const [isAiGeneratedAdjustment, setIsAiGeneratedAdjustment] = useState(false);

    const [contextMenu, setContextMenu] = useState<{ visible: boolean; x: number; y: number; exception: Exception | null }>({ visible: false, x: 0, y: 0, exception: null });
    
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    
    useEffect(() => {
        setCurrentPageTitle('Exception Summary');
    }, [setCurrentPageTitle]);
    
    useEffect(() => {
        setSelectedIds([]);
    }, [currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId, statusFilter, categoryFilter]);
    
    const filteredExceptions = useMemo(() => {
        return exceptions.filter(ex => 
            ex.businessArea === currentBusinessArea &&
            (currentRegion === 'ALL' || ex.region === currentRegion) &&
            (currentProductLineId === 'ALL' || ex.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || ex.strategyId === currentStrategyId) &&
            (statusFilter === 'ALL' || ex.status === statusFilter) &&
            (categoryFilter === 'ALL' || ex.category === categoryFilter)
        );
    }, [exceptions, currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId, statusFilter, categoryFilter]);

    const handleOpenDetailModal = useCallback((exception: Exception, action: 'analyze' | 'suggest' | null = null) => {
        setSelectedException(exception);
        setActionToTrigger(action);
        setIsDetailModalOpen(true);
        closeContextMenu();
    }, []);
    
    const handleOpenAdjustmentModal = useCallback((exception: Exception, prefilledAdjustment: Adjustment) => {
        setSelectedException(exception);
        setAdjustmentForModal(prefilledAdjustment);
        setIsAdjustmentModalOpen(true);
        setIsAiGeneratedAdjustment(true);
        closeContextMenu();
    }, []);

    const handleSaveAdjustment = (adjustment: Adjustment) => {
        saveAdjustment(adjustment);
        if (adjustment.relatedExceptionId) {
            const exceptionToUpdate = exceptions.find(ex => ex.id === adjustment.relatedExceptionId);
            if (exceptionToUpdate) {
                updateException({ ...exceptionToUpdate, status: ExceptionStatus.PENDING_ADJUSTMENT });
            }
        }
        setIsAdjustmentModalOpen(false);
        setSelectedException(null);
        setAdjustmentForModal(null);
        setIsAiGeneratedAdjustment(false);
    };

    const handleAnalyzeRca = useCallback(async (exception: Exception): Promise<string> => {
        if (!process.env.API_KEY) return "API Key not configured. Cannot perform analysis.";
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `Provide a concise root cause analysis and suggest next investigation steps for this financial exception. Focus on the most likely cause. Exception: ${JSON.stringify(exception, null, 2)}`;

            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: prompt,
            });

            return response.text;
        } catch (error) {
            console.error("Error analyzing RCA:", error);
            return "An error occurred while analyzing the root cause.";
        }
    }, []);

    const handleSuggestAdjustment = useCallback(async (exception: Exception): Promise<any> => {
        if (!process.env.API_KEY) return null;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const validAdjustmentTypes = Object.values(AdjustmentType).join(', ');
            const prompt = `
              Based on this exception, propose a financial adjustment as a raw JSON object. The amount should counteract the financial impact.
              Valid types: ${validAdjustmentTypes}.
              JSON keys: "type", "amount", "currency", "debitAccount", "creditAccount", "justification".
              Exception: ${JSON.stringify(exception, null, 2)}
            `;

            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });

            let jsonStr = response.text.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = jsonStr.match(fenceRegex);
            if (match && match[2]) {
              jsonStr = match[2].trim();
            }
            return JSON.parse(jsonStr);
        } catch (error) {
            console.error("Error suggesting adjustment:", error);
            return { justification: "Error generating suggestion." };
        }
    }, []);

    const handleToggleSelectOne = useCallback((id: string, checked: boolean) => {
        setSelectedIds(prev => checked ? [...prev, id] : prev.filter(selId => selId !== id));
    }, []);

    const handleToggleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedIds(e.target.checked ? filteredExceptions.map(ex => ex.id) : []);
    };

    const isAllSelected = selectedIds.length > 0 && selectedIds.length === filteredExceptions.length;

    const closeContextMenu = () => {
        setContextMenu({ visible: false, x: 0, y: 0, exception: null });
    };

    const handleContextMenu = (event: React.MouseEvent, exception: Exception) => {
        event.preventDefault();
        setContextMenu({ visible: true, x: event.clientX, y: event.clientY, exception });
    };

    const getContextMenuItems = (exception: Exception): ContextMenuItemType[] => [
        { label: 'View Details & AI Actions', icon: EyeIcon, onClick: () => handleOpenDetailModal(exception) },
        { label: 'Mark as Resolved', icon: CheckCircleIcon, onClick: () => updateException({...exception, status: ExceptionStatus.RESOLVED}), disabled: exception.status === 'Resolved' },
    ];
    
    return (
        <div className="space-y-6">
            <DashboardCard title="Exceptions Workbench">
                <div className="flex flex-col md:flex-row justify-between md:items-center space-y-4 md:space-y-0">
                    <div className="flex space-x-2 border-b border-slate-200 pb-2 md:border-b-0 md:pb-0 overflow-x-auto">
                        {(['ALL', ...Object.values(ExceptionCategory)]).map(cat => (
                            <button
                                key={cat}
                                onClick={() => setCategoryFilter(cat as ExceptionCategory | 'ALL')}
                                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${categoryFilter === cat ? 'bg-sky-700 text-white shadow' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                     <select
                        value={statusFilter}
                        onChange={e => setStatusFilter(e.target.value as ExceptionStatus | 'ALL')}
                        className="form-select px-3 py-2 text-sm text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition"
                    >
                        <option value="ALL">All Statuses</option>
                         {Object.values(ExceptionStatus).map(stat => <option key={stat} value={stat}>{stat}</option>)}
                    </select>
                </div>
            </DashboardCard>
            
            <DashboardCard title="Filtered Exceptions">
                <div className="overflow-x-auto rounded-lg border border-slate-200">
                    <table className="min-w-full divide-y divide-slate-200">
                        <thead className="bg-slate-100">
                            <tr>
                                <th className="px-4 py-3 w-12">
                                    <input type="checkbox" onChange={handleToggleSelectAll} checked={isAllSelected} className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500" />
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">ID</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Position</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Description</th>
                                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Impact</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden sm:table-cell">Assigned</th>
                                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">AI Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-200">
                            {filteredExceptions.map(exception => (
                                <ExceptionRow
                                    key={exception.id}
                                    exception={exception}
                                    isSelected={selectedIds.includes(exception.id)}
                                    onToggleSelect={handleToggleSelectOne}
                                    onContextMenu={handleContextMenu}
                                    onViewDetails={handleOpenDetailModal}
                                />
                            ))}
                        </tbody>
                    </table>
                     {filteredExceptions.length === 0 && <p className="text-center p-8 text-slate-500">No exceptions match the current filters.</p>}
                </div>
            </DashboardCard>

            {isDetailModalOpen && selectedException && (
                <ExceptionDetailModal
                    isOpen={isDetailModalOpen}
                    onClose={() => setIsDetailModalOpen(false)}
                    exception={selectedException}
                    onOpenAdjustmentModal={handleOpenAdjustmentModal}
                    onAnalyzeRca={handleAnalyzeRca}
                    onSuggestAdjustment={handleSuggestAdjustment}
                    actionToTrigger={actionToTrigger}
                />
            )}

            {isAdjustmentModalOpen && (
                <AdjustmentModal
                    isOpen={isAdjustmentModalOpen}
                    onClose={() => {
                        setIsAdjustmentModalOpen(false);
                        setAdjustmentForModal(null);
                        setIsAiGeneratedAdjustment(false);
                    }}
                    onSave={handleSaveAdjustment}
                    exception={selectedException}
                    existingAdjustment={adjustmentForModal}
                    businessArea={currentBusinessArea}
                    isAiGenerated={isAiGeneratedAdjustment}
                />
            )}
            
            {contextMenu.visible && contextMenu.exception && (
                <ContextMenu
                    isOpen={contextMenu.visible}
                    x={contextMenu.x}
                    y={contextMenu.y}
                    items={getContextMenuItems(contextMenu.exception)}
                    onClose={closeContextMenu}
                />
            )}
        </div>
    );
};

export default ExceptionSummaryPage;
