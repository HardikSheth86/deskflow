import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { PreSignOffTask, PreSignOffTaskStatus, ContextMenuItemType, AdjustmentType, Adjustment } from '../types';
import { MOCK_PRE_SIGN_OFF_ACTIONS_BY_AREA } from '../constants';
import { 
    CheckCircleIcon, 
    EyeIcon,
    PlusCircleIcon,
    ShareIcon,
    PencilIcon,
    ListBulletIcon,
    CloseIcon,
} from '../components/icons';
import PreSignOffTaskDetailModal from '../components/PreSignOffTaskDetailModal';
import AdjustmentModal from '../components/AdjustmentModal';
import ContextMenu from '../components/ContextMenu';
import PreSignOffBreakdownView from '../components/PreSignOffBreakdownView';
import StatusPill from '../components/StatusPill';

const getTaskRowStyle = (status: PreSignOffTaskStatus) => {
    switch (status) {
      case PreSignOffTaskStatus.COMPLETED_OK: return "border-green-500 bg-green-50";
      case PreSignOffTaskStatus.COMPLETED_BREAKS: return "border-yellow-500 bg-yellow-50";
      case PreSignOffTaskStatus.IN_PROGRESS: return "border-sky-500 bg-sky-50";
      case PreSignOffTaskStatus.FAILED:
      case PreSignOffTaskStatus.REQUIRES_ATTENTION: return "border-red-500 bg-red-50";
      case PreSignOffTaskStatus.ACKNOWLEDGED: return "border-indigo-500 bg-indigo-50";
      case PreSignOffTaskStatus.PENDING:
      default: return "border-slate-300 bg-slate-50";
    }
};

/**
 * A memoized component for rendering a single row in the pre-sign-off tasks table.
 * This prevents re-rendering of rows that haven't changed, improving performance.
 */
const TaskRow = React.memo(({
    task,
    isSelected,
    onToggleSelect,
    onContextMenu,
    onViewDetails,
}: {
    task: PreSignOffTask;
    isSelected: boolean;
    onToggleSelect: (id: string, checked: boolean) => void;
    onContextMenu: (event: React.MouseEvent, task: PreSignOffTask) => void;
    onViewDetails: (task: PreSignOffTask) => void;
}) => {
    return (
        <tr 
            className={`hover:bg-sky-50 transition-colors ${getTaskRowStyle(task.status)} border-l-4 cursor-context-menu ${isSelected ? 'bg-sky-100' : ''}`}
            onContextMenu={(e) => onContextMenu(e, task)}
        >
            <td className="px-4 py-3 whitespace-nowrap">
                <input 
                    type="checkbox"
                    className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                    checked={isSelected}
                    onChange={(e) => onToggleSelect(task.id, e.target.checked)}
                    aria-label={`Select task ${task.id}`}
                />
            </td>
            <td className="px-4 py-3 whitespace-normal text-sm font-medium text-sky-700 max-w-xs">{task.title}</td>
            <td className="px-4 py-3 whitespace-nowrap text-sm">
                <StatusPill status={task.status} />
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 text-center">
                {task.breakCount !== undefined && task.breakCount > 0 
                    ? <span className="font-semibold text-red-600">{task.breakCount}</span> 
                    : task.status === PreSignOffTaskStatus.COMPLETED_OK ? <CheckCircleIcon className="w-5 h-5 text-green-500 mx-auto" /> : '-'}
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600">{task.assignedToUser || task.responsibleTeam || 'N/A'}</td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 hidden sm:table-cell">{task.lastRun ? new Date(task.lastRun).toLocaleString() : 'N/A'}</td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-center">
                <button onClick={() => onViewDetails(task)} className="text-sky-600 hover:text-sky-800 p-1 rounded-full hover:bg-sky-100" title="View/Edit Details">
                    <EyeIcon className="w-5 h-5"/>
                </button>
                <button onClick={() => onViewDetails(task)} className="text-yellow-500 hover:text-yellow-700 p-1 rounded-full hover:bg-yellow-100" title="Assign Task">
                    <PencilIcon className="w-5 h-5"/>
                </button>
            </td>
        </tr>
    );
});


const PreSignOffPage: React.FC = () => {
  const { 
    currentBusinessArea, 
    setCurrentPageTitle, 
    preSignOffTasksByArea, 
    updatePreSignOffTask,
    saveAdjustment,
    currentRegion,
    currentProductLineId,
    currentStrategyId
  } = useAppContext();
  
  const allTasksForArea = useMemo(() => preSignOffTasksByArea[currentBusinessArea] || [], [preSignOffTasksByArea, currentBusinessArea]);
  const allActionsForArea = useMemo(() => MOCK_PRE_SIGN_OFF_ACTIONS_BY_AREA[currentBusinessArea] || [], [currentBusinessArea]);
  
  const [isTaskDetailModalOpen, setIsTaskDetailModalOpen] = useState(false);
  const [selectedTaskForDetail, setSelectedTaskForDetail] = useState<PreSignOffTask | null>(null);
  
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
  const [prefilledAdjustmentType, setPrefilledAdjustmentType] = useState<AdjustmentType | undefined>(undefined);

  const [activeTeamFilter, setActiveTeamFilter] = useState<string>('ALL');
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>([]);
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    task: PreSignOffTask | null;
  }>({ visible: false, x: 0, y: 0, task: null });
  
  const [drilledDownTask, setDrilledDownTask] = useState<PreSignOffTask | null>(null);

  useEffect(() => {
    setCurrentPageTitle('Pre-Sign Off Control Center');
  }, [setCurrentPageTitle]);

  useEffect(() => {
    // Reset local page state when global filters change
    setActiveTeamFilter('ALL');
    setSelectedTaskIds([]);
    setDrilledDownTask(null);
  }, [currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId]);

  const tasks = useMemo(() => {
    return allTasksForArea.filter(task =>
      (currentRegion === 'ALL' || task.region === currentRegion) &&
      (currentProductLineId === 'ALL' || task.productLineId === currentProductLineId || task.productLineId === 'ALL') &&
      (currentStrategyId === 'ALL' || task.strategyId === currentStrategyId || task.strategyId === 'ALL')
    );
  }, [allTasksForArea, currentRegion, currentProductLineId, currentStrategyId]);

  const actions = useMemo(() => allActionsForArea, [allActionsForArea]);

  const responsibleTeams = useMemo(() => {
      const teams = new Set(tasks.map(t => t.responsibleTeam).filter(Boolean) as string[]);
      return ['ALL', ...Array.from(teams)];
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    return tasks.filter(task => 
      activeTeamFilter === 'ALL' || task.responsibleTeam === activeTeamFilter
    );
  }, [tasks, activeTeamFilter]);

  useEffect(() => {
    setSelectedTaskIds([]);
    setDrilledDownTask(null);
  }, [activeTeamFilter]);
  
  const handleUpdateTaskAndModal = useCallback((updatedTask: PreSignOffTask) => {
    updatePreSignOffTask(updatedTask);
    if(selectedTaskForDetail && selectedTaskForDetail.id === updatedTask.id) {
        setSelectedTaskForDetail(updatedTask);
    }
  }, [selectedTaskForDetail, updatePreSignOffTask]);

  const handleOpenTaskDetailModal = useCallback((task: PreSignOffTask) => {
    setSelectedTaskForDetail(task);
    setIsTaskDetailModalOpen(true);
    closeContextMenu();
  }, []);
  
  const handleOpenAdjustmentModal = (type: AdjustmentType) => {
    setPrefilledAdjustmentType(type);
    setIsAdjustmentModalOpen(true);
  };

  const handleSaveAndCloseAdjustment = useCallback((adjustment: Adjustment) => {
    saveAdjustment(adjustment);
    alert(`Adjustment ${adjustment.id} for type ${adjustment.type} has been ${adjustment.status.toLowerCase()}.`);
    setIsAdjustmentModalOpen(false);
    setPrefilledAdjustmentType(undefined);
  }, [saveAdjustment]);


  const handleToggleSelectAll = (isChecked: boolean) => {
    setSelectedTaskIds(isChecked ? filteredTasks.map(t => t.id) : []);
  };

  const handleToggleSelectOne = useCallback((taskId: string, isChecked: boolean) => {
    setSelectedTaskIds(prev => isChecked ? [...prev, taskId] : prev.filter(id => id !== taskId));
  }, []);
  
  const isAllSelected = useMemo(() => {
    return filteredTasks.length > 0 && selectedTaskIds.length === filteredTasks.length;
  }, [filteredTasks, selectedTaskIds]);

  const handleBulkAction = (action: string) => {
    if (selectedTaskIds.length === 0) {
      alert("Please select one or more tasks to perform a bulk action.");
      return;
    }
    
    if (action === 'Assign to User') {
      alert(`Bulk Assign Action for tasks: ${selectedTaskIds.join(', ')}\n(Simulated: Would assign these to a chosen user/team.)`);
    } else if (action === 'Acknowledge Selected') {
        const tasksToUpdate = tasks.filter(task => 
            selectedTaskIds.includes(task.id) && task.status !== PreSignOffTaskStatus.COMPLETED_OK
        ).map(task => ({ ...task, status: PreSignOffTaskStatus.ACKNOWLEDGED }));
        
        tasksToUpdate.forEach(updatePreSignOffTask);
        
        alert(`Acknowledged tasks: ${selectedTaskIds.join(', ')}.`);
        setSelectedTaskIds([]);
    }
  };
  
  const closeContextMenu = () => {
    setContextMenu({ visible: false, x: 0, y: 0, task: null });
  };
  
  const handleContextMenu = useCallback((event: React.MouseEvent, task: PreSignOffTask) => {
    event.preventDefault();
    setContextMenu({
      visible: true,
      x: event.clientX,
      y: event.clientY,
      task: task,
    });
  }, []);

  const handleShowBreaksDrillDown = (task: PreSignOffTask) => {
    setDrilledDownTask(task);
    closeContextMenu();
  };
  
  const getContextMenuItems = (task: PreSignOffTask): ContextMenuItemType[] => [
    { label: "View/Edit Details (Modal)", icon: EyeIcon, onClick: () => handleOpenTaskDetailModal(task) },
    { label: "Acknowledge Task", icon: CheckCircleIcon, 
      onClick: () => updatePreSignOffTask({...task, status: PreSignOffTaskStatus.ACKNOWLEDGED}),
      disabled: task.status === PreSignOffTaskStatus.ACKNOWLEDGED || task.status === PreSignOffTaskStatus.COMPLETED_OK
    },
    { isSeparator: true },
    { label: `Drill-down: Related Breaks (${task.breakCount || 0})`, icon: ListBulletIcon, 
      onClick: () => handleShowBreaksDrillDown(task),
      disabled: !task.breakCount || task.breakCount === 0 
    },
  ];


  return (
    <div className="space-y-6">
       <DashboardCard title="Create Pre-Sign Off Adjustment">
        <p className="text-slate-600 mb-4">
          Create specialized adjustments required before the sign-off can be completed.
        </p>
        {actions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {actions.map(action => (
              <div key={action.id} className="p-4 border border-slate-200 rounded-lg bg-white hover:shadow-lg transition-shadow flex flex-col justify-between">
                <div>
                  <h3 className="text-md font-semibold text-sky-700 mb-1 flex items-center">
                    <action.icon className="w-5 h-5 mr-2" />
                    {action.title}
                  </h3>
                  <p className="text-xs text-slate-500 mb-3">{action.description}</p>
                </div>
                <button
                  onClick={() => handleOpenAdjustmentModal(action.adjustmentType)}
                  className="w-full mt-2 px-3 py-1.5 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center justify-center"
                >
                  <PlusCircleIcon className="w-4 h-4 mr-2" />
                  Create Adjustment
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 text-center py-4">No pre-sign off adjustment types configured for {currentBusinessArea}.</p>
        )}
      </DashboardCard>

      <DashboardCard title="Pre-Sign Off Checks">
        <div className="mb-4 flex space-x-2 border-b border-slate-200 pb-2 overflow-x-auto">
          {responsibleTeams.map(team => (
            <button
                key={team}
                onClick={() => setActiveTeamFilter(team)}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${activeTeamFilter === team ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
                {team} ({team === 'ALL' ? tasks.length : tasks.filter(t => t.responsibleTeam === team).length})
            </button>
          ))}
        </div>

        <div className="flex justify-between items-center mb-4">
            <p className="text-slate-600 text-sm">
              Showing {filteredTasks.length} tasks. Selected: {selectedTaskIds.length}. Right-click for more options.
            </p>
            <div className="flex space-x-2">
                <button 
                    onClick={() => handleBulkAction('Assign to User')}
                    disabled={selectedTaskIds.length === 0}
                    className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <ShareIcon className="w-4 h-4 mr-1.5" /> Bulk Assign
                </button>
                 <button 
                    onClick={() => handleBulkAction('Acknowledge Selected')}
                    disabled={selectedTaskIds.length === 0}
                    className="px-3 py-1.5 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <CheckCircleIcon className="w-4 h-4 mr-1.5" /> Bulk Acknowledge
                </button>
            </div>
        </div>

        {filteredTasks.length > 0 ? (
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-100">
                <tr>
                   <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider w-12">
                    <input 
                      type="checkbox"
                      className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                      checked={isAllSelected}
                      onChange={(e) => handleToggleSelectAll(e.target.checked)}
                      aria-label="Select all tasks"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Task</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">Breaks</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Assigned To</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden sm:table-cell">Last Run</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredTasks.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    isSelected={selectedTaskIds.includes(task.id)}
                    onToggleSelect={handleToggleSelectOne}
                    onContextMenu={handleContextMenu}
                    onViewDetails={handleOpenTaskDetailModal}
                  />
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-slate-500 text-center py-8">No pre-sign off checks to display for the current filter.</p>
        )}
      </DashboardCard>
      
      {drilledDownTask && (
        <DashboardCard
            title={`Breakdown for Task: ${drilledDownTask.title}`}
            className="mt-6"
            actions={
            <button 
                onClick={() => setDrilledDownTask(null)}
                className="text-slate-500 hover:text-slate-700 p-1 rounded-full"
                aria-label="Close drill-down view"
            >
                <CloseIcon className="w-5 h-5" />
            </button>
            }
        >
            <PreSignOffBreakdownView task={drilledDownTask} />
        </DashboardCard>
      )}

      {isTaskDetailModalOpen && selectedTaskForDetail && (
        <PreSignOffTaskDetailModal
            isOpen={isTaskDetailModalOpen}
            onClose={() => { setSelectedTaskForDetail(null); setIsTaskDetailModalOpen(false);}}
            task={selectedTaskForDetail}
            onUpdateTask={handleUpdateTaskAndModal}
        />
      )}

      {isAdjustmentModalOpen && (
        <AdjustmentModal 
          isOpen={isAdjustmentModalOpen}
          onClose={() => setIsAdjustmentModalOpen(false)}
          onSave={handleSaveAndCloseAdjustment}
          businessArea={currentBusinessArea}
          prefilledType={prefilledAdjustmentType}
        />
      )}

      {contextMenu.visible && contextMenu.task && (
        <ContextMenu
          isOpen={contextMenu.visible}
          x={contextMenu.x}
          y={contextMenu.y}
          items={getContextMenuItems(contextMenu.task)}
          onClose={closeContextMenu}
        />
      )}
    </div>
  );
};

export default PreSignOffPage;
