import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { MOCK_INVESTIGATIVE_TRADES } from '../constants';
import { InvestigativeTrade } from '../types';
import DashboardCard from '../components/DashboardCard';
import { MagnifyingGlassIcon, CpuChipIcon } from '../components/icons';
import StatusPill from '../components/StatusPill';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const InvestigationPage: React.FC = () => {
    const { 
        setCurrentPageTitle, 
        currentBusinessArea, 
        currentRegion, 
        currentProductLineId, 
        currentStrategyId 
    } = useAppContext();
    
    const [allTrades] = useState<InvestigativeTrade[]>(MOCK_INVESTIGATIVE_TRADES);
    const [nlpQuery, setNlpQuery] = useState('Show all booked trades for AAPL with quantity over 5000');
    const [filterObject, setFilterObject] = useState<any>({});
    const [isThinking, setIsThinking] = useState(false);
    
    useEffect(() => {
        setCurrentPageTitle('Investigation Workbench');
    }, [setCurrentPageTitle]);

    const tradesForCurrentContext = useMemo(() => {
        return allTrades.filter(trade => 
            trade.businessArea === currentBusinessArea &&
            (currentRegion === 'ALL' || trade.region === currentRegion) &&
            (currentProductLineId === 'ALL' || trade.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || trade.strategyId === currentStrategyId)
        );
    }, [allTrades, currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId]);

    const handleNlpQuery = async () => {
        if (!process.env.API_KEY || !nlpQuery) return;
        setIsThinking(true);
        setFilterObject({});

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `
              You are a data filtering assistant for financial trades. The user will provide a natural language query.
              You must convert this into a JSON filter object.
              The available fields for filtering are: 'id' (string, partial match), 'product' (string, partial match),
              'minQuantity' (number), 'maxQuantity' (number), 'minPrice' (number), 'maxPrice' (number), 'currency' (string, exact match),
              'status' (string, exact match 'Booked'|'Amended'|'Cancelled'), 'traderId' (string, partial match),
              'salesperson' (string, partial match), 'counterparty' (string, partial match),
              'bookingSystem' (string, from tradeCapture, 'TradeMaster'|'BookItAll').
              Your response MUST be a single, raw JSON object with NO markdown fences.
              If a field is not specified in the query, do not include it in the JSON.

              User Query: "${nlpQuery}"
            `;
            
            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });

            let jsonStr = response.text.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = jsonStr.match(fenceRegex);
            if (match && match[2]) {
              jsonStr = match[2].trim();
            }
            setFilterObject(JSON.parse(jsonStr));

        } catch (error) {
            console.error("Error processing NLP query:", error);
            alert("Sorry, I could not understand that query. Please try rephrasing it.");
        } finally {
            setIsThinking(false);
        }
    };

    const filteredTrades = useMemo(() => {
        if (Object.keys(filterObject).length === 0) {
            return tradesForCurrentContext;
        }

        return tradesForCurrentContext.filter(trade => {
            return Object.entries(filterObject).every(([key, value]) => {
                if (value === null || value === undefined || value === "") return true;
                
                switch (key) {
                    case 'id': return trade.id.toLowerCase().includes((value as string).toLowerCase());
                    case 'product': return trade.product.toLowerCase().includes((value as string).toLowerCase());
                    case 'minQuantity': return trade.quantity >= Number(value);
                    case 'maxQuantity': return trade.quantity <= Number(value);
                    case 'minPrice': return trade.price >= Number(value);
                    case 'maxPrice': return trade.price <= Number(value);
                    case 'currency': return trade.currency.toLowerCase() === (value as string).toLowerCase();
                    case 'status': return trade.status.toLowerCase() === (value as string).toLowerCase();
                    case 'traderId': return trade.tradeCapture.traderId.toLowerCase().includes((value as string).toLowerCase());
                    case 'salesperson': return trade.tradeCapture.salesperson.toLowerCase().includes((value as string).toLowerCase());
                    case 'counterparty': return trade.counterparty.toLowerCase().includes((value as string).toLowerCase());
                    case 'bookingSystem': return trade.tradeCapture.bookingSystem.toLowerCase() === (value as string).toLowerCase();
                    default: return true;
                }
            });
        });
    }, [tradesForCurrentContext, filterObject]);

    useEffect(() => {
        handleNlpQuery();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="space-y-6">
            <DashboardCard title={<div className="flex items-center"><CpuChipIcon className="w-6 h-6 mr-2" />Natural Language Query</div>}>
                <p className="text-slate-600 mb-4">
                    Type a question or command in plain English to filter the trades below. The AI will translate your request into a data filter.
                </p>
                <div className="flex space-x-2">
                    <input 
                        type="text" 
                        placeholder="e.g., Show all amended trades for product US10YT=RR"
                        value={nlpQuery} 
                        onChange={(e) => setNlpQuery(e.target.value)} 
                        onKeyDown={e => e.key === 'Enter' && handleNlpQuery()} 
                        className="w-full p-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                    />
                    <button onClick={handleNlpQuery} disabled={isThinking} className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 flex items-center disabled:opacity-50">
                       <MagnifyingGlassIcon className="w-5 h-5 mr-2" /> {isThinking ? 'Thinking...' : 'Run Query'}
                    </button>
                </div>
                 {Object.keys(filterObject).length > 0 && (
                    <div className="mt-2 text-xs text-slate-500 p-2 bg-slate-100 rounded-md">
                        <strong>Active Filter JSON:</strong> {JSON.stringify(filterObject)}
                    </div>
                )}
            </DashboardCard>

            <DashboardCard title={`Investigation Results (${filteredTrades.length} trades)`}>
                <div className="overflow-x-auto rounded-lg border border-slate-200 max-h-[65vh]">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-100 sticky top-0">
                            <tr>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Trade ID</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Product</th>
                                <th className="px-3 py-2 text-right font-semibold text-slate-600">Quantity</th>
                                <th className="px-3 py-2 text-right font-semibold text-slate-600">Price</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Status</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Trader</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600 hidden md:table-cell">Counterparty</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600 hidden lg:table-cell">Settlement</th>
                            </tr>
                        </thead>
                         <tbody className="bg-white divide-y divide-slate-100">
                            {filteredTrades.map(trade => (
                                <tr key={trade.id} className="hover:bg-slate-50">
                                    <td className="px-3 py-2 whitespace-nowrap font-medium text-sky-700">{trade.id}</td>
                                    <td className="px-3 py-2 whitespace-nowrap">{trade.product}</td>
                                    <td className="px-3 py-2 whitespace-nowrap text-right">{trade.quantity.toLocaleString()}</td>
                                    <td className="px-3 py-2 whitespace-nowrap text-right">{trade.price.toLocaleString('en-US', { style: 'currency', currency: trade.currency })}</td>
                                    <td className="px-3 py-2 whitespace-nowrap"><StatusPill status={trade.status} /></td>
                                    <td className="px-3 py-2 whitespace-nowrap">{trade.tradeCapture.traderId}</td>
                                    <td className="px-3 py-2 whitespace-nowrap hidden md:table-cell">{trade.counterparty}</td>
                                    <td className="px-3 py-2 whitespace-nowrap hidden lg:table-cell">{trade.ops.settlementDate}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {filteredTrades.length === 0 && (
                        <div className="text-center p-8 text-slate-500">
                            <p>No trades match your query or the current global filters.</p>
                            <p className="text-xs mt-1">Try a different query or adjust the Business Area/Region filters.</p>
                        </div>
                    )}
                </div>
            </DashboardCard>
        </div>
    );
};

export default InvestigationPage;