
import React from 'react';
import { ReportItem } from '../pages/AnalyticsPage'; // Adjust path as necessary
import { CloseIcon, SendIcon, DocumentReportIcon } from './icons';

interface FullScreenReportViewerProps {
  report: ReportItem;
  onClose: () => void;
  onSend: (report: ReportItem) => void;
}

const FullScreenReportViewer: React.FC<FullScreenReportViewerProps> = ({ report, onClose, onSend }) => {
  return (
    <div className="fixed inset-0 bg-slate-800 bg-opacity-95 backdrop-blur-sm z-[100] flex flex-col p-4 sm:p-6 md:p-8 animate-fadeIn">
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out forwards;
        }
      `}</style>
      {/* Header Bar */}
      <div className="flex justify-between items-center mb-4 text-white flex-shrink-0">
        <div className="flex items-center">
          <DocumentReportIcon className="w-7 h-7 mr-3 text-sky-400" />
          <h2 className="text-xl sm:text-2xl font-semibold">{report.title}</h2>
        </div>
        <div className="flex items-center space-x-3">
            <button
                onClick={() => onSend(report)}
                className="px-3 py-1.5 sm:px-4 sm:py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors text-xs sm:text-sm font-medium flex items-center"
                aria-label={`Send ${report.title}`}
            >
                <SendIcon className="w-4 h-4 mr-1.5" />
                Send this Report
            </button>
            <button
                onClick={onClose}
                className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-full transition-colors"
                aria-label="Close full screen report viewer"
            >
                <CloseIcon className="w-6 h-6 sm:w-7 sm:h-7" />
            </button>
        </div>
      </div>

      {/* Content Area (Iframe or Fallback) */}
      <div className="flex-grow bg-slate-200 rounded-lg shadow-2xl overflow-hidden">
        {report.powerBiEmbedUrl ? (
          <iframe
            title={report.title}
            src={report.powerBiEmbedUrl}
            frameBorder="0"
            allowFullScreen={true}
            className="w-full h-full"
          ></iframe>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-white">
            <DocumentReportIcon className="w-16 h-16 text-slate-400 mb-4" />
            <h3 className="text-xl font-semibold text-slate-700 mb-2">Report Preview Not Available</h3>
            <p className="text-slate-500">
              A Power BI embed URL has not been configured for this report ("{report.title}").
            </p>
            <p className="text-slate-500 mt-1">
              In a real application, if a Power BI report isn't available, a static preview or mock data could be shown here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FullScreenReportViewer;
