import React, { useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { BusinessArea, Region } from '../types';
import { ALL_BUSINESS_AREAS, ALL_REGIONS } from '../constants';

const GlobalFilters: React.FC = () => {
    const {
        currentBusinessArea,
        setCurrentBusinessArea,
        currentProductLineId,
        setCurrentProductLineId,
        currentStrategyId,
        setCurrentStrategyId,
        currentRegion,
        setCurrentRegion,
        productLinesByArea
    } = useAppContext();

    const productLinesForArea = useMemo(() => {
        return productLinesByArea[currentBusinessArea] || [];
    }, [currentBusinessArea, productLinesByArea]);

    const strategiesForProductLine = useMemo(() => {
        if (currentProductLineId === 'ALL') {
            return productLinesForArea.flatMap(pl => pl.strategies);
        }
        const selectedProductLine = productLinesForArea.find(pl => pl.id === currentProductLineId);
        return selectedProductLine ? selectedProductLine.strategies : [];
    }, [currentProductLineId, productLinesForArea]);

    const handleBusinessAreaChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setCurrentBusinessArea(e.target.value as BusinessArea);
        // Reset child filters
        setCurrentProductLineId('ALL');
        setCurrentStrategyId('ALL');
    };

    const handleProductLineChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setCurrentProductLineId(e.target.value);
        // Reset child filter
        setCurrentStrategyId('ALL');
    };
    
    const inputStyles = "w-full p-2 border border-slate-300 rounded-md text-sm bg-slate-50 placeholder:text-slate-500 text-slate-800 focus:bg-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors";

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div>
                <label htmlFor="global-filter-ba" className="block text-xs font-medium text-slate-600 mb-1">Business Area</label>
                <select id="global-filter-ba" value={currentBusinessArea} onChange={handleBusinessAreaChange} className={inputStyles}>
                    {ALL_BUSINESS_AREAS.map(area => <option key={area} value={area}>{area}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="global-filter-pl" className="block text-xs font-medium text-slate-600 mb-1">Product Line</label>
                <select id="global-filter-pl" value={currentProductLineId} onChange={handleProductLineChange} className={inputStyles}>
                    <option value="ALL">All Product Lines</option>
                    {productLinesForArea.map(pl => <option key={pl.id} value={pl.id}>{pl.name}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="global-filter-strat" className="block text-xs font-medium text-slate-600 mb-1">Strategy</label>
                <select id="global-filter-strat" value={currentStrategyId} onChange={(e) => setCurrentStrategyId(e.target.value)} className={inputStyles}>
                    <option value="ALL">All Strategies</option>
                    {strategiesForProductLine.map(strat => <option key={strat.id} value={strat.id}>{strat.name}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="global-filter-region" className="block text-xs font-medium text-slate-600 mb-1">Region</label>
                <select id="global-filter-region" value={currentRegion} onChange={(e) => setCurrentRegion(e.target.value as Region | 'ALL')} className={inputStyles}>
                    <option value="ALL">All Regions</option>
                    {ALL_REGIONS.map(region => <option key={region} value={region}>{region}</option>)}
                </select>
            </div>
        </div>
    );
};

export default GlobalFilters;
