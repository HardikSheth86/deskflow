
import React from 'react';

/**
 * Sidebar component. Currently not used in the main layout but implemented
 * to ensure all files are buildable.
 */
const Sidebar: React.FC = () => {
  return null;
};

export default Sidebar;
