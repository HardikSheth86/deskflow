import React, { useState } from 'react';
import { Case, CaseStatus, Exception, CaseComment } from '../types';
import StatusPill from './StatusPill';
import { formatDateDistance, formatCurrency } from '../utils/helpers';
import { ChevronDownIcon, ChevronUpIcon, PaperAirplaneIcon, UserCircleIcon, ExceptionIcon } from './icons';

interface CaseCardProps {
  caseItem: Case;
  exception: Exception | undefined;
  onUpdateCase: (updatedCase: Case) => void;
  isCurrentUserAssigned: boolean;
}

const CaseCard: React.FC<CaseCardProps> = React.memo(({ caseItem, exception, onUpdateCase, isCurrentUserAssigned }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [newComment, setNewComment] = useState('');

  const handleAddComment = () => {
    if (!newComment.trim()) return;

    const commentToAdd: CaseComment = {
      user: 'Valerie User', // Hardcoded current user
      timestamp: new Date().toISOString(),
      comment: newComment.trim(),
    };

    const updatedCase: Case = {
      ...caseItem,
      comments: [...caseItem.comments, commentToAdd],
      status: CaseStatus.IN_PROGRESS, // When user comments, move to "In Progress"
    };

    onUpdateCase(updatedCase);
    setNewComment('');
  };

  const handleCloseCase = () => {
     const commentToAdd: CaseComment = {
      user: 'Valerie User', // Hardcoded current user
      timestamp: new Date().toISOString(),
      comment: newComment.trim() || 'Case closed without additional comments.',
    };

     const updatedCase: Case = {
      ...caseItem,
      comments: [...caseItem.comments, commentToAdd],
      status: CaseStatus.CLOSED,
    };
    onUpdateCase(updatedCase);
    setNewComment('');
  }

  const isActionable = isCurrentUserAssigned && caseItem.status !== CaseStatus.CLOSED;

  return (
    <div className="bg-white shadow-md rounded-lg p-4 border-l-4 border-sky-500">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-md font-semibold text-slate-800">{caseItem.title}</h3>
          <p className="text-xs text-slate-500">
            Case #{caseItem.id} | Opened {formatDateDistance(caseItem.dateOpened)} | Assigned to: {caseItem.assignedTo}
          </p>
        </div>
        <StatusPill status={caseItem.status} />
      </div>

      {/* Linked Exception Snippet */}
      {exception && (
        <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-md text-sm">
          <div className="flex justify-between items-center">
            <p className="font-semibold text-slate-700 flex items-center">
              <ExceptionIcon className="w-4 h-4 mr-2 text-red-500" />
              Linked Exception: {exception.id}
            </p>
            <p className={`font-semibold ${exception.financialImpact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(exception.financialImpact, exception.position.currency)}
            </p>
          </div>
          <p className="text-xs text-slate-600 mt-1 italic">"{exception.description}"</p>
        </div>
      )}
      
      {/* Expander for Comments */}
      <div className="mt-3">
        <button onClick={() => setIsExpanded(!isExpanded)} className="text-sm text-sky-600 hover:text-sky-800 flex items-center">
          {isExpanded ? 'Hide' : 'Show'} Comment History ({caseItem.comments.length})
          {isExpanded ? <ChevronUpIcon className="w-4 h-4 ml-1" /> : <ChevronDownIcon className="w-4 h-4 ml-1" />}
        </button>
      </div>

      {isExpanded && (
        <div className="mt-2 space-y-3 pr-2 max-h-48 overflow-y-auto">
          {caseItem.comments.map((comment, index) => (
            <div key={index} className="flex items-start">
              <div className="flex-shrink-0 bg-slate-200 text-slate-600 p-1.5 rounded-full mr-2">
                  <UserCircleIcon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs">
                  <span className="font-semibold text-slate-700">{comment.user}</span>
                  <span className="text-slate-500 ml-2">{formatDateDistance(comment.timestamp)}</span>
                </p>
                <p className="text-sm text-slate-800 bg-slate-100 p-2 rounded-md mt-1">{comment.comment}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Action Form for Current User */}
      {isActionable && (
        <div className="mt-4 pt-3 border-t border-slate-200">
          <h4 className="text-sm font-semibold text-slate-700 mb-2">Respond or Update</h4>
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            rows={2}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500 text-sm"
            placeholder="Add a comment to update the case..."
          />
          <div className="flex justify-end space-x-2 mt-2">
            <button
                onClick={handleCloseCase}
                className="px-3 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-xs font-medium"
            >
                Mark as Closed
            </button>
            <button
                onClick={handleAddComment}
                disabled={!newComment.trim()}
                className="px-3 py-1.5 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-xs font-medium flex items-center disabled:opacity-50"
            >
                <PaperAirplaneIcon className="w-4 h-4 mr-1.5" />
                Add Comment & Update
            </button>
          </div>
        </div>
      )}
    </div>
  );
});

export default CaseCard;