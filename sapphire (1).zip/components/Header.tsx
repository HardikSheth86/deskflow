import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import GlobalFilters from './GlobalFilters';

/**
 * The main header component displayed on every page below the top navigation bar.
 * It shows the current page title and contains the global filter controls.
 * @returns {JSX.Element} The rendered header component.
 */
const Header: React.FC = () => {
  const { currentPageTitle } = useAppContext();

  return (
    <header className="bg-white shadow-sm p-4 space-y-4">
      <div className="flex justify-start items-center">
        <h1 className="text-2xl font-semibold text-slate-700">{currentPageTitle}</h1>
      </div>
      <GlobalFilters />
    </header>
  );
};

export default Header;
