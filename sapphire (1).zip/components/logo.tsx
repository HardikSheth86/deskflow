import React from 'react';

export const SapphireLogo = ({ className }: { className?: string }) => (
  <svg
    className={className}
    viewBox="0 0 100 100"
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
  >
    <defs>
      <linearGradient id="sapphireGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0F52BA" /> {/* Dark Sapphire Blue */}
        <stop offset="100%" stopColor="#87CEEB" /> {/* Sky Blue */}
      </linearGradient>
      <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
        <feMerge>
          <feMergeNode in="coloredBlur" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>
    <g filter="url(#glow)">
      <path
        d="M50 2.5 L75 25 L97.5 50 L75 75 L50 97.5 L25 75 L2.5 50 L25 25 Z"
        fill="url(#sapphireGradient)"
        stroke="#FFFFFF"
        strokeWidth="1.5"
      />
      <path
        d="M50 2.5 L50 97.5 M2.5 50 L97.5 50 M25 25 L75 75 M25 75 L75 25"
        stroke="rgba(255, 255, 255, 0.4)"
        strokeWidth="1"
      />
    </g>
  </svg>
);
