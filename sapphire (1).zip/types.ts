import React from 'react';

/**
 * Enumeration of the primary business areas within the firm.
 * @enum {string}
 */
export enum BusinessArea {
  EQUITIES = 'Equities',
  FIXED_INCOME = 'Fixed Income',
  PRIME_BROKERAGE = 'Prime Brokerage',
  COMMODITIES = 'Commodities',
  TREASURY_CAPITAL_MARKETS = 'Treasury Capital Markets',
}

/**
 * Enumeration of the primary regions.
 * @enum {string}
 */
export enum Region {
  NON_JAPAN_ASIA = 'Non Japan Asia',
  TOKYO = 'Tokyo',
  EMEA = 'EMEA',
  NORTH_AMERICA = 'North America',
}


/**
 * Represents the high-level status of a sign-off entity.
 * @enum {string}
 */
export enum ProcessStatus {
  IN_PROGRESS = 'In Progress',
  AWAITING_SIGN_OFF = 'Awaiting Sign-off',
  SIGNED_OFF = 'Signed Off',
  REJECTED = 'Rejected',
}

/**
 * Defines a single stage in the daily validation process timeline.
 * @interface ProcessStage
 * @property {string} id - The unique identifier for the stage.
 * @property {string} name - The human-readable name of the stage.
 * @property {string | null} completedAt - The timestamp when the stage was completed, or null if not yet completed.
 * @property {'pending' | 'in-progress' | 'completed' | 'failed'} status - The current status of the stage.
 */
export interface ProcessStage {
  id: string;
  name: string;
  completedAt: string | null;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
}

/**
 * Represents a Key Performance Indicator (KPI) displayed on the dashboard.
 * @interface KPI
 * @property {string} label - The name of the KPI (e.g., "Total Assets").
 * @property {string} value - The current value of the KPI, formatted as a string.
 * @property {string} variance - The change from the previous period, formatted as a string.
 * @property {'positive' | 'negative' | 'neutral'} varianceType - Determines the color-coding of the variance display.
 */
export interface KPI {
  label: string;
  value: string;
  variance: string;
  varianceType: 'positive' | 'negative' | 'neutral';
}

/**
 * Enumeration of the categories for financial exceptions.
 * @enum {string}
 */
export enum ExceptionCategory {
  FOBO = 'FOBO',
  VRS = 'VRS',
  DOD = 'DOD',
  ATTRIBUTION = 'Attribution',
  CUSTOM_RULES = 'Custom Rules',
}

/**
 * Represents the lifecycle status of a single exception.
 * @enum {string}
 */
export enum ExceptionStatus {
  OPEN = 'Open',
  IN_REVIEW = 'In Review',
  PENDING_ADJUSTMENT = 'Pending Adjustment',
  RESOLVED = 'Resolved',
  CLOSED = 'Closed',
}

/**
 * Defines the structure for a financial position, the level at which exceptions are generated.
 * @interface ExceptionPosition
 * @property {string} tapsAccount - The TAPS account associated with the position.
 * @property {string} cusip - The CUSIP identifier of the financial instrument.
 * @property {string} currency - The currency of the position.
 * @property {string} counterparty - The counterparty for the position.
 */
export interface ExceptionPosition {
    tapsAccount: string;
    cusip: string;
    currency: string;
    counterparty: string;
}

/**
 * Defines the structure for a financial exception.
 * An exception represents a quantifiable break or discrepancy that needs investigation.
 * @interface Exception
 * @property {string} id - The unique identifier for the exception.
 * @property {ExceptionCategory} category - The category of the exception.
 * @property {ExceptionPosition} position - The detailed position object where the exception occurred.
 * @property {number} financialImpact - The monetary value of the exception's impact.
 * @property {string} description - A human-readable description of the exception.
 * @property {ExceptionStatus} status - The current status in the resolution workflow.
 * @property {string} [assignedTo] - The user or team the exception is assigned to.
 * @property {string} [rcaCommentary] - The root cause analysis commentary provided by a user.
 * @property {string} [aiRcaCommentary] - The root cause analysis commentary suggested by the AI.
 * @property {string} dateIdentified - The date the exception was first identified.
 * @property {BusinessArea} businessArea - The business area the exception belongs to.
 * @property {Record<string, string | number>} [details] - A key-value map of underlying data points.
 * @property {{ timestamp: string; action: string; user: string }[]} [history] - An audit trail of actions taken on the exception.
 * @property {string} productLineId - The ID of the product line this exception belongs to.
 * @property {string} strategyId - The ID of the strategy this exception belongs to.
 * @property {Region} region - The region this exception belongs to.
 */
export interface Exception {
  id: string;
  category: ExceptionCategory;
  position: ExceptionPosition;
  financialImpact: number;
  description: string;
  status: ExceptionStatus;
  assignedTo?: string;
  rcaCommentary?: string;
  aiRcaCommentary?: string;
  dateIdentified: string;
  businessArea: BusinessArea;
  details?: Record<string, string | number>;
  history?: { timestamp: string; action: string; user: string }[];
  productLineId: string;
  strategyId: string;
  region: Region;
}

/**
 * Represents a single entry in an activity log.
 * @interface ActivityLogItem
 * @property {string} id - The unique identifier for the log entry.
 * @property {string} timestamp - The ISO timestamp of the activity.
 * @property {'Trade' | 'Adjustment' | 'FX Reval' | 'Fee' | 'System' | 'Commentary'} type - The type of activity.
 * @property {string} description - A human-readable description of the activity.
 * @property {object} [financialImpact] - Optional details about the financial impact of the activity.
 * @property {number} financialImpact.amount - The monetary value of the impact.
 * @property {string} financialImpact.currency - The currency of the impact.
 * @property {number} [financialImpact.pnlEffect] - The effect on Profit & Loss.
 * @property {number} [financialImpact.assetEffect] - The effect on assets.
 * @property {number} [financialImpact.liabilityEffect] - The effect on liabilities.
 * @property {string} [user] - The user who performed the action, or 'System'.
 */
export interface ActivityLogItem {
  id: string;
  timestamp: string;
  type: 'Trade' | 'Adjustment' | 'FX Reval' | 'Fee' | 'System' | 'Commentary';
  description: string;
  financialImpact?: { 
    amount: number; 
    currency: string; 
    pnlEffect?: number; 
    assetEffect?: number; 
    liabilityEffect?: number 
  };
  user?: string;
}

/**
 * Represents a detailed trading strategy, which is a sub-component of a SignOffProductLine.
 * This is the lowest level of sign-off granularity.
 * @interface SignOffStrategy
 * @property {string} id - The unique identifier for the strategy.
 * @property {string} name - The human-readable name of the strategy.
 * @property {string} parentId - The ID of the parent `SignOffProductLine`.
 * @property {ProcessStatus} status - The current sign-off status of the strategy.
 * @property {string} lastUpdated - The ISO timestamp of the last update.
 * @property {string} currency - The base currency for the strategy's financials.
 * @property {BusinessArea} businessArea - The business area it belongs to.
 * @property {number} currentNetPnL - The current day's Net P&L.
 * @property {number} previousNetPnL - The previous day's Net P&L.
 * @property {number} currentTotalAssets - The current day's total assets.
 * @property {number} previousTotalAssets - The previous day's total assets.
 * @property {number} currentTotalLiabilities - The current day's total liabilities.
 * @property {number} previousTotalLiabilities - The previous day's total liabilities.
 * @property {number} pnlTrading - The portion of P&L change from trading activity.
 * @property {number} pnlFxReval - The portion of P&L change from FX revaluation.
 * @property {number} pnlAdjustments - The portion of P&L change from adjustments.
 * @property {number} assetChangeTrading - The change in assets from trading activity.
 * @property {number} assetChangeFxReval - The change in assets from FX revaluation.
 * @property {number} assetChangeAdjustments - The change in assets from adjustments.
 * @property {number} liabilityChangeTrading - The change in liabilities from trading activity.
 * @property {number} liabilityChangeFxReval - The change in liabilities from FX revaluation.
 * @property {number} liabilityChangeAdjustments - The change in liabilities from adjustments.
 * @property {ActivityLogItem[]} activityLog - A log of activities that occurred within this strategy.
 * @property {Region} region - The region this strategy belongs to.
 */
export interface SignOffStrategy {
  id: string;
  name: string;
  parentId: string;
  status: ProcessStatus;
  lastUpdated: string;
  currency: string;
  businessArea: BusinessArea;
  currentNetPnL: number;
  previousNetPnL: number;
  currentTotalAssets: number;
  previousTotalAssets: number;
  currentTotalLiabilities: number;
  previousTotalLiabilities: number;
  pnlTrading: number;
  pnlFxReval: number;
  pnlAdjustments: number;
  assetChangeTrading: number;
  assetChangeFxReval: number;
  assetChangeAdjustments: number;
  liabilityChangeTrading: number;
  liabilityChangeFxReval: number;
  liabilityChangeAdjustments: number;
  activityLog: ActivityLogItem[];
  region: Region;
}

/**
 * Represents a major product line that requires sign-off.
 * It is composed of one or more `SignOffStrategy` items.
 * @interface SignOffProductLine
 * @property {string} id - The unique identifier for the product line.
 * @property {string} name - The human-readable name of the product line.
 * @property {BusinessArea} businessArea - The business area it belongs to.
 * @property {ProcessStatus} status - The current sign-off status of the product line.
 * @property {string} lastUpdated - The ISO timestamp of the last update.
 * @property {string} currency - The base currency for the product line's financials.
 * @property {number} currentNetPnL - The aggregated current day Net P&L.
 * @property {number} previousNetPnL - The aggregated previous day Net P&L.
 * @property {number} currentTotalAssets - The aggregated current day total assets.
 * @property {number} previousTotalAssets - The aggregated previous day total assets.
 * @property {number} currentTotalLiabilities - The aggregated current day total liabilities.
 * @property {number} previousTotalLiabilities - The aggregated previous day total liabilities.
 * @property {SignOffStrategy[]} strategies - The list of underlying strategies that roll up into this product line.
 * @property {Region} region - The region this product line belongs to.
 */
export interface SignOffProductLine {
  id: string;
  name: string;
  businessArea: BusinessArea;
  status: ProcessStatus;
  lastUpdated: string;
  currency: string;
  currentNetPnL: number;
  previousNetPnL: number;
  currentTotalAssets: number;
  previousTotalAssets: number;
  currentTotalLiabilities: number;
  previousTotalLiabilities: number;
  strategies: SignOffStrategy[];
  region: Region;
}

/**
 * Represents a navigation item in the application's main navigation.
 * @interface NavItemType
 * @property {string} path - The URL path for the navigation link.
 * @property {string} name - The display name for the navigation item.
 * @property {(props: React.SVGProps<SVGSVGElement>) => JSX.Element} icon - The icon component for the navigation item.
 */
export interface NavItemType {
  path: string;
  name: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
}

/**
 * Enumeration of the types of financial adjustments that can be made.
 * @enum {string}
 */
export enum AdjustmentType {
  PNL_CORRECTION = 'P&L Correction',
  BS_REALIGNMENT = 'Balance Sheet Realignment',
  FEE_POSTING = 'Fee Posting',
  WASH_ACCOUNT_CLEARING = 'Wash Account Clearing',
  TRADE_AMENDMENT = 'Trade Amendment',
  FINANCING_PNL_FLATTENING = 'Financing PNL Flattening',
  OVER_UNDER_ACCRUAL = 'Over/Under Accrual',
  ATTRIBUTION_ADJUSTMENT = 'Attribution Adjustment',
  OTHER = 'Other',
}

/**
 * Represents the status of an adjustment in its approval workflow.
 * @type {string}
 */
export type AdjustmentStatus = 'DRAFT' | 'PENDING_REVIEW' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'CANCELLED';

/**
 * Defines the structure for a financial adjustment.
 * Adjustments are formal accounting entries to correct or align financial records.
 * @interface Adjustment
 * @property {string} id - The unique identifier for the adjustment.
 * @property {string} [relatedExceptionId] - Optional ID of an exception this adjustment resolves.
 * @property {AdjustmentType} type - The category of the adjustment.
 * @property {number} amount - The monetary value of the adjustment.
 * @property {string} currency - The currency of the adjustment amount.
 * @property {string} debitAccount - The account to be debited.
 * @property {string} creditAccount - The account to be credited.
 * @property {string} justification - The reason for the adjustment.
 * @property {AdjustmentStatus} status - The current status in the approval workflow.
 * @property {string} createdBy - The user who created the adjustment.
 * @property {string} createdAt - The ISO timestamp when the adjustment was created.
 * @property {BusinessArea} businessArea - The business area this adjustment belongs to.
 * @property {string} [lastModifiedAt] - The ISO timestamp of the last modification.
 * @property {string} [submittedBy] - The user who submitted the adjustment.
 * @property {string} [submittedAt] - The ISO timestamp when the adjustment was submitted.
 * @property {string} [approvedBy] - The user who approved the adjustment.
 * @property {string} [approvedAt] - The ISO timestamp when the adjustment was approved.
 * @property {string} [rejectedBy] - The user who rejected the adjustment.
 * @property {string} [rejectedAt] - The ISO timestamp when the adjustment was rejected.
 * @property {string} [rejectionReason] - The reason for rejection, if applicable.
 * @property {number} [suggestedAmount] - An AI-suggested amount for the adjustment.
 * @property {string} [suggestedCurrency] - An AI-suggested currency.
 * @property {string} [suggestedDebitAccount] - An AI-suggested debit account.
 * @property {string} [suggestedCreditAccount] - An AI-suggested credit account.
 * @property {string} [suggestedJustification] - AI-suggested justification text.
 * @property {string} productLineId - The ID of the product line this adjustment belongs to.
 * @property {string} strategyId - The ID of the strategy this adjustment belongs to.
 * @property {Region} region - The region this adjustment belongs to.
 */
export interface Adjustment {
  id: string;
  relatedExceptionId?: string;
  type: AdjustmentType;
  amount: number;
  currency: string;
  debitAccount: string;
  creditAccount: string;
  justification: string;
  status: AdjustmentStatus;
  createdBy: string;
  createdAt: string;
  businessArea: BusinessArea;
  lastModifiedAt?: string;
  submittedBy?: string;
  submittedAt?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  suggestedAmount?: number;
  suggestedCurrency?: string;
  suggestedDebitAccount?: string;
  suggestedCreditAccount?: string;
  suggestedJustification?: string;
  productLineId: string;
  strategyId: string;
  region: Region;
}

/**
 * Represents the status of a case in the case management workflow.
 * @enum {string}
 */
export enum CaseStatus {
  OPEN = 'Open',
  IN_PROGRESS = 'In Progress',
  AWAITING_RESPONSE = 'Awaiting Response', // e.g. Controller is waiting for Trader/Ops
  CLOSED = 'Closed',
}

/**
 * Represents a single comment within a case's history.
 * @interface CaseComment
 * @property {string} user - The user who posted the comment.
 * @property {string} timestamp - The ISO timestamp of the comment.
 * @property {string} comment - The content of the comment.
 */
export interface CaseComment {
  user: string;
  timestamp: string;
  comment: string;
}

/**
 * Defines the structure for a case, which is a formal follow-up on an exception.
 * @interface Case
 * @property {string} id - The unique identifier for the case.
 * @property {string} title - The title of the case.
 * @property {string} exceptionId - The ID of the exception this case is linked to.
 * @property {string} assignedTo - The user the case is currently assigned to.
 * @property {CaseStatus} status - The current status of the case.
 * @property {string} dateOpened - The ISO timestamp when the case was opened.
 * @property {CaseComment[]} comments - An array of comments forming the case history.
 * @property {Region} region - The region this case belongs to.
 */
export interface Case {
  id: string;
  title: string;
  exceptionId: string;
  assignedTo: string;
  status: CaseStatus;
  dateOpened: string;
  comments: CaseComment[];
  region: Region;
}


/**
 * Defines the shape of the global application context.
 * This context provides access to centralized state and updater functions.
 * @interface AppContextType
 * @property {BusinessArea} currentBusinessArea - The currently selected business area.
 * @property {(area: BusinessArea) => void} setCurrentBusinessArea - Function to update the current business area.
 * @property {string} currentPageTitle - The title of the current page, managed for display in the header.
 * @property {(title: string) => void} setCurrentPageTitle - Function to update the current page title.
 * @property {Exception[]} exceptions - The array of all financial exceptions.
 * @property {Adjustment[]} adjustments - The array of all financial adjustments.
 * @property {Record<BusinessArea, SignOffProductLine[]>} productLinesByArea - Product lines, organized by business area.
 * @property {Commentary[]} commentaries - The array of all commentary documents.
 * @property {Record<BusinessArea, PreSignOffTask[]>} preSignOffTasksByArea - Pre-sign-off tasks, organized by business area.
 * @property {Case[]} cases - The array of all cases.
 * @property {(updatedException: Exception) => void} updateException - Function to update a single exception.
 * @property {(updatedExceptions: Exception[]) => void} updateMultipleExceptions - Function to update an array of exceptions.
 * @property {(adjustmentToSave: Adjustment) => void} saveAdjustment - Function to create or update an adjustment.
 * @property {(itemId: string, level: 'ProductLine' | 'Strategy', newStatus: ProcessStatus, approved: boolean) => void} updateSignOffStatus - Function to update the status of a sign-off item.
 * @property {(commentaryToSave: Commentary) => void} saveCommentary - Function to create or update a commentary.
 * @property {(updatedTask: PreSignOffTask) => void} updatePreSignOffTask - Function to update a pre-sign-off task.
 * @property {(updatedCase: Case) => void} updateCase - Function to update a case.
 * @property {(newCase: Case) => void} createCase - Function to create a new case.
 * @property {string} currentProductLineId - The ID of the currently selected product line filter ('ALL' for no filter).
 * @property {(id: string) => void} setCurrentProductLineId - Function to update the product line filter.
 * @property {string} currentStrategyId - The ID of the currently selected strategy filter ('ALL' for no filter).
 * @property {(id: string) => void} setCurrentStrategyId - Function to update the strategy filter.
 * @property {Region | 'ALL'} currentRegion - The currently selected region filter ('ALL' for no filter).
 * @property {(region: Region | 'ALL') => void} setCurrentRegion - Function to update the region filter.
 */
export interface AppContextType {
  currentBusinessArea: BusinessArea;
  setCurrentBusinessArea: (area: BusinessArea) => void;
  currentPageTitle: string;
  setCurrentPageTitle: (title: string) => void;
  
  // Centralized State
  exceptions: Exception[];
  adjustments: Adjustment[];
  productLinesByArea: Record<BusinessArea, SignOffProductLine[]>;
  commentaries: Commentary[];
  preSignOffTasksByArea: Record<BusinessArea, PreSignOffTask[]>;
  cases: Case[];

  // Updater Functions
  updateException: (updatedException: Exception) => void;
  updateMultipleExceptions: (updatedExceptions: Exception[]) => void;
  saveAdjustment: (adjustmentToSave: Adjustment) => void;
  updateSignOffStatus: (itemId: string, level: 'ProductLine' | 'Strategy', newStatus: ProcessStatus, approved: boolean) => void;
  saveCommentary: (commentaryToSave: Commentary) => void;
  updatePreSignOffTask: (updatedTask: PreSignOffTask) => void;
  updateCase: (updatedCase: Case) => void;
  createCase: (newCase: Case) => void;
  
  // Global Filters
  currentProductLineId: string;
  setCurrentProductLineId: (id: string) => void;
  currentStrategyId: string;
  setCurrentStrategyId: (id: string) => void;
  currentRegion: Region | 'ALL';
  setCurrentRegion: (region: Region | 'ALL') => void;
}

/**
 * Defines an item within a context menu.
 * @interface ContextMenuItemType
 * @property {string} [label] - The text label for the menu item.
 * @property {(props: React.SVGProps<SVGSVGElement>) => JSX.Element} [icon] - The icon component for the menu item.
 * @property {() => void} [onClick] - The function to execute when the item is clicked.
 * @property {boolean} [disabled] - Whether the menu item is disabled.
 * @property {boolean} [isSeparator] - If true, renders a separator line instead of a button.
 */
export interface ContextMenuItemType {
  label?: string;
  icon?: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  onClick?: () => void;
  disabled?: boolean;
  isSeparator?: boolean;
}

/**
 * Represents detailed information for a specific financial position.
 * @interface PositionDrillDownInfo
 * @property {string} positionId - The ID of the position.
 * @property {string} marketValue - The current market value.
 * @property {number} quantity - The quantity of the position.
 * @property {string} costBasis - The original cost basis.
 * @property {string} lastPrice - The last known price.
 * @property {string} unrealizedPnL - The unrealized Profit & Loss.
 * @property {string} relatedBook - The trading book it belongs to.
 * @property {string} assetClass - The asset class of the position.
 */
export interface PositionDrillDownInfo {
  positionId: string;
  marketValue: string;
  quantity: number;
  costBasis: string;
  lastPrice: string;
  unrealizedPnL: string;
  relatedBook: string;
  assetClass: string;
}

/**
 * Represents detailed information for a specific trade.
 * @interface TradeDrillDownInfo
 * @property {string} tradeId - The ID of the trade.
 * @property {string} timestamp - The ISO timestamp of the trade.
 * @property {number} quantity - The quantity traded.
 * @property {number} price - The price at which the trade was executed.
 * @property {string} currency - The currency of the trade.
 * @property {'Buy' | 'Sell'} direction - The direction of the trade.
 * @property {string} counterparty - The counterparty to the trade.
 * @property {string} relatedExceptionId - The ID of the exception it is related to.
 */
export interface TradeDrillDownInfo {
  tradeId: string;
  timestamp: string;
  quantity: number;
  price: number;
  currency: string;
  direction: 'Buy' | 'Sell';
  counterparty: string;
  relatedExceptionId: string;
}

/**
 * A discriminated union representing the content for a drill-down view.
 * It can be either details for a single position or a list of trades.
 * @type {object}
 */
export type DrillDownContentType = 
  | { type: 'position'; data: PositionDrillDownInfo }
  | { type: 'trades'; data: TradeDrillDownInfo[] };

/**
 * Enumeration of the types of commentaries that can be created.
 * @enum {string}
 */
export enum CommentaryType {
  MARKET = 'Market Commentary',
  OPERATIONAL_RISK = 'Operational Risk Commentary',
  BALANCE_SHEET_FLUCTUATION = 'Balance Sheet Fluctuation Commentary',
  T0_T1_COMMENTARY = 'T0/T1 Commentary',
  DAILY_TRADER_PACK = 'Daily Trader Pack',
}

/**
 * Represents a single section within a commentary, which includes user content and an optional AI suggestion.
 * @interface CommentarySection
 * @property {string} title - The title of the section.
 * @property {string} userContent - The content written by the user.
 * @property {string} [aiSuggestion] - An optional AI-generated suggestion or placeholder for the section.
 */
export interface CommentarySection {
  title: string;
  userContent: string;
  aiSuggestion?: string;
}

/**
 * Defines the structure for a commentary document.
 * @interface Commentary
 * @property {string} id - The unique identifier for the commentary.
 * @property {CommentaryType} type - The type of commentary.
 * @property {string} title - The title of the commentary.
 * @property {string} author - The user who authored the commentary.
 * @property {string} dateCreated - The ISO timestamp when the commentary was created.
 * @property {BusinessArea} businessArea - The business area this commentary belongs to.
 * @property {CommentarySection[]} sections - An array of sections that make up the commentary.
 * @property {string[]} [linkedItems] - An array of IDs of linked items (e.g., exceptions, positions).
 * @property {string[]} [tags] - An array of tags for categorizing and searching.
 * @property {string} productLineId - The ID of the product line this commentary belongs to.
 * @property {string} strategyId - The ID of the strategy this commentary belongs to.
 * @property {Region} region - The region this commentary belongs to.
 */
export interface Commentary {
  id: string;
  type: CommentaryType;
  title: string;
  author: string;
  dateCreated: string;
  businessArea: BusinessArea;
  sections: CommentarySection[];
  linkedItems?: string[];
  tags?: string[];
  productLineId: string;
  strategyId: string;
  region: Region;
}

/**
 * Defines the structure for a commentary template, used to bootstrap new commentaries.
 * @interface CommentaryTemplate
 * @property {CommentaryType} type - The type of commentary this template creates.
 * @property {string} name - The name of the template.
 * @property {string} description - A short description of the template's purpose.
 * @property {Array<{ title: string; aiPlaceholder?: string }>} defaultSections - The default sections to create for this template.
 */
export interface CommentaryTemplate {
  type: CommentaryType;
  name: string;
  description: string;
  defaultSections: Array<{ title: string; aiPlaceholder?: string }>;
}

/**
 * Represents a distribution list for sending reports or notifications.
 * @interface DistributionList
 * @property {string} id - The unique identifier for the distribution list.
 * @property {string} name - The name of the distribution list.
 * @property {string} [description] - An optional description of the list's members.
 */
export interface DistributionList {
  id: string;
  name: string;
  description?: string;
}

/**
 * Represents the status of a pre-sign-off automated task.
 * @enum {string}
 */
export enum PreSignOffTaskStatus {
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  COMPLETED_OK = 'Completed - OK',
  COMPLETED_BREAKS = 'Completed - Breaks Found',
  FAILED = 'Failed',
  REQUIRES_ATTENTION = 'Requires Attention',
  ACKNOWLEDGED = 'Acknowledged',
}

/**
 * Represents a single break found during a pre-sign-off task.
 * @interface PreSignOffBreakDetail
 * @property {string} id - The unique identifier for the break.
 * @property {string} description - A description of the break.
 * @property {'High' | 'Medium' | 'Low'} severity - The severity of the break.
 * @property {string} [relatedEntity] - An optional related entity ID (e.g., a position or trade ID).
 */
export interface PreSignOffBreakDetail {
  id: string;
  description: string;
  severity: 'High' | 'Medium' | 'Low';
  relatedEntity?: string;
}

/**
 * Represents a task in the pre-sign-off checklist.
 * @interface PreSignOffTask
 * @property {string} id - The unique identifier for the task.
 * @property {string} title - The title of the task.
 * @property {string} description - A description of what the task does.
 * @property {PreSignOffTaskStatus} status - The current status of the task.
 * @property {BusinessArea} businessArea - The business area this task belongs to.
 * @property {string} [lastRun] - The ISO timestamp of when the task was last run.
 * @property {string} [lastUpdated] - The ISO timestamp of the last status update.
 * @property {number} [breakCount] - The number of breaks found by the task.
 * @property {string} [detailsLink] - An optional link to a more detailed view.
 * @property {string} [responsibleTeam] - The team responsible for this task.
 * @property {string} [assignedToUser] - The specific user assigned to investigate.
 * @property {PreSignOffBreakDetail[]} [breakDetails] - An array of break details if any were found.
 * @property {string} productLineId - The ID of the product line this task belongs to.
 * @property {string} strategyId - The ID of the strategy this task belongs to.
 * @property {Region} region - The region this task belongs to.
 */
export interface PreSignOffTask {
  id: string;
  title: string;
  description: string;
  status: PreSignOffTaskStatus;
  businessArea: BusinessArea;
  lastRun?: string;
  lastUpdated?: string;
  breakCount?: number;
  detailsLink?: string;
  responsibleTeam?: string;
  assignedToUser?: string;
  breakDetails?: PreSignOffBreakDetail[];
  productLineId: string;
  strategyId: string;
  region: Region;
}

/**
 * Represents a manual action that can be triggered from the pre-sign-off screen.
 * @interface PreSignOffAction
 * @property {string} id - The unique identifier for the action.
 * @property {string} title - The title of the action.
 * @property {string} description - A description of what the action does.
 * @property {(props: React.SVGProps<SVGSVGElement>) => JSX.Element} icon - The icon component for the action.
 * @property {BusinessArea} businessArea - The business area this action is available for.
 * @property {AdjustmentType} adjustmentType - The type of adjustment this action will create.
 */
export interface PreSignOffAction {
  id: string;
  title: string;
  description: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  businessArea: BusinessArea;
  adjustmentType: AdjustmentType;
}

/**
 * Represents the P&L summary for a trader's personal dashboard.
 * @interface TraderPnlSummary
 * @property {number} mtd - Month-to-date P&L.
 * @property {number} ytd - Year-to-date P&L.
 * @property {number} dod - Day-over-day P&L.
 * @property {string} currency - The currency of the P&L figures.
 */
export interface TraderPnlSummary {
  mtd: number;
  ytd: number;
  dod: number;
  currency: string;
}

/**
 * Represents the status of a deployment stage in a release train.
 * @enum {string}
 */
export enum DeploymentStatus {
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  SUCCESS = 'Success',
  FAILED = 'Failed',
}

/**
 * Represents a single stage in a deployment pipeline.
 * @interface DeploymentStage
 * @property {string} name - The name of the deployment stage.
 * @property {DeploymentStatus} status - The current status of the stage.
 * @property {string} [startedAt] - The ISO timestamp when the stage started.
 * @property {string} [completedAt] - The ISO timestamp when the stage completed.
 */
export interface DeploymentStage {
  name: string;
  status: DeploymentStatus;
  startedAt?: string;
  completedAt?: string;
}

/**
 * Represents a release train for software deployment tracking.
 * @interface ReleaseTrain
 * @property {string} id - The unique identifier for the release train.
 * @property {string} name - The name of the release.
 * @property {string} version - The version number being deployed.
 * @property {'Active' | 'Completed' | 'Rolled Back'} status - The overall status of the release.
 * @property {DeploymentStage[]} stages - The sequence of deployment stages.
 * @property {string} [deployedAt] - The ISO timestamp of the final deployment.
 */
export interface ReleaseTrain {
  id: string;
  name: string;
  version: string;
  status: 'Active' | 'Completed' | 'Rolled Back';
  stages: DeploymentStage[];
  deployedAt?: string;
}

/**
 * Represents a technology stack item for documentation.
 * @interface StackItem
 * @property {string} name - The name of the technology.
 * @property {'Frontend' | 'API' | 'Tooling' | 'Platform'} category - The category of the technology.
 * @property {string} description - A description of its role in the application.
 */
export interface StackItem {
  name: string;
  category: 'Frontend' | 'API' | 'Tooling' | 'Platform';
  description: string;
}

/**
 * Represents pre-trade approval details for a trade in the Investigation Workbench.
 * @interface PreTradeApprovalDetails
 * @property {string} approvalId - The ID of the pre-trade approval.
 * @property {'Approved' | 'Breached'} limitCheckStatus - The status of the limit check.
 * @property {string} timestamp - The timestamp of the approval.
 * @property {string} checkedBy - The system or user that performed the check.
 */
export interface PreTradeApprovalDetails {
  approvalId: string;
  limitCheckStatus: 'Approved' | 'Breached';
  timestamp: string;
  checkedBy: string;
}

/**
 * Represents trade capture system details for a trade in the Investigation Workbench.
 * @interface TradeCaptureDetails
 * @property {'TradeMaster' | 'BookItAll'} bookingSystem - The system where the trade was captured.
 * @property {string} tradeTime - The time the trade was captured.
 * @property {string} traderId - The ID of the trader who executed the trade.
 * @property {string} salesperson - The salesperson associated with the trade.
 */
export interface TradeCaptureDetails {
  bookingSystem: 'TradeMaster' | 'BookItAll';
  tradeTime: string;
  traderId: string;
  salesperson: string;
}

/**
 * Represents risk metrics for a trade in the Investigation Workbench.
 * @interface RiskDetails
 * @property {number} delta - The delta of the position.
 * @property {number} gamma - The gamma of the position.
 * @property {number} vega - The vega of the position.
 * @property {number} theta - The theta of the position.
 * @property {number} var99 - The 99% Value at Risk.
 */
export interface RiskDetails {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  var99: number;
}

/**
 * Represents operations details for a trade in the Investigation Workbench.
 * @interface OpsDetails
 * @property {'Confirmed' | 'Unconfirmed' | 'Mismatch'} confirmationStatus - The status of trade confirmation.
 * @property {'Settled' | 'Unsettled' | 'Failed'} settlementStatus - The status of trade settlement.
 * @property {string} settlementDate - The expected settlement date.
 */
export interface OpsDetails {
  confirmationStatus: 'Confirmed' | 'Unconfirmed' | 'Mismatch';
  settlementStatus: 'Settled' | 'Unsettled' | 'Failed';
  settlementDate: string;
}

/**
 * Represents ledger details for a trade in the Investigation Workbench.
 * @interface LedgerDetails
 * @property {string} journalId - The ID of the ledger journal entry.
 * @property {string} debitAccount - The account debited by the transaction.
 * @property {string} creditAccount - The account credited by the transaction.
 * @property {number} amount - The amount of the transaction.
 * @property {string} currency - The currency of the transaction.
 * @property {string} postingDate - The date the transaction was posted to the ledger.
 */
export interface LedgerDetails {
  journalId: string;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  currency: string;
  postingDate: string;
}

/**
 * Represents a comprehensive trade object for the Investigation Workbench.
 * @interface InvestigativeTrade
 * @property {string} id - The unique identifier for the trade.
 * @property {BusinessArea} businessArea - The business area the trade belongs to.
 * @property {string} product - The product or instrument traded.
 * @property {number} quantity - The quantity of the trade.
 * @property {number} price - The price of the trade.
 * @property {string} currency - The currency of the trade.
 * @property {string} counterparty - The counterparty to the trade.
 * @property {'Booked' | 'Amended' | 'Cancelled'} status - The current status of the trade.
 * @property {string} tradeDate - The date the trade was executed.
 * @property {PreTradeApprovalDetails} preTrade - Details from the pre-trade system.
 * @property {TradeCaptureDetails} tradeCapture - Details from the trade capture system.
 * @property {RiskDetails} risk - Details from the risk system.
 * @property {OpsDetails} ops - Details from the operations system.
 * @property {LedgerDetails} ledger - Details from the general ledger system.
 * @property {string} productLineId - The ID of the product line this trade belongs to.
 * @property {string} strategyId - The ID of the strategy this trade belongs to.
 * @property {Region} region - The region this trade belongs to.
 */
export interface InvestigativeTrade {
  id: string;
  businessArea: BusinessArea;
  product: string;
  quantity: number;
  price: number;
  currency: string;
  counterparty: string;
  status: 'Booked' | 'Amended' | 'Cancelled';
  tradeDate: string;
  preTrade: PreTradeApprovalDetails;
  tradeCapture: TradeCaptureDetails;
  risk: RiskDetails;
  ops: OpsDetails;
  ledger: LedgerDetails;
  productLineId: string;
  strategyId: string;
  region: Region;
}

/**
 * Represents a single message in the AI chat widget.
 * @interface ChatMessage
 * @property {string} id - The unique identifier for the message.
 * @property {string} text - The content of the message.
 * @property {'user' | 'ai'} sender - Who sent the message.
 * @property {string} timestamp - The ISO timestamp of when the message was sent.
 */
export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

/**
 * Represents a single FAQ item for the help widget.
 * @interface FAQ
 * @property {string} id - The unique identifier for the FAQ.
 * @property {string} question - The question being asked.
 * @property {string} answer - The answer to the question.
 * @property {string[]} keywords - An array of keywords for searching.
 */
export interface FAQ {
  id: string;
  question: string;
  answer: string;
  keywords: string[];
}