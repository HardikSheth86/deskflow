

import React, { createContext, useState, ReactNode, useCallback, useMemo } from 'react';
import { 
  BusinessArea, AppContextType, Exception, Adjustment, SignOffProductLine, 
  Commentary, PreSignOffTask, ProcessStatus, Case, Region, SignOffStrategy
} from '../types';
import { 
  MOCK_EXCEPTIONS, 
  MOCK_ADJUSTMENTS, 
  MOCK_PRODUCT_LINES_BY_AREA, 
  MOCK_COMMENTARIES,
  MOCK_PRE_SIGN_OFF_TASKS_BY_AREA,
  MOCK_CASES,
} from '../constants';
import { determineProductLineStatus } from '../utils/helpers';

/**
 * @file This file defines the main React Context for the application's global state.
 * The `AppProvider` component initializes and manages all core data entities
 * and exposes them along with state updater functions to the rest of the application.
 */

/**
 * The main application context. Provides access to global state and updater functions.
 * It is initialized as `undefined` and must be consumed using the `useAppContext` hook,
 * which ensures it is only accessed within components wrapped by the `AppProvider`.
 * @type {React.Context<AppContextType | undefined>}
 */
export const AppContext = createContext<AppContextType | undefined>(undefined);

/**
 * @interface AppProviderProps
 * Defines the props for the AppProvider component.
 * @property {ReactNode} children - The child components that will have access to this context.
 */
interface AppProviderProps {
  children: ReactNode;
}

/**
 * The provider component for the application's global state.
 * It initializes and manages all the core data (exceptions, adjustments, etc.)
 * and exposes functions to modify that data in an immutable way.
 * All components that need access to global state should be children of this provider.
 * @param {AppProviderProps} props - The component props.
 * @returns {JSX.Element} The provider component wrapping its children.
 */
export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  // --- UI State ---
  /** The title displayed in the header for the current page. */
  const [currentPageTitle, setCurrentPageTitle] = useState<string>('Dashboard');
  
  // --- Global Filter State ---
  const [selectedBusinessAreas, setSelectedBusinessAreas] = useState<BusinessArea[]>([BusinessArea.TREASURY_CAPITAL_MARKETS]);
  const [selectedProductLineIds, setSelectedProductLineIds] = useState<string[]>([]);
  const [selectedStrategies, setSelectedStrategies] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<Region[]>([]);


  // --- Centralized Data State Management ---
  // NOTE: A deep copy of mock data is made on initialization using JSON.parse/stringify.
  // This is a simple method suitable for this app's data structures but has limitations
  // (e.g., it will not correctly copy Dates, functions, or undefined values).
  // A more robust solution for complex objects might involve a library like `immer`.
  
  /** The master list of all financial exceptions. */
  const [exceptions, setExceptions] = useState<Exception[]>(() => JSON.parse(JSON.stringify(MOCK_EXCEPTIONS)));
  /** The master list of all financial adjustments. */
  const [adjustments, setAdjustments] = useState<Adjustment[]>(() => JSON.parse(JSON.stringify(MOCK_ADJUSTMENTS)));
  /** The master list of all product lines, keyed by their business area. */
  const [productLinesByArea, setProductLinesByArea] = useState<Record<BusinessArea, SignOffProductLine[]>>(() => JSON.parse(JSON.stringify(MOCK_PRODUCT_LINES_BY_AREA)));
  /** The master list of all commentary documents. */
  const [commentaries, setCommentaries] = useState<Commentary[]>(() => JSON.parse(JSON.stringify(MOCK_COMMENTARIES)));
  /** The master list of all pre-sign-off tasks, keyed by their business area. */
  const [preSignOffTasksByArea, setPreSignOffTasksByArea] = useState<Record<BusinessArea, PreSignOffTask[]>>(() => JSON.parse(JSON.stringify(MOCK_PRE_SIGN_OFF_TASKS_BY_AREA)));
  /** The master list of all investigation cases. */
  const [cases, setCases] = useState<Case[]>(() => JSON.parse(JSON.stringify(MOCK_CASES)));


  /**
   * Updates a single exception in the global state in an immutable way.
   * @param {Exception} updatedException - The exception object with the updated values.
   */
  const updateException = useCallback((updatedException: Exception) => {
    setExceptions(prev => prev.map(ex => ex.id === updatedException.id ? updatedException : ex));
  }, []);

  /**
   * Updates multiple exceptions in the global state, typically for bulk actions.
   * @param {Exception[]} updatedExceptions - An array of exception objects with updated values.
   */
  const updateMultipleExceptions = useCallback((updatedExceptions: Exception[]) => {
    setExceptions(prev => {
        const updatedIds = new Set(updatedExceptions.map(ue => ue.id));
        return prev.map(ex => {
            const foundUpdate = updatedExceptions.find(ue => ue.id === ex.id);
            return foundUpdate ? foundUpdate : ex;
        });
    });
  }, []);

  /**
   * Saves an adjustment. If an adjustment with the same ID exists, it's updated; otherwise, it's added.
   * This ensures immutability by creating a new array.
   * @param {Adjustment} adjustmentToSave - The adjustment object to save.
   */
  const saveAdjustment = useCallback((adjustmentToSave: Adjustment) => {
    setAdjustments(prev => {
      const index = prev.findIndex(adj => adj.id === adjustmentToSave.id);
      if (index > -1) {
        const updated = [...prev];
        updated[index] = adjustmentToSave;
        return updated;
      }
      return [...prev, adjustmentToSave];
    });
  }, []);
  
  /**
   * Saves multiple adjustments from a bulk upload.
   * @param {Adjustment[]} adjustmentsToSave - An array of adjustment objects to add.
   */
  const saveMultipleAdjustments = useCallback((adjustmentsToSave: Adjustment[]) => {
    setAdjustments(prev => [...prev, ...adjustmentsToSave]);
  }, []);

  /**
   * Updates a sign-off item (ProductLine or Strategy) with new data.
   * Used for actions like saving a comment. This uses immutable update patterns.
   * @param {SignOffProductLine | SignOffStrategy} updatedItem - The updated item.
   */
  const updateSignOffItem = useCallback((updatedItem: SignOffProductLine | SignOffStrategy) => {
    setProductLinesByArea(prevAreaState => {
      const newAreaState: Record<BusinessArea, SignOffProductLine[]> = { ...prevAreaState };
      
      for (const areaKey in newAreaState) {
        const area = areaKey as BusinessArea;
        newAreaState[area] = newAreaState[area].map(pl => {
          // Case 1: The updated item is a Product Line
          if ('strategies' in updatedItem && pl.id === updatedItem.id) {
            return { ...pl, ...updatedItem };
          }
          
          // Case 2: The updated item is a Strategy, check if it's in this Product Line
          const strategyIndex = pl.strategies.findIndex(s => s.id === updatedItem.id);
          if (strategyIndex > -1) {
            const newStrategies = [...pl.strategies];
            newStrategies[strategyIndex] = updatedItem as SignOffStrategy;
            return { ...pl, strategies: newStrategies };
          }

          return pl; // No changes in this Product Line
        });
      }
      return newAreaState;
    });
  }, []);


  /**
   * Updates the sign-off status of a Product Line or a Strategy using immutable patterns.
   * It handles the logic for rolling up statuses (e.g., if a strategy is rejected, the parent product line status is updated).
   * @param {string} itemId - The ID of the item to update (ProductLine or Strategy).
   * @param {'ProductLine' | 'Strategy'} level - The level of the item being updated.
   * @param {ProcessStatus} newStatus - The new status to apply.
   */
  const updateSignOffStatus = useCallback((itemId: string, level: 'ProductLine' | 'Strategy', newStatus: ProcessStatus) => {
    setProductLinesByArea(prevAreaState => {
      const newAreaState = { ...prevAreaState };

      for (const areaKey in newAreaState) {
          const area = areaKey as BusinessArea;
          newAreaState[area] = newAreaState[area].map(pl => {
              let plLastUpdated = pl.lastUpdated;
              let plStatus = pl.status;
              let strategies = pl.strategies;
              let wasModified = false;

              // If updating a strategy
              if (level === 'Strategy') {
                  const strategyIndex = strategies.findIndex(s => s.id === itemId);
                  if (strategyIndex > -1) {
                      const newStrategies = [...strategies];
                      newStrategies[strategyIndex] = { ...strategies[strategyIndex], status: newStatus, lastUpdated: new Date().toISOString() };
                      strategies = newStrategies;
                      plStatus = determineProductLineStatus(strategies);
                      plLastUpdated = new Date().toISOString();
                      wasModified = true;
                  }
              }

              // If updating a product line
              if (level === 'ProductLine' && pl.id === itemId) {
                  plStatus = newStatus;
                  plLastUpdated = new Date().toISOString();
                  strategies = strategies.map(s => {
                      if (newStatus !== ProcessStatus.SIGNED_OFF || s.status !== ProcessStatus.REJECTED) {
                          return { ...s, status: newStatus, lastUpdated: new Date().toISOString() };
                      }
                      return s;
                  });
                  wasModified = true;
              }

              // Return a new product line object only if it was modified
              return wasModified ? { ...pl, strategies, status: plStatus, lastUpdated: plLastUpdated } : pl;
          });
      }
      return newAreaState;
    });
  }, []);

  
  /**
   * Saves a commentary. If one with the same ID exists, it's updated; otherwise, it's added.
   * @param {Commentary} commentaryToSave - The commentary object to save.
   */
  const saveCommentary = useCallback((commentaryToSave: Commentary) => {
    setCommentaries(prev => {
      const index = prev.findIndex(c => c.id === commentaryToSave.id);
      if (index > -1) {
        const updated = [...prev];
        updated[index] = commentaryToSave;
        return updated;
      }
      return [...prev, commentaryToSave];
    });
  }, []);

  /**
   * Updates a single pre-sign-off task in the global state.
   * @param {PreSignOffTask} updatedTask - The task object with updated values.
   */
  const updatePreSignOffTask = useCallback((updatedTask: PreSignOffTask) => {
    setPreSignOffTasksByArea(prev => {
      const newAreaState = { ...prev };
      const tasksForCurrentArea = newAreaState[updatedTask.businessArea] ? [...newAreaState[updatedTask.businessArea]] : [];
      const taskIndex = tasksForCurrentArea.findIndex(t => t.id === updatedTask.id);
      if (taskIndex !== -1) {
        tasksForCurrentArea[taskIndex] = updatedTask;
        newAreaState[updatedTask.businessArea] = tasksForCurrentArea;
        return newAreaState;
      }
      return prev;
    });
  }, []);

  /**
   * Updates a single case in the global state.
   * @param {Case} updatedCase - The case object with the updated values.
   */
  const updateCase = useCallback((updatedCase: Case) => {
    setCases(prev => prev.map(c => c.id === updatedCase.id ? updatedCase : c));
  }, []);

  /**
   * Creates a new case and adds it to the global state.
   * @param {Case} newCase - The new case object to add.
   */
  const createCase = useCallback((newCase: Case) => {
    setCases(prev => [...prev, newCase]);
  }, []);


  /**
   * Memoizes the context value to prevent unnecessary re-renders of consumer components.
   * The context value only changes if one of the dependencies in the array changes.
   * This is a critical performance optimization for context providers.
   */
  const value = useMemo(() => ({
    currentPageTitle,
    setCurrentPageTitle,
    exceptions,
    adjustments,
    productLinesByArea,
    commentaries,
    preSignOffTasksByArea,
    cases,
    updateException,
    updateMultipleExceptions,
    saveAdjustment,
    saveMultipleAdjustments,
    updateSignOffStatus,
    updateSignOffItem,
    saveCommentary,
    updatePreSignOffTask,
    updateCase,
    createCase,
    selectedBusinessAreas,
    setSelectedBusinessAreas,
    selectedProductLineIds,
    setSelectedProductLineIds,
    selectedStrategies,
    setSelectedStrategies,
    selectedRegions,
    setSelectedRegions,
  }), [
    currentPageTitle, exceptions, adjustments, productLinesByArea, 
    commentaries, preSignOffTasksByArea, cases, 
    selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions,
    updateException, updateMultipleExceptions, saveAdjustment, saveMultipleAdjustments,
    updateSignOffStatus, updateSignOffItem, saveCommentary, updatePreSignOffTask, updateCase, createCase,
    setCurrentPageTitle, setSelectedBusinessAreas, setSelectedProductLineIds,
    setSelectedStrategies, setSelectedRegions,
  ]);

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};
