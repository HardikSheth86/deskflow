import { SignOffStrategy, ProcessStatus } from '../types';

/**
 * Formats a number into a currency string with no decimal places.
 * @param {number} value - The numeric value to format.
 * @param {string} currency - The currency code (e.g., 'USD').
 * @param {boolean} [showSign=false] - If true, prefixes positive numbers with a '+' sign.
 * @returns {string} A formatted currency string (e.g., "$1,234" or "+$1,234").
 */
export const formatCurrency = (value: number, currency: string, showSign: boolean = false): string => {
  const sign = value >= 0 && showSign ? '+' : '';
  return sign + new Intl.NumberFormat('en-US', { style: 'currency', currency, minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
};

/**
 * Calculates the Day-over-Day (DoD) change between two numbers.
 * @param {number} current - The current day's value.
 * @param {number} previous - The previous day's value.
 * @returns {{amount: number, percentage: number, isPositive: boolean}} An object containing the absolute amount of change, the percentage change, and a boolean indicating if the change was positive. Returns 100% for percentage change if the previous value was 0.
 */
export const calculateDoDChange = (current: number, previous: number) => {
  if (previous === 0) {
    const amount = current - previous;
    return { amount, percentage: amount !== 0 ? 100 : 0, isPositive: amount >= 0 };
  }
  const amountChange = current - previous;
  const percentageChange = (amountChange / Math.abs(previous)) * 100;
  return { amount: amountChange, percentage: parseFloat(percentageChange.toFixed(2)), isPositive: amountChange >= 0 };
};

/**
 * Calculates aggregate financial metrics for a higher-level entity (e.g., Product Line or Strategy Group) by summing the values of its underlying strategies.
 * @param {SignOffStrategy[]} strategies - An array of `SignOffStrategy` objects to aggregate.
 * @returns {Partial<SignOffStrategy>} A partial `SignOffStrategy` object containing the summed financial metrics (PnL, Assets, Liabilities).
 */
export const calculateProductLineAggregates = (strategies: SignOffStrategy[]): Partial<SignOffStrategy> => {
  return strategies.reduce((acc, strategy) => {
    acc.currentNetPnL = (acc.currentNetPnL || 0) + strategy.currentNetPnL;
    acc.previousNetPnL = (acc.previousNetPnL || 0) + strategy.previousNetPnL;
    acc.currentTotalAssets = (acc.currentTotalAssets || 0) + strategy.currentTotalAssets;
    acc.previousTotalAssets = (acc.previousTotalAssets || 0) + strategy.previousTotalAssets;
    acc.currentTotalLiabilities = (acc.currentTotalLiabilities || 0) + strategy.currentTotalLiabilities;
    acc.previousTotalLiabilities = (acc.previousTotalLiabilities || 0) + strategy.previousTotalLiabilities;
    return acc;
  }, {} as Partial<SignOffStrategy>);
};

/**
 * Determines the rolled-up status of a parent entity based on the statuses of its child strategies.
 * The business logic is as follows, in order of precedence:
 * 1. If any child strategy is REJECTED, the parent is REJECTED.
 * 2. If any child strategy is IN_PROGRESS or AWAITING_SIGN_OFF, the parent is IN_PROGRESS.
 * 3. If all child strategies are SIGNED_OFF, the parent is considered AWAITING_SIGN_OFF for its own level of approval.
 * @param {SignOffStrategy[]} strategies - An array of `SignOffStrategy` objects.
 * @returns {ProcessStatus} The calculated `ProcessStatus` for the parent entity.
 */
export const determineProductLineStatus = (strategies: SignOffStrategy[]): ProcessStatus => {
  if (strategies.length === 0) return ProcessStatus.IN_PROGRESS;
  if (strategies.some(s => s.status === ProcessStatus.REJECTED)) return ProcessStatus.REJECTED;
  if (strategies.some(s => s.status === ProcessStatus.IN_PROGRESS || s.status === ProcessStatus.AWAITING_SIGN_OFF)) return ProcessStatus.IN_PROGRESS;
  // This state means all children are signed off, making the parent ready for its own sign-off action.
  if (strategies.every(s => s.status === ProcessStatus.SIGNED_OFF)) return ProcessStatus.AWAITING_SIGN_OFF;
  return ProcessStatus.IN_PROGRESS; // Default case if logic doesn't cover a state.
};


/**
 * Formats a date string into a human-readable relative time string (e.g., "5 minutes ago").
 * Provides a simplified relative time calculation.
 * @param {string} dateString - An ISO 8601 date string to format.
 * @returns {string} A human-readable string representing the time distance from now.
 */
export const formatDateDistance = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  let interval = seconds / 31536000;
  if (interval > 1) {
    return Math.floor(interval) + (Math.floor(interval) === 1 ? " year ago" : " years ago");
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + (Math.floor(interval) === 1 ? " month ago" : " months ago");
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + (Math.floor(interval) === 1 ? " day ago" : " days ago");
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + (Math.floor(interval) === 1 ? " hour ago" : " hours ago");
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + (Math.floor(interval) === 1 ? " minute ago" : " minutes ago");
  }
  return "just now";
};
