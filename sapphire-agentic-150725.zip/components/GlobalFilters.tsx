

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { BusinessArea, Region } from '../types';
import { ALL_REGIONS } from '../constants';
import { ChevronDownIcon } from './icons';

interface MultiSelectProps {
    label: string;
    name: string;
    options: { value: string; label: string }[];
    selected: string[];
    onChange: (selected: string[]) => void;
    disabled?: boolean;
}

const MultiSelectDropdown: React.FC<MultiSelectProps> = ({ label, name, options, selected, onChange, disabled = false }) => {
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [wrapperRef]);
    
    const handleSelect = (value: string) => {
        if (disabled) return;
        const newSelected = selected.includes(value)
            ? selected.filter(item => item !== value)
            : [...selected, value];
        onChange(newSelected);
    };

    const isAllSelected = selected.length === options.length && options.length > 0;

    const handleSelectAll = () => {
        if (isAllSelected) {
            onChange([]);
        } else {
            onChange(options.map(o => o.value));
        }
    };

    const getButtonLabel = () => {
        if (selected.length === 0) return `All ${name}s`;
        if (selected.length === options.length && options.length > 0) return `All ${name}s`;
        if (selected.length === 1) {
             const selectedOption = options.find(o => o.value === selected[0]);
             return selectedOption ? selectedOption.label : '1 Selected';
        }
        return `${selected.length} Selected`;
    }

    return (
        <div className="relative" ref={wrapperRef}>
            <label className="block text-xs font-medium text-slate-600 mb-1">{label}</label>
            <button
                type="button"
                className={`w-full p-2 border border-slate-300 rounded-md text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors flex justify-between items-center text-left ${disabled ? 'bg-slate-200 cursor-not-allowed' : 'bg-slate-50'}`}
                onClick={() => !disabled && setIsOpen(!isOpen)}
                disabled={disabled}
            >
                <span className="truncate">{getButtonLabel()}</span>
                <ChevronDownIcon className="w-5 h-5 text-slate-400" />
            </button>
            {isOpen && !disabled && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-slate-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
                    <ul className="py-1">
                        {options.length > 1 && (
                            <li>
                                <label className="flex items-center w-full px-3 py-2 text-sm text-slate-700 hover:bg-sky-50 cursor-pointer font-semibold border-b">
                                    <input
                                        type="checkbox"
                                        className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 mr-3"
                                        checked={isAllSelected}
                                        onChange={handleSelectAll}
                                    />
                                    Select All
                                </label>
                            </li>
                        )}
                         {options.map(option => (
                            <li key={option.value}>
                                <label className="flex items-center w-full px-3 py-2 text-sm text-slate-700 hover:bg-sky-50 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 mr-3"
                                        checked={selected.includes(option.value)}
                                        onChange={() => handleSelect(option.value)}
                                    />
                                    {option.label}
                                </label>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};


const GlobalFilters: React.FC = () => {
    const {
        productLinesByArea,
        selectedBusinessAreas,
        selectedProductLineIds,
        setSelectedProductLineIds,
        selectedStrategies,
        setSelectedStrategies,
        selectedRegions,
        setSelectedRegions,
    } = useAppContext();

    const regionOptions = useMemo(() => ALL_REGIONS.map(region => ({ value: region, label: region })), []);
    
    const productLineOptions = useMemo(() => {
        if (selectedBusinessAreas.length === 0) return [];
        const options = selectedBusinessAreas.flatMap(area => 
            (productLinesByArea[area] || []).map(pl => ({
                value: pl.id,
                label: pl.name,
            }))
        );
        return Array.from(new Map(options.map(item => [item.value, item])).values());
    }, [selectedBusinessAreas, productLinesByArea]);

    const strategyOptions = useMemo(() => {
        if (selectedProductLineIds.length === 0) return [];
        const allProductLines = selectedBusinessAreas.flatMap(area => productLinesByArea[area] || []);
        const options = allProductLines
            .filter(pl => selectedProductLineIds.includes(pl.id))
            .flatMap(pl => pl.strategies.map(s => ({ value: s.id, label: s.name })));
        
        return Array.from(new Map(options.map(item => [item.value, item])).values());
    }, [selectedBusinessAreas, selectedProductLineIds, productLinesByArea]);
    
    const handleProductLineChange = (ids: string[]) => {
        setSelectedProductLineIds(ids);
        setSelectedStrategies([]);
    };
    
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Division</label>
                <div className="w-full p-2 border border-slate-300 rounded-md text-sm text-slate-800 bg-slate-100 cursor-not-allowed truncate">
                    {BusinessArea.TREASURY_CAPITAL_MARKETS}
                </div>
            </div>
            <MultiSelectDropdown
                label="Product Line"
                name="Product Line"
                options={productLineOptions}
                selected={selectedProductLineIds}
                onChange={handleProductLineChange}
                disabled={selectedBusinessAreas.length === 0}
            />
            <MultiSelectDropdown
                label="Strategy"
                name="Strategy"
                options={strategyOptions}
                selected={selectedStrategies}
                onChange={setSelectedStrategies}
                disabled={selectedProductLineIds.length === 0}
            />
            <MultiSelectDropdown
                label="Region"
                name="Region"
                options={regionOptions}
                selected={selectedRegions}
                onChange={(regions) => setSelectedRegions(regions as Region[])}
            />
        </div>
    );
};

export default GlobalFilters;
