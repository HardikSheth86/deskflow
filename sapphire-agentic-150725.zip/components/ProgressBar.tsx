import React from 'react';
import { ProcessStage } from '../types';

/**
 * @interface ProgressBarProps
 * Defines the props for the ProgressBar component.
 * @property {ProcessStage[]} stages - An array of stage objects to display in the progress bar.
 * @property {string} [currentStageName] - The name of the stage to highlight as the current one.
 */
interface ProgressBarProps {
  stages: Pick<ProcessStage, 'name' | 'status'>[];
  currentStageName?: string;
}

/**
 * A visual component that displays the progress of a multi-stage process.
 * It shows completed, in-progress, and pending stages with color-coding.
 * @param {ProgressBarProps} props - The props for the component.
 * @returns {JSX.Element} The rendered progress bar.
 */
const ProgressBar: React.FC<ProgressBarProps> = ({ stages, currentStageName }) => {
  const getStageColor = (status: 'pending' | 'in-progress' | 'completed' | 'failed', isCurrent: boolean) => {
    if (status === 'completed') return 'bg-green-500';
    if (status === 'in-progress' || isCurrent) return 'bg-sky-500';
    if (status === 'failed') return 'bg-red-500';
    return 'bg-slate-300';
  };
  
  const getTextColor = (status: 'pending' | 'in-progress' | 'completed' | 'failed', isCurrent: boolean) => {
    if (status === 'completed') return 'text-green-700';
    if (status === 'in-progress' || isCurrent) return 'text-sky-700';
    if (status === 'failed') return 'text-red-700';
    return 'text-slate-500';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 md:space-x-4 overflow-x-auto pb-2">
        {stages.map((stage, index) => {
          const isCurrent = stage.name === currentStageName;
          const isActiveOrCompleted = stage.status === 'completed' || stage.status === 'in-progress' || isCurrent;
          return (
          <React.Fragment key={stage.name}>
            <div className="flex flex-col items-center min-w-[80px] md:min-w-[100px]">
              <div
                className={`w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center text-white text-xs md:text-sm font-semibold
                            ${getStageColor(stage.status, isCurrent)} transition-all duration-300 ease-in-out
                            ${isActiveOrCompleted ? 'ring-2 ring-offset-2' : ''} 
                            ${stage.status === 'completed' ? 'ring-green-500' : stage.status === 'in-progress' || isCurrent ? 'ring-sky-500' : stage.status === 'failed' ? 'ring-red-500' : 'ring-slate-300'}`}
              >
                {stage.status === 'completed' ? '✓' : stage.status === 'failed' ? '✗' : index + 1}
              </div>
              <p className={`mt-2 text-xs md:text-sm text-center font-medium ${getTextColor(stage.status, isCurrent)}`}>{stage.name}</p>
            </div>
            {index < stages.length - 1 && (
              <div className={`flex-1 h-1 rounded 
                ${stages[index+1].status !== 'pending' ? getStageColor(stage.status, false) : 'bg-slate-300' }
                min-w-[20px] md:min-w-[30px] transition-all duration-300 ease-in-out`}
              />
            )}
          </React.Fragment>
        )})}
      </div>
    </div>
  );
};


export default ProgressBar;
