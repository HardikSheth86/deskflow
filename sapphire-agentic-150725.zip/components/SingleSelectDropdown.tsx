import React, { useState, useRef, useEffect } from 'react';
import { ChevronDownIcon, ChevronUpIcon } from './icons';

interface SingleSelectOption {
  value: string;
  label: string;
}

interface SingleSelectDropdownProps {
  label: string;
  options: SingleSelectOption[];
  selectedValue: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

const SingleSelectDropdown: React.FC<SingleSelectDropdownProps> = ({
  label,
  options,
  selectedValue,
  onChange,
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [wrapperRef]);

  const handleSelect = (value: string) => {
    onChange(value);
    setIsOpen(false);
  };
  
  const selectedLabel = options.find(o => o.value === selectedValue)?.label || 'Select...';

  return (
    <div className="relative" ref={wrapperRef}>
      <label className="block font-medium text-slate-700 mb-1">{label}</label>
      <button
        type="button"
        className={`w-full p-2 border border-slate-300 rounded-md text-sm text-slate-800 focus:ring-sky-500 focus:border-sky-500 transition-colors flex justify-between items-center text-left ${disabled ? 'bg-slate-200 cursor-not-allowed' : 'bg-white'}`}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <span className="truncate">{selectedLabel}</span>
        {isOpen ? <ChevronUpIcon className="w-5 h-5 text-slate-400" /> : <ChevronDownIcon className="w-5 h-5 text-slate-400" />}
      </button>
      {isOpen && !disabled && (
        <ul
          className="absolute z-10 w-full mt-1 bg-white border border-slate-300 rounded-md shadow-lg max-h-60 overflow-y-auto"
          role="listbox"
        >
          {options.map(option => (
            <li
              key={option.value}
              className={`px-3 py-2 text-sm text-slate-700 hover:bg-sky-50 cursor-pointer ${selectedValue === option.value ? 'font-semibold bg-sky-100' : ''}`}
              onClick={() => handleSelect(option.value)}
              role="option"
              aria-selected={selectedValue === option.value}
            >
              {option.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SingleSelectDropdown;
