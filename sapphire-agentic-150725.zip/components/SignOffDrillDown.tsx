
import React from 'react';
import { SignOffStrategy } from '../types';
import Tabs, { TabItem } from './Tabs';
import { CurrencyDollarIcon, GlobeAmericasIcon, BuildingOfficeIcon, CloseIcon, CalculatorIcon } from './icons';
import { formatCurrency } from '../utils/helpers';
import StatusPill from './StatusPill';

// Mock data for the triple ledger view as it's not in the main types
const mockLedgerData = (strategy: SignOffStrategy) => [
    { metric: 'Net P&L', treasury: strategy.currentNetPnL, bu: strategy.currentNetPnL - 1500, risk: strategy.currentNetPnL + 500 },
    { metric: 'Total Assets', treasury: strategy.currentTotalAssets, bu: strategy.currentTotalAssets, risk: strategy.currentTotalAssets + 50000 },
    { metric: 'Total Liabilities', treasury: strategy.currentTotalLiabilities, bu: strategy.currentTotalLiabilities, risk: strategy.currentTotalLiabilities },
];


const FXExposureView: React.FC<{ strategy: SignOffStrategy }> = ({ strategy }) => (
    <div className="p-2">
        {(strategy.fxExposure && strategy.fxExposure.length > 0) ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {strategy.fxExposure.map(exp => (
                    <div key={exp.currency} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="text-sm font-semibold text-slate-800">{exp.currency}</div>
                        <div className="text-xs text-slate-500">{formatCurrency(exp.amount, exp.currency)}</div>
                    </div>
                ))}
            </div>
        ) : <p className="text-slate-500 text-center py-6">No FX exposure data available for this strategy.</p>}
    </div>
);

const MultiLedgerExposureView: React.FC<{ strategy: SignOffStrategy }> = ({ strategy }) => {
    const data = mockLedgerData(strategy);
    return (
        <div className="p-2">
            <p className="text-xs text-slate-500 mb-2">This is a conceptual view showing how a multi-ledger reconciliation could be displayed, highlighting breaks between systems.</p>
            <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50">
                    <tr>
                        <th className="px-2 py-1 text-left font-semibold text-slate-600">Metric</th>
                        <th className="px-2 py-1 text-right font-semibold text-slate-600">Treasury GL</th>
                        <th className="px-2 py-1 text-right font-semibold text-slate-600">BU Ledger</th>
                        <th className="px-2 py-1 text-right font-semibold text-slate-600">Risk System</th>
                        <th className="px-2 py-1 text-right font-semibold text-slate-600">Max Variance</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100">
                    {data.map(row => {
                        const values = [row.treasury, row.bu, row.risk];
                        const variance = Math.max(...values) - Math.min(...values);
                        return (
                            <tr key={row.metric} className={variance > 0 ? 'bg-yellow-50' : ''}>
                                <td className="px-2 py-1 font-medium">{row.metric}</td>
                                <td className="px-2 py-1 text-right">{formatCurrency(row.treasury, strategy.currency)}</td>
                                <td className="px-2 py-1 text-right">{formatCurrency(row.bu, strategy.currency)}</td>
                                <td className="px-2 py-1 text-right">{formatCurrency(row.risk, strategy.currency)}</td>
                                <td className={`px-2 py-1 text-right font-semibold ${variance > 0 ? 'text-red-600' : ''}`}>{formatCurrency(variance, strategy.currency)}</td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
};

const BreakdownItem: React.FC<{ label: string; value: number; currency: string; }> = ({label, value, currency}) => {
    const valueColor = value >= 0 ? 'text-green-700' : 'text-red-700';
    return (
        <div className="flex justify-between py-1 text-sm">
            <span className="text-slate-600">{label}:</span>
            <span className={`font-medium ${valueColor}`}>{formatCurrency(value, currency, true)}</span>
        </div>
    );
};

const EntityDetailsView: React.FC<{ strategy: SignOffStrategy }> = ({ strategy }) => (
    <div className="p-2 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <h4 className="font-semibold text-slate-700 mb-2">Legal Entity Details</h4>
            {(strategy.entityDetails && strategy.entityDetails.length > 0) ? (
                <div className="space-y-2">
                    {strategy.entityDetails.map(detail => (
                        <div key={detail.name} className="p-2 bg-slate-50 rounded-md">
                            <div className="text-xs font-medium text-slate-500">{detail.name}</div>
                            <div className="text-sm font-semibold text-slate-800">{detail.value}</div>
                        </div>
                    ))}
                </div>
            ) : <p className="text-slate-500 text-center py-6">No entity details available.</p>}
        </div>
         <div className="bg-white p-3 rounded-lg border border-slate-200">
          <h5 className="font-semibold text-slate-700 mb-2 text-md">P&L Breakdown</h5>
          <BreakdownItem label="Trading P&L" value={strategy.pnlTrading} currency={strategy.currency} />
          <BreakdownItem label="FX Revaluation P&L" value={strategy.pnlFxReval} currency={strategy.currency} />
          <BreakdownItem label="Adjustments & Fees P&L" value={strategy.pnlAdjustments} currency={strategy.currency} />
          <hr className="my-1 border-slate-200"/>
          <BreakdownItem label="Total P&L Change" value={strategy.currentNetPnL - strategy.previousNetPnL} currency={strategy.currency} />
        </div>
    </div>
);


interface SignOffDrillDownProps {
  strategy: SignOffStrategy;
  onClose: () => void;
}

const SignOffDrillDown: React.FC<SignOffDrillDownProps> = ({ strategy, onClose }) => {
    
    const tabs: TabItem[] = [
        { label: 'FX Exposure', icon: GlobeAmericasIcon, content: <FXExposureView strategy={strategy} /> },
        { label: 'Multi-Ledger Exposure', icon: CurrencyDollarIcon, content: <MultiLedgerExposureView strategy={strategy} /> },
        { label: 'Entity P&L Details', icon: BuildingOfficeIcon, content: <EntityDetailsView strategy={strategy} /> },
    ];

    return (
        <div className="animate-slideUp">
            <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold text-lg text-slate-800">Drill-Down: {strategy.name}</h3>
                <button onClick={onClose} className="p-1 rounded-full text-slate-500 hover:bg-slate-200" aria-label="Close drill-down view">
                    <CloseIcon className="w-5 h-5" />
                </button>
            </div>
            <div className="bg-white p-2 rounded-lg border border-slate-200">
                <Tabs tabs={tabs} />
            </div>
        </div>
    );
};

export default SignOffDrillDown;