import React from 'react';
import { ReportItem } from '../types';
import { EyeIcon, SendIcon } from './icons';

interface ReportCardProps {
    report: ReportItem;
    onView: (report: ReportItem) => void;
    onSend: (report: ReportItem) => void;
}

const getFrequencyColor = (frequency: 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly'): string => {
    const colors = {
        Daily: 'bg-blue-100 text-blue-800 border-blue-300',
        Weekly: 'bg-teal-100 text-teal-800 border-teal-300',
        Monthly: 'bg-amber-100 text-amber-800 border-amber-300',
        Quarterly: 'bg-purple-100 text-purple-800 border-purple-300',
    };
    return colors[frequency];
};


const ReportCard: React.FC<ReportCardProps> = ({ report, onView, onSend }) => {
    const frequencyColor = getFrequencyColor(report.frequency);
    return (
       <div className="p-4 border border-slate-200 rounded-lg bg-white hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full">
            <div className="flex-grow">
                <div className="flex justify-between items-start mb-2">
                    <report.icon className="w-9 h-9 text-sky-600 flex-shrink-0" />
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold border ${frequencyColor}`}>
                        {report.frequency}
                    </span>
                </div>
                <h4 className="text-md font-semibold text-slate-800 mt-3">{report.title}</h4>
                <p className="text-xs text-slate-500 mt-1 flex-grow">{report.description}</p>
            </div>
            <div className="flex space-x-2 mt-4 pt-3 border-t border-slate-100">
                <button onClick={() => onView(report)} className="w-full px-3 py-1.5 bg-sky-500 text-white rounded-md hover:bg-sky-600 text-xs font-medium flex items-center justify-center">
                    <EyeIcon className="w-4 h-4 mr-1.5" /> View
                </button>
                <button onClick={() => onSend(report)} className="w-full px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 text-xs font-medium flex items-center justify-center">
                    <SendIcon className="w-4 h-4 mr-1.5" /> Send
                </button>
            </div>
        </div>
    );
};

export default ReportCard;
