
import React from 'react';
import { DrillDownContentType } from '../types';
import Modal from './Modal';
import { RenderPositionDetails, RenderTradeDetails } from './DrillDownViews';

interface DrillDownInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  content: DrillDownContentType | null;
}

/**
 * A modal to display detailed drill-down information, which can be either
 * position-specific attributes or a list of associated trades.
 * @param {DrillDownInfoModalProps} props - The props for the component.
 * @returns {JSX.Element | null} The rendered modal component.
 */
const DrillDownInfoModal: React.FC<DrillDownInfoModalProps> = ({ isOpen, onClose, content }) => {
  if (!isOpen || !content) return null;

  const title = content.type === 'position' 
    ? `Position Details: ${content.data.positionId}` 
    : 'Associated Trade Details';

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="lg">
      {content.type === 'position' && <RenderPositionDetails data={content.data} />}
      {content.type === 'trades' && <RenderTradeDetails data={content.data} />}
    </Modal>
  );
};

export default DrillDownInfoModal;
