
import React, { useMemo } from 'react';
import { PreSignOffCheckType, PreSignOffTask } from '../types';
import { MOCK_PRE_SIGN_OFF_DRILLDOWN_DATA } from '../constants';
import { formatCurrency } from '../utils/helpers';

// Sub-component for T0-T1 check
const T0T1View: React.FC<{ data: any[] }> = ({ data }) => (
  <table className="min-w-full divide-y divide-slate-200 text-sm">
    <thead className="bg-slate-50">
      <tr>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Metric</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">T0 Value (Estimate)</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">T1 Value (Actual)</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Variance</th>
      </tr>
    </thead>
    <tbody className="bg-white divide-y divide-slate-100">
      {data.map((item, index) => (
        <tr key={index} className={item.variance !== 0 ? 'bg-yellow-50' : ''}>
          <td className="px-3 py-2 font-medium text-slate-700">{item.metric}</td>
          <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(item.t0Value, item.currency)}</td>
          <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(item.t1Value, item.currency)}</td>
          <td className={`px-3 py-2 text-right font-semibold ${item.variance !== 0 ? 'text-red-600' : 'text-slate-600'}`}>{formatCurrency(item.variance, item.currency)}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

// Sub-component for VRS check
const VrsView: React.FC<{ data: any[] }> = ({ data }) => (
  <table className="min-w-full divide-y divide-slate-200 text-sm">
    <thead className="bg-slate-50">
      <tr>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Position ID</th>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">CUSIP</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Risk System Value</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Finance Ledger Value</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Difference</th>
      </tr>
    </thead>
    <tbody className="bg-white divide-y divide-slate-100">
      {data.map((item, index) => (
        <tr key={index} className={item.difference !== 0 ? 'bg-yellow-50' : ''}>
          <td className="px-3 py-2 font-medium text-slate-700">{item.positionId}</td>
          <td className="px-3 py-2 text-slate-600">{item.cusip}</td>
          <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(item.riskSystemValue, item.currency)}</td>
          <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(item.financeLedgerValue, item.currency)}</td>
          <td className={`px-3 py-2 text-right font-semibold ${item.difference !== 0 ? 'text-red-600' : 'text-slate-600'}`}>{formatCurrency(item.difference, item.currency)}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

// Sub-component for Cancel/Correct check
const CancelCorrectView: React.FC<{ data: any[] }> = ({ data }) => (
  <table className="min-w-full divide-y divide-slate-200 text-sm">
    <thead className="bg-slate-50">
      <tr>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Trader ID</th>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Original Trade</th>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Corrected Trade</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Time to Correct (ms)</th>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Reason</th>
      </tr>
    </thead>
    <tbody className="bg-white divide-y divide-slate-100">
      {data.map((item, index) => (
        <tr key={index} className={'bg-yellow-50'}>
          <td className="px-3 py-2 font-medium text-slate-700">{item.traderId}</td>
          <td className="px-3 py-2 text-slate-600">{item.originalTradeId}</td>
          <td className="px-3 py-2 text-slate-600">{item.correctedTradeId}</td>
          <td className="px-3 py-2 text-right text-slate-600">{item.timeToCorrectMs}</td>
          <td className="px-3 py-2 text-slate-600">{item.reasonForCancel}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

// Sub-component for EVE check
const EveView: React.FC<{ data: any[] }> = ({ data }) => (
  <table className="min-w-full divide-y divide-slate-200 text-sm">
    <thead className="bg-slate-50">
      <tr>
        <th className="px-3 py-2 text-left font-semibold text-slate-600">Position ID</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Ops Ledger Value</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Finance Ledger Value</th>
        <th className="px-3 py-2 text-right font-semibold text-slate-600">Difference</th>
      </tr>
    </thead>
    <tbody className="bg-white divide-y divide-slate-100">
      {data.map((item, index) => (
        <tr key={index} className={item.difference !== 0 ? 'bg-yellow-50' : ''}>
          <td className="px-3 py-2 font-medium text-slate-700">{item.positionId}</td>
          <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(item.opsLedgerValue, item.currency)}</td>
          <td className="px-3 py-2 text-right text-slate-600">{formatCurrency(item.financeLedgerValue, item.currency)}</td>
          <td className={`px-3 py-2 text-right font-semibold ${item.difference !== 0 ? 'text-red-600' : 'text-slate-600'}`}>{formatCurrency(item.difference, item.currency)}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

interface PreSignOffDrillDownViewProps {
  task: PreSignOffTask;
}

const PreSignOffDrillDownView: React.FC<PreSignOffDrillDownViewProps> = ({ task }) => {
  const drillDownData = useMemo(() => MOCK_PRE_SIGN_OFF_DRILLDOWN_DATA[task.id] || null, [task.id]);

  if (!drillDownData) {
    return (
      <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm text-center text-slate-500">
        No drill-down data available for this task.
      </div>
    );
  }
  
  const renderContent = () => {
      switch (drillDownData.details.type) {
        case PreSignOffCheckType.T0_T1:
          return <T0T1View data={drillDownData.details.data} />;
        case PreSignOffCheckType.VRS:
          return <VrsView data={drillDownData.details.data} />;
        case PreSignOffCheckType.CANCEL_CORRECT:
          return <CancelCorrectView data={drillDownData.details.data} />;
        case PreSignOffCheckType.EVE:
          return <EveView data={drillDownData.details.data} />;
        default:
          return <p>Unsupported check type for drill-down.</p>;
      }
  };

  return (
    <div className="p-1 bg-white rounded-lg">
      <div className="max-h-96 overflow-y-auto overflow-x-auto rounded-lg border border-slate-200">
        {renderContent()}
      </div>
    </div>
  );
};

export default PreSignOffDrillDownView;
