import React, { useState, ReactNode, useEffect } from 'react';

export interface TabItem {
  label: string;
  content: ReactNode;
  icon?: (props: React.SVGProps<SVGSVGElement>) => React.ReactNode;
  disabled?: boolean;
}

interface TabsProps {
  tabs: TabItem[];
  initialActiveTabIndex?: number;
}

const Tabs: React.FC<TabsProps> = ({ tabs, initialActiveTabIndex = 0 }) => {
  const [activeTabIndex, setActiveTabIndex] = useState(initialActiveTabIndex);

  useEffect(() => {
    // Update active tab if initialActiveTabIndex changes externally (e.g. parent component logic)
    // This is useful if the modal re-renders with a new item but is still "open" conceptually.
    setActiveTabIndex(initialActiveTabIndex);
  }, [initialActiveTabIndex]);

  const handleTabClick = (index: number) => {
    if (!tabs[index].disabled) {
      setActiveTabIndex(index);
    }
  };

  return (
    <div className="w-full">
      <div className="border-b border-slate-300">
        <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
          {tabs.map((tab, index) => (
            <button
              key={tab.label}
              onClick={() => handleTabClick(index)}
              disabled={tab.disabled}
              className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors
                ${
                  activeTabIndex === index
                    ? 'border-sky-500 text-sky-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-400'
                }
                ${tab.disabled ? 'opacity-50 cursor-not-allowed' : ''}
              `}
              aria-current={activeTabIndex === index ? 'page' : undefined}
            >
              <div className="flex items-center">
                {tab.icon && <tab.icon className={`w-5 h-5 mr-2 ${activeTabIndex === index ? 'text-sky-600' : 'text-slate-500'}`} />}
                {tab.label}
              </div>
            </button>
          ))}
        </nav>
      </div>
      <div className="py-4">
        {tabs[activeTabIndex] && tabs[activeTabIndex].content}
      </div>
    </div>
  );
};

export default Tabs;