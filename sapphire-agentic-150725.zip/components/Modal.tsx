import React, { ReactNode, useEffect, useRef } from 'react';
import { CloseIcon } from './icons';

/**
 * @interface ModalProps
 * Defines the props for the Modal component.
 * @property {boolean} isOpen - Controls whether the modal is visible.
 * @property {() => void} onClose - Function to call when the modal should be closed.
 * @property {string} [title] - Optional title displayed in the modal's header. Not used for fullscreen modals.
 * @property {ReactNode} children - The content to be rendered inside the modal.
 * @property {'sm' | 'md' | 'lg' | 'xl'} [size='md'] - The size of the modal window.
 * @property {boolean} [fullScreen=false] - If true, the modal takes up the entire screen.
 */
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  fullScreen?: boolean;
}

/**
 * A highly reusable and accessible modal component that supports standard and fullscreen modes.
 * It includes features like focus trapping and closing via the Escape key for accessibility.
 * @param {ModalProps} props - The props for the component.
 * @returns {JSX.Element | null} The rendered modal component or null if not open.
 */
const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, size = 'md', fullScreen = false }) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);

  /**
   * Effect to handle accessibility features like focus trapping and keyboard events (Escape key).
   * When the modal opens, it saves the previously focused element and sets focus to the first
   * focusable element within the modal. It traps the focus within the modal and restores focus
   * to the original element when the modal closes.
   */
  useEffect(() => {
    if (isOpen) {
      previousFocusRef.current = document.activeElement as HTMLElement;
      const focusableElements = modalRef.current?.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      
      // Focus the first focusable element on modal open
      focusableElements?.[0]?.focus();

      const handleKeyDown = (event: KeyboardEvent) => {
        // Close modal on Escape key
        if (event.key === 'Escape') {
          onClose();
        }
        
        // Trap focus within the modal
        if (event.key === 'Tab' && modalRef.current && focusableElements && focusableElements.length > 0) {
          const firstElement = focusableElements[0];
          const lastElement = focusableElements[focusableElements.length - 1];

          if (event.shiftKey) { // Shift+Tab
            if (document.activeElement === firstElement) {
              lastElement.focus();
              event.preventDefault();
            }
          } else { // Tab
            if (document.activeElement === lastElement) {
              firstElement.focus();
              event.preventDefault();
            }
          }
        }
      };

      document.addEventListener('keydown', handleKeyDown);

      // Cleanup function to remove event listeners and restore focus
      return () => {
        document.removeEventListener('keydown', handleKeyDown);
        if (previousFocusRef.current) {
          previousFocusRef.current.focus();
        }
      };
    }
  }, [isOpen, onClose]);


  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
  };

  // Render fullscreen variant
  if (fullScreen) {
    return (
      <div 
        ref={modalRef}
        className="fixed inset-0 bg-slate-100 z-50 flex flex-col animate-modalShowFullScreen"
        role="dialog"
        aria-modal="true"
      >
        {children}
         <style>{`
          @keyframes modalShowFullScreen {
            from { opacity: 0.8; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-modalShowFullScreen {
            animation: modalShowFullScreen 0.3s ease-out forwards;
          }
        `}</style>
      </div>
    );
  }

  // Render standard modal variant
  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? 'modal-title' : undefined}
    >
      <div 
        ref={modalRef} 
        onClick={(e) => e.stopPropagation()}
        className={`bg-white rounded-lg shadow-xl w-full ${sizeClasses[size]} flex flex-col overflow-hidden transform transition-all duration-300 ease-in-out scale-95 opacity-0 animate-modalShow`}
      >
        {title && (
          <div className="flex justify-between items-center p-4 border-b border-slate-200 flex-shrink-0">
            <h2 id="modal-title" className="text-xl font-semibold text-slate-700">{title}</h2>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 transition-colors"
              aria-label="Close modal"
            >
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        )}
        <div className="p-6 max-h-[70vh] overflow-y-auto flex-grow">
          {children}
        </div>
      </div>
      <style>{`
        @keyframes modalShow {
          to {
            transform: scale(1);
            opacity: 1;
          }
        }
        .animate-modalShow {
          animation: modalShow 0.3s forwards;
        }
      `}</style>
    </div>
  );
};

export default Modal;
