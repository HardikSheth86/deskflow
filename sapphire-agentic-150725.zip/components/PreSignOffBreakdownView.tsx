import React from 'react';
import { PreSignOffTask } from '../types';
import { ListBulletIcon } from './icons';

interface PreSignOffBreakdownViewProps {
  task: PreSignOffTask;
}

const getSeverityPill = (severity: 'High' | 'Medium' | 'Low') => {
    switch (severity) {
        case 'High': return 'bg-red-100 text-red-700';
        case 'Medium': return 'bg-yellow-100 text-yellow-700';
        case 'Low': return 'bg-green-100 text-green-700';
        default: return 'bg-slate-100 text-slate-700';
    }
}

const PreSignOffBreakdownView: React.FC<PreSignOffBreakdownViewProps> = ({ task }) => {
  if (!task.breakDetails || task.breakDetails.length === 0) {
    return (
        <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm text-center text-slate-500">
            No break details available for this task.
        </div>
    );
  }

  return (
    <div className="p-1 bg-white rounded-lg">
      <h4 className="text-md font-semibold text-slate-700 mb-2 flex items-center">
        <ListBulletIcon className="w-5 h-5 mr-2 text-red-600" />
        Identified Breaks ({task.breakCount})
      </h4>
      <div className="max-h-64 overflow-y-auto">
        <table className="min-w-full divide-y divide-slate-200 text-sm">
          <thead className="bg-slate-50 sticky top-0">
            <tr>
              <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase">Break ID</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase">Description</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase hidden sm:table-cell">Related Entity</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase">Severity</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-100">
            {task.breakDetails.map((detail) => (
              <tr key={detail.id}>
                <td className="px-3 py-2 whitespace-nowrap text-sky-600 font-medium">{detail.id}</td>
                <td className="px-3 py-2">{detail.description}</td>
                <td className="px-3 py-2 whitespace-nowrap hidden sm:table-cell">{detail.relatedEntity || 'N/A'}</td>
                <td className="px-3 py-2 whitespace-nowrap">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${getSeverityPill(detail.severity)}`}>
                      {detail.severity}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PreSignOffBreakdownView;
