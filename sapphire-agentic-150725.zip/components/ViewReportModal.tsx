
import React from 'react';
import Modal from './Modal';

interface ViewReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportTitle?: string;
}

/**
 * A placeholder modal for viewing a report.
 * This component is not currently used but is implemented to ensure the project builds correctly.
 * The FullScreenReportViewer is used instead for a more immersive experience.
 */
const ViewReportModal: React.FC<ViewReportModalProps> = ({ isOpen, onClose, reportTitle }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={reportTitle || "View Report"}>
      <div className="text-center p-4">
        <p className="text-slate-600">This is a placeholder for viewing a report.</p>
        <p className="text-slate-500 text-sm mt-2">In a real implementation, this would contain a rendered report or embedded viewer.</p>
      </div>
    </Modal>
  );
};

export default ViewReportModal;
