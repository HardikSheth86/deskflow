import React from 'react';
import { NavLink } from 'react-router-dom';
import { NavItemType } from '../types';
import { 
    DashboardIcon, ExceptionIcon, AdjustmentIcon, SignOffIcon, 
    CommentaryIcon, AnalyticsIcon, CaseManagementIcon, 
    ClipboardDocumentCheckIcon, MagnifyingGlassIcon, UserCircleIcon,
    PresentationChartLineIcon,
    BookOpenIcon,
    BeakerIcon,
} from './icons';
import { SapphireLogo } from './logo';

const navItems: NavItemType[] = [
  { path: '/', name: 'Dashboard', icon: DashboardIcon },
  { path: '/exceptions', name: 'Exceptions', icon: ExceptionIcon },
  { path: '/investigation', name: 'Investigation', icon: MagnifyingGlassIcon },
  { path: '/adjustments', name: 'Adjustments', icon: AdjustmentIcon },
  { path: '/presignoff', name: 'Pre-Sign Off', icon: ClipboardDocumentCheckIcon },
  { path: '/sign-off', name: 'Sign-Off', icon: SignOffIcon },
  { path: '/commentary', name: 'Commentary', icon: CommentaryIcon },
  { path: '/analytics', name: 'Analytics', icon: AnalyticsIcon },  
  { path: '/trader-review', name: 'Trader Review', icon: UserCircleIcon },
  { path: '/management', name: 'Management', icon: PresentationChartLineIcon },
];

const utilityNavItems: NavItemType[] = [
    { path: '/testing', name: 'Testing', icon: BeakerIcon },
    { path: '/documentation', name: 'Documentation', icon: BookOpenIcon },
    { path: '/cases', name: 'Case Management', icon: CaseManagementIcon },
]

const TopNav: React.FC = () => {
  return (
    <div className="bg-slate-800 text-slate-100 p-3 shadow-lg sticky top-0 z-50 flex items-center justify-between h-16">
      {/* Left Section: App Title and Navigation */}
      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-3">
          <SapphireLogo className="w-10 h-10" />
          <div>
            <div className="text-xl font-semibold text-sky-400">Sapphire</div>
            <div className="text-xs text-slate-400 -mt-1">AI powered Finance Control Application</div>
          </div>
        </div>
        <nav>
          <ul className="flex items-center space-x-1">
            {navItems.map((item) => (
              <li key={item.name}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-slate-700 transition-colors text-sm ${
                      isActive ? 'bg-sky-600 text-white shadow-md' : 'text-slate-300 hover:text-white'
                    }`
                  }
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Right Section: Utility Nav and User Info */}
      <div className="flex items-center space-x-4">
        <nav>
          <ul className="flex items-center space-x-1">
            {utilityNavItems.map((item) => (
               <li key={item.name}>
                <NavLink
                  to={item.path}
                  title={item.name}
                  className={({ isActive }) =>
                    `flex items-center space-x-2 p-2 rounded-md hover:bg-slate-700 transition-colors text-sm ${
                      isActive ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                    }`
                  }
                >
                  <item.icon className="w-5 h-5" />
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
         <div className="h-8 w-px bg-slate-600"></div> {/* Separator */}
        <div className="flex items-center space-x-2">
           <img src={`https://picsum.photos/seed/Valerie/32/32`} alt="User Avatar" className="w-8 h-8 rounded-full border-2 border-sky-500" />
           <div>
              <p className="text-sm font-medium text-slate-200">Valerie User</p>
              <p className="text-xs text-slate-400">Back Office Analyst</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default TopNav;