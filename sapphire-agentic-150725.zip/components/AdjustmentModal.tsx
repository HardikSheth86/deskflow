import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { Adjustment, AdjustmentType, AdjustmentStatus, Exception, BusinessArea, Region } from '../types';
import { LightbulbIcon, PlusCircleIcon, SendIcon } from './icons';
import { useAppContext } from '../hooks/useAppContext';
import SingleSelectDropdown from './SingleSelectDropdown';

interface AdjustmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (adjustment: Adjustment) => void;
  exception?: Exception | null;
  existingAdjustment?: Adjustment | null;
  prefilledType?: AdjustmentType;
  isAiGenerated?: boolean;
}

export const AdjustmentModal: React.FC<AdjustmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  exception,
  existingAdjustment,
  prefilledType,
  isAiGenerated = false,
}) => {
  const { selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions } = useAppContext();
  const [id, setId] = useState<string>('');
  const [type, setType] = useState<AdjustmentType>(AdjustmentType.OTHER);
  const [amount, setAmount] = useState<string>('');
  const [currency, setCurrency] = useState<string>('USD');
  const [debitAccount, setDebitAccount] = useState<string>('');
  const [creditAccount, setCreditAccount] = useState<string>('');
  const [justification, setJustification] = useState<string>('');
  const [status, setStatus] = useState<AdjustmentStatus>('SUBMITTED');
  const [relatedExceptionId, setRelatedExceptionId] = useState<string | undefined>(undefined);

  // AI Suggestion state (mirrors Adjustment type for display)
  const [suggestedData, setSuggestedData] = useState<{
    amount?: number;
    currency?: string;
    debitAccount?: string;
    creditAccount?: string;
    justification?: string;
  }>({});
  
  const inputBaseClasses = "w-full p-2 bg-white border border-slate-300 rounded-md text-slate-800 focus:ring-2 focus:ring-sky-500 focus:outline-none transition-colors";

  useEffect(() => {
    if (isOpen) {
      if (existingAdjustment) {
        setId(existingAdjustment.id);
        setType(existingAdjustment.type);
        setAmount(existingAdjustment.amount.toString());
        setCurrency(existingAdjustment.currency);
        setDebitAccount(existingAdjustment.debitAccount);
        setCreditAccount(existingAdjustment.creditAccount);
        setJustification(existingAdjustment.justification);
        setStatus(existingAdjustment.status);
        setRelatedExceptionId(existingAdjustment.relatedExceptionId);
        setSuggestedData({
            amount: existingAdjustment.suggestedAmount,
            currency: existingAdjustment.suggestedCurrency,
            debitAccount: existingAdjustment.suggestedDebitAccount,
            creditAccount: existingAdjustment.suggestedCreditAccount,
            justification: existingAdjustment.suggestedJustification,
        });
      } else if (exception) {
        setId(`ADJ-${Date.now()}`);
        setType(prefilledType || AdjustmentType.PNL_CORRECTION);
        setAmount(''); 
        setCurrency(exception.position.currency);
        setDebitAccount('');
        setCreditAccount('');
        setJustification(`Adjustment for exception ${exception.id}: ${exception.description}`);
        setStatus('SUBMITTED');
        setRelatedExceptionId(exception.id);
        // Mock AI suggestions based on exception
        setSuggestedData({
            amount: Math.abs(exception.financialImpact),
            currency: exception.position.currency,
            debitAccount: exception.financialImpact < 0 ? 'PNL_CORRECTION_DR' : 'SUSPENSE_DR',
            creditAccount: exception.financialImpact < 0 ? 'SUSPENSE_CR' : 'PNL_CORRECTION_CR',
            justification: `AI Suggestion: Resolve ${exception.category} exception ${exception.id}. Financial impact ${exception.financialImpact.toLocaleString()} ${exception.position.currency}. ${exception.aiRcaCommentary ? `RCA: ${exception.aiRcaCommentary.substring(0,100)}...` : ''}`,
        });
      } else {
        // New standalone adjustment
        setId(`ADJ-${Date.now()}`);
        setType(prefilledType || AdjustmentType.OTHER);
        setAmount('');
        setCurrency('USD');
        setDebitAccount('');
        setCreditAccount('');
        setJustification('');
        setStatus('SUBMITTED');
        setRelatedExceptionId(undefined);
        setSuggestedData({ justification: "AI Suggestion: For a new adjustment, consider common types like inter-company transfers or reclassifications."});
      }
    }
  }, [isOpen, existingAdjustment, exception, prefilledType]);

  const handleApplySuggestions = () => {
    if (suggestedData.amount) setAmount(suggestedData.amount.toString());
    if (suggestedData.currency) setCurrency(suggestedData.currency);
    if (suggestedData.debitAccount) setDebitAccount(suggestedData.debitAccount);
    if (suggestedData.creditAccount) setCreditAccount(suggestedData.creditAccount);
    if (suggestedData.justification) setJustification(suggestedData.justification);
  };

  const handleSubmit = () => {
    if (!amount || isNaN(parseFloat(amount))) {
      alert('Please enter a valid amount.');
      return;
    }
    if (!debitAccount.trim() || !creditAccount.trim()) {
      alert('Debit and Credit accounts cannot be empty.');
      return;
    }
    if (!justification.trim()) {
        alert('Justification cannot be empty.');
        return;
    }

    const adjustmentData: Adjustment = {
      id,
      relatedExceptionId,
      type,
      amount: parseFloat(amount),
      currency,
      debitAccount: debitAccount.trim(),
      creditAccount: creditAccount.trim(),
      justification: justification.trim(),
      status: 'SUBMITTED',
      createdBy: existingAdjustment?.createdBy || 'Valerie User', // Mock user
      createdAt: existingAdjustment?.createdAt || new Date().toISOString(),
      businessArea: existingAdjustment?.businessArea || exception?.businessArea || selectedBusinessAreas[0],
      productLineId: existingAdjustment?.productLineId || exception?.productLineId || selectedProductLineIds[0] || 'ALL',
      strategyId: existingAdjustment?.strategyId || exception?.strategyId || selectedStrategies[0] || 'ALL',
      region: existingAdjustment?.region || exception?.region || selectedRegions[0],
      lastModifiedAt: new Date().toISOString(),
      submittedBy: 'Valerie User',
      submittedAt: new Date().toISOString(),
      // AI suggestion fields would be part of the existingAdjustment or could be saved if this was a real DB
      suggestedAmount: suggestedData.amount,
      suggestedCurrency: suggestedData.currency,
      suggestedDebitAccount: suggestedData.debitAccount,
      suggestedCreditAccount: suggestedData.creditAccount,
      suggestedJustification: suggestedData.justification,
    };
    
    onSave(adjustmentData);
    onClose();
  };
  
  const adjustmentTypeOptions = Object.values(AdjustmentType).map(value => ({ value, label: value}));

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={existingAdjustment ? `Edit Adjustment: ${existingAdjustment.id}` : 'Create New Adjustment'} 
        size="xl"
    >
      <div className="space-y-6 text-sm">
        {isAiGenerated && (
            <div className="p-3 bg-indigo-100 border-l-4 border-indigo-400 text-indigo-800 rounded-r-lg">
                <p className="font-semibold flex items-center">
                    <LightbulbIcon className="w-5 h-5 mr-2" />
                    AI has proposed the following adjustment. Please review and submit.
                </p>
            </div>
        )}
        {relatedExceptionId && (
            <div className="p-3 bg-sky-100 border-l-4 border-sky-400 text-sky-900 rounded-r-lg text-sm font-medium">
                Linked to Exception: <span className="font-semibold">{relatedExceptionId}</span>
            </div>
        )}

        {/* Suggestive Adjustment Details */}
        {(suggestedData.amount || suggestedData.debitAccount || suggestedData.justification) && !isAiGenerated && (
             <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 space-y-2">
                <div className="flex justify-between items-center">
                    <h4 className="font-semibold text-yellow-800 flex items-center">
                    <LightbulbIcon className="w-5 h-5 mr-2" />
                    AI Suggestion Available
                    </h4>
                    <button
                        onClick={handleApplySuggestions}
                        className="px-3 py-1 bg-yellow-400 text-black rounded-md hover:bg-yellow-500 text-xs font-semibold flex items-center"
                    >
                        <PlusCircleIcon className="w-4 h-4 mr-1" /> Apply Suggestion
                    </button>
                </div>
                {suggestedData.justification && <p className="italic text-yellow-800"><strong>Justification:</strong> {suggestedData.justification}</p>}
            </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
                 <SingleSelectDropdown
                    label="Adjustment Type"
                    options={adjustmentTypeOptions}
                    selectedValue={type}
                    onChange={(value) => setType(value as AdjustmentType)}
                />
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="adj-amount" className="block font-medium text-slate-700 mb-1">Amount</label>
                    <input type="number" id="adj-amount" value={amount} onChange={(e) => setAmount(e.target.value)} className={inputBaseClasses} placeholder="e.g., 1000.00" />
                </div>
                <div>
                    <label htmlFor="adj-currency" className="block font-medium text-slate-700 mb-1">Currency</label>
                    <input type="text" id="adj-currency" value={currency} onChange={(e) => setCurrency(e.target.value.toUpperCase())} className={inputBaseClasses} placeholder="e.g., USD" maxLength={3} />
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
             <div>
                <label htmlFor="adj-debit" className="block font-medium text-slate-700 mb-1">Debit Account</label>
                <input type="text" id="adj-debit" value={debitAccount} onChange={(e) => setDebitAccount(e.target.value)} className={inputBaseClasses} placeholder="Enter debit account"/>
            </div>
            <div>
                <label htmlFor="adj-credit" className="block font-medium text-slate-700 mb-1">Credit Account</label>
                <input type="text" id="adj-credit" value={creditAccount} onChange={(e) => setCreditAccount(e.target.value)} className={inputBaseClasses} placeholder="Enter credit account" />
            </div>
        </div>
       
        <div>
            <label htmlFor="adj-justification" className="block font-medium text-slate-700 mb-1">Justification</label>
            <textarea id="adj-justification" value={justification} onChange={(e) => setJustification(e.target.value)} rows={4} className={inputBaseClasses} placeholder="Detailed reason for the adjustment..."></textarea>
        </div>
        
        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 border-t pt-4">
          <button 
            onClick={handleSubmit}
            className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center justify-center"
            title="Submit Adjustment"
          >
            <SendIcon className="w-5 h-5 mr-1.5" />
            Submit Adjustment
          </button>
        </div>
      </div>
    </Modal>
  );
};