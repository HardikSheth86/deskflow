
import React, { useState, useEffect, useMemo } from 'react';
import { SignOffProductLine, SignOffStrategy, ProcessStatus, ActivityLogItem, Adjustment } from '../types';
import Modal from './Modal';
import Tabs, { TabItem } from './Tabs'; 
import { 
    CheckCircleIcon, XCircleIcon, InformationCircleIcon, 
    CalculatorIcon, ListBulletIcon, PencilIcon, BranchIcon, EyeIcon,
    CloseIcon, TableCellsIcon, GlobeAmericasIcon, BuildingOfficeIcon
} from './icons';
import { useAppContext } from '../hooks/useAppContext';
import { formatCurrency, calculateDoDChange } from '../utils/helpers';
import StatusPill from './StatusPill';

// --- Sub-Components for Tab Content (Extracted for Performance and Readability) ---

const FinancialMetricDisplay: React.FC<{ label: string; sodValue: number; eodValue: number; currency: string; isPnL?: boolean; }> = ({ label, sodValue, eodValue, currency, isPnL = false }) => {
  const dodChange = calculateDoDChange(eodValue, sodValue);
  const varianceColor = dodChange.isPositive ? (isPnL ? 'text-green-600' : 'text-green-600') : 'text-red-600';
  return (
    <div className="py-3 px-1">
      <h5 className="text-base font-semibold text-slate-800 mb-1">{label}</h5>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-3 text-sm">
        <div><span className="text-slate-500 block text-xs">SOD Value:</span>{formatCurrency(sodValue, currency)}</div>
        <div><span className="text-slate-500 block text-xs">EOD Value:</span>{formatCurrency(eodValue, currency)}</div>
        <div className={varianceColor}><span className="text-slate-500 block text-xs">Variance:</span>{formatCurrency(dodChange.amount, currency, true)}<span className="block text-xs">({dodChange.percentage}%)</span></div>
      </div>
    </div>
  );
};

const BreakdownItem: React.FC<{ label: string; value: number; currency: string; }> = ({label, value, currency}) => {
    const valueColor = value >= 0 ? 'text-green-700' : 'text-red-700';
    return (
        <div className="flex justify-between py-1.5 text-sm">
            <span className="text-slate-600">{label}:</span>
            <span className={`font-medium ${valueColor}`}>{formatCurrency(value, currency, true)}</span>
        </div>
    );
};

const SummaryView: React.FC<{item: SignOffProductLine | SignOffStrategy}> = ({ item }) => (
    <div className="space-y-6">
        <div className="p-4 bg-white rounded-lg border border-slate-200 shadow">
          <h4 className="text-lg font-semibold text-slate-700 mb-2">Current Status: 
            <span className="ml-2"><StatusPill status={item.status} /></span>
          </h4>
          <p className="text-sm text-slate-500">Last Updated: {new Date(item.lastUpdated).toLocaleString()}</p>
        </div>
         <div className="bg-white p-4 rounded-lg border border-slate-200 shadow divide-y divide-slate-200">
            <FinancialMetricDisplay label="Net P&L" sodValue={item.previousNetPnL} eodValue={item.currentNetPnL} currency={item.currency} isPnL={true} />
            <FinancialMetricDisplay label="Total Assets" sodValue={item.previousTotalAssets} eodValue={item.currentTotalAssets} currency={item.currency} />
            <FinancialMetricDisplay label="Total Liabilities" sodValue={item.previousTotalLiabilities} eodValue={item.currentTotalLiabilities} currency={item.currency} />
        </div>
    </div>
);

const BreakdownView: React.FC<{item: SignOffStrategy}> = ({ item }) => (
    <div className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow">
              <h5 className="font-semibold text-slate-700 mb-2 text-md">P&L Breakdown</h5>
              <BreakdownItem label="Trading P&L" value={item.pnlTrading} currency={item.currency} />
              <BreakdownItem label="FX Revaluation P&L" value={item.pnlFxReval} currency={item.currency} />
              <BreakdownItem label="Adjustments & Fees P&L" value={item.pnlAdjustments} currency={item.currency} />
              <hr className="my-2 border-slate-300"/>
              <BreakdownItem label="Total P&L Change" value={item.currentNetPnL - item.previousNetPnL} currency={item.currency} />
            </div>
            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow">
              <h5 className="font-semibold text-slate-700 mb-2 text-md">Asset Movement</h5>
              <BreakdownItem label="Trading Activity" value={item.assetChangeTrading} currency={item.currency} />
              <BreakdownItem label="FX Revaluation" value={item.assetChangeFxReval} currency={item.currency} />
              <BreakdownItem label="Adjustments & Other" value={item.assetChangeAdjustments} currency={item.currency} />
               <hr className="my-2 border-slate-300"/>
              <BreakdownItem label="Total Asset Change" value={item.currentTotalAssets - item.previousTotalAssets} currency={item.currency} />
            </div>
            <div className="bg-white p-4 rounded-lg border border-slate-200 shadow">
              <h5 className="font-semibold text-slate-700 mb-2 text-md">Liability Movement</h5>
              <BreakdownItem label="Trading & Settlements" value={item.liabilityChangeTrading} currency={item.currency} />
              <BreakdownItem label="FX Revaluation" value={item.liabilityChangeFxReval} currency={item.currency} />
              <BreakdownItem label="Adjustments & Other" value={item.liabilityChangeAdjustments} currency={item.currency} />
               <hr className="my-2 border-slate-300"/>
              <BreakdownItem label="Total Liability Change" value={item.currentTotalLiabilities - item.previousTotalLiabilities} currency={item.currency} />
            </div>
          </div>
     </div>
);

const FxExposureView: React.FC<{ item: SignOffStrategy }> = ({ item }) => (
    <div className="bg-white p-4 rounded-lg border border-slate-200 shadow">
        <h5 className="font-semibold text-slate-700 mb-2 text-md">Foreign Exchange Exposure</h5>
        {(item.fxExposure && item.fxExposure.length > 0) ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {item.fxExposure.map(exp => (
                    <div key={exp.currency} className="p-3 bg-slate-50 rounded-md">
                        <div className="text-xs text-slate-500">{exp.currency}</div>
                        <div className="font-semibold text-slate-800">{formatCurrency(exp.amount, exp.currency)}</div>
                    </div>
                ))}
            </div>
        ) : <p className="text-slate-500 text-center py-6">No FX exposure data available for this strategy.</p>}
    </div>
);

const EntityDetailsView: React.FC<{ item: SignOffStrategy }> = ({ item }) => (
    <div className="bg-white p-4 rounded-lg border border-slate-200 shadow">
        <h5 className="font-semibold text-slate-700 mb-2 text-md">Entity Details</h5>
        {(item.entityDetails && item.entityDetails.length > 0) ? (
            <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                {item.entityDetails.map(detail => (
                    <div key={detail.name} className="p-2 bg-slate-50 rounded-md">
                        <dt className="text-xs font-medium text-slate-500">{detail.name}</dt>
                        <dd className="text-sm font-semibold text-slate-800">{detail.value}</dd>
                    </div>
                ))}
            </dl>
        ) : <p className="text-slate-500 text-center py-6">No entity details available for this strategy.</p>}
    </div>
);


const ActivityLogView: React.FC<{activityLog: ActivityLogItem[]}> = ({ activityLog }) => (
    <div className="bg-white p-1 rounded-lg border border-slate-200 shadow">
      {activityLog && activityLog.length > 0 ? (
        <div className="max-h-[50vh] overflow-y-auto">
          <table className="min-w-full text-sm">
            <thead className="sticky top-0 bg-slate-100 z-10">
              <tr>
                <th className="px-3 py-2 text-left font-semibold text-slate-600">Time</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600">Type</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600">Description</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600 hidden sm:table-cell">User</th>
                <th className="px-3 py-2 text-right font-semibold text-slate-600 hidden md:table-cell">Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {activityLog.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="px-3 py-2 whitespace-nowrap">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="px-3 py-2 whitespace-nowrap"><StatusPill status={log.type as any} /></td>
                  <td className="px-3 py-2">{log.description}</td>
                  <td className="px-3 py-2 whitespace-nowrap hidden sm:table-cell">{log.user || 'System'}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-right hidden md:table-cell">
                    {log.financialImpact && formatCurrency(log.financialImpact.amount, log.financialImpact.currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <p className="text-slate-500 text-center py-6">No activity log entries found.</p>}
    </div>
);

const AdjustmentsView: React.FC<{adjustments: Adjustment[]}> = ({ adjustments }) => (
    <div className="bg-white p-1 rounded-lg border border-slate-200 shadow">
      {adjustments.length > 0 ? (
        <div className="max-h-[50vh] overflow-y-auto">
          <table className="min-w-full text-sm">
            <thead className="sticky top-0 bg-slate-100 z-10">
              <tr>
                <th className="px-3 py-2 text-left font-semibold text-slate-600">ID</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600">Type</th>
                <th className="px-3 py-2 text-right font-semibold text-slate-600">Amount</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600">Status</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600 hidden md:table-cell">Justification</th>
                <th className="px-3 py-2 text-left font-semibold text-slate-600 hidden lg:table-cell">Created At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {adjustments.map((adj) => (
                <tr key={adj.id} className="hover:bg-slate-50">
                  <td className="px-3 py-2 whitespace-nowrap text-sky-700 font-medium">{adj.id}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{adj.type}</td>
                  <td className={`px-3 py-2 whitespace-nowrap text-right font-semibold ${adj.amount >=0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(adj.amount, adj.currency)}</td>
                  <td className="px-3 py-2 whitespace-nowrap"><StatusPill status={adj.status} /></td>
                  <td className="px-3 py-2 text-slate-600 hidden md:table-cell truncate max-w-xs">{adj.justification}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500 hidden lg:table-cell">{new Date(adj.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <p className="text-slate-500 text-center py-6">No relevant adjustments found for this item.</p>}
    </div>
);

const StrategiesView: React.FC<{strategies: SignOffStrategy[], onOpenStrategyModal: (s: SignOffStrategy) => void}> = ({ strategies, onOpenStrategyModal }) => (
    <div className="space-y-3">
        {strategies.map(strategy => (
            <div key={strategy.id} className="p-4 border border-slate-200 rounded-lg bg-white shadow hover:shadow-lg transition-shadow">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
                    <div className="mb-2 sm:mb-0">
                        <h5 className="text-md font-semibold text-slate-800">{strategy.name}</h5>
                        <div className="text-sm text-slate-500">Status: <StatusPill status={strategy.status} /></div>
                        <p className="text-sm text-slate-500">P&L: {formatCurrency(strategy.currentNetPnL, strategy.currency)}</p>
                    </div>
                    <button onClick={() => onOpenStrategyModal(strategy)} className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 text-sm font-medium flex items-center self-start sm:self-center">
                       <EyeIcon className="w-5 h-5 mr-1.5"/> Review Strategy
                    </button>
                </div>
            </div>
        ))}
        {strategies.length === 0 && <div className="p-4 bg-white rounded-lg border border-slate-200 shadow"><p className="text-slate-500 text-center py-4">No strategies found for this product line.</p></div>}
    </div>
);

const AttestationView: React.FC<{item: SignOffProductLine | SignOffStrategy, level: 'ProductLine' | 'Strategy', onSubmit: (approved: boolean) => void, comments: string, setComments: (c: string) => void, attestationChecked: boolean, setAttestationChecked: (c: boolean) => void, canSignOff: boolean, isSignedOff: boolean }> = 
({ item, level, onSubmit, comments, setComments, attestationChecked, setAttestationChecked, canSignOff, isSignedOff }) => (
     <div className="space-y-6 text-sm">
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow space-y-4">
            <div className="flex items-start">
              <input type="checkbox" id={`attestation-${item.id}`} checked={attestationChecked} onChange={(e) => setAttestationChecked(e.target.checked)} className="mt-1 h-5 w-5 text-sky-600 border-slate-400 rounded focus:ring-sky-500" disabled={isSignedOff || !canSignOff} />
              <label htmlFor={`attestation-${item.id}`} className="ml-3 text-sm text-slate-700">
                I confirm that I have reviewed the financial data for <strong>{item.name}</strong> as of {new Date().toLocaleDateString()} and am satisfied with its accuracy and completeness based on the information available.
              </label>
            </div>
            <div>
              <label htmlFor={`comments-${item.id}`} className="block text-sm font-medium text-slate-700 mb-1">Additional Comments (optional for approval, required for rejection):</label>
              <textarea id={`comments-${item.id}`} value={comments} onChange={(e) => setComments(e.target.value)} rows={3} className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500" placeholder="Enter any comments regarding this sign-off..." disabled={isSignedOff} />
            </div>
            {level === 'ProductLine' && !canSignOff && !isSignedOff && <p className="text-sm text-red-600 font-semibold p-3 bg-red-50 border border-red-200 rounded-md">Product Line cannot be signed off until all its strategies are marked as 'Signed Off'.</p>}
        </div>
        {!isSignedOff && (
        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3">
          <button onClick={() => onSubmit(true)} disabled={!attestationChecked || isSignedOff || !canSignOff} className="px-6 py-2.5 bg-green-600 text-white rounded-md font-semibold hover:bg-green-700 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed">
              <CheckCircleIcon className="w-5 h-5 mr-2" />
              Approve
          </button>
          <button onClick={() => onSubmit(false)} disabled={!attestationChecked || isSignedOff || !comments} className="px-6 py-2.5 bg-red-600 text-white rounded-md font-semibold hover:bg-red-700 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed">
              <XCircleIcon className="w-5 h-5 mr-2" />
              Reject
          </button>
        </div>
        )}
     </div>
);


interface SignOffDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: SignOffProductLine | SignOffStrategy;
  level: 'ProductLine' | 'Strategy';
  onSignOffAction: (itemId: string, level: 'ProductLine' | 'Strategy', attestation: string, comments: string, approved: boolean) => void;
  onOpenStrategyModal: (strategy: SignOffStrategy) => void;
}

const SignOffDetailModal: React.FC<SignOffDetailModalProps> = ({ isOpen, onClose, item, level, onSignOffAction, onOpenStrategyModal }) => {
  const { adjustments } = useAppContext();
  const [comments, setComments] = useState('');
  const [attestationChecked, setAttestationChecked] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setComments('');
      setAttestationChecked(false);
    }
  }, [isOpen]);

  if (!item) return null;
  
  const isProductLine = level === 'ProductLine';

  const relevantAdjustments = adjustments.filter(adj => 
     isProductLine ? adj.productLineId === item.id : adj.strategyId === item.id
  );

  const relevantActivityLog = useMemo(() => {
      if (isProductLine) {
          // Aggregate activity logs from all strategies within the product line
          return (item as SignOffProductLine).strategies.flatMap(strategy => strategy.activityLog);
      } else {
          // It's a strategy, so just use its activity log
          return (item as SignOffStrategy).activityLog;
      }
  }, [item, isProductLine]);

  const canSignOff = isProductLine ? (item as SignOffProductLine).strategies.every(s => s.status === ProcessStatus.SIGNED_OFF) : true;
  const isSignedOff = item.status === ProcessStatus.SIGNED_OFF;

  const handleSubmit = (approved: boolean) => {
    if (!approved && !comments) {
        alert('Comments are required for rejection.');
        return;
    }
    const attestation = `Attestation for ${item.name} completed by Valerie User.`;
    onSignOffAction(item.id, level, attestation, comments, approved);
  }
  
  const tabs: TabItem[] = [
    { label: 'Summary', icon: InformationCircleIcon, content: <SummaryView item={item} /> },
    isProductLine ? 
        { label: 'Strategies', icon: BranchIcon, content: <StrategiesView strategies={(item as SignOffProductLine).strategies} onOpenStrategyModal={onOpenStrategyModal}/> } :
        { label: 'P&L / BS Breakdown', icon: CalculatorIcon, content: <BreakdownView item={item as SignOffStrategy} /> },
    { label: 'Activity Log', icon: ListBulletIcon, content: <ActivityLogView activityLog={relevantActivityLog} /> },
    { label: 'Relevant Adjustments', icon: PencilIcon, content: <AdjustmentsView adjustments={relevantAdjustments} /> },
    isProductLine ?
        { label: 'Sign Off Product Line', icon: CheckCircleIcon, content: <AttestationView item={item} level="ProductLine" onSubmit={handleSubmit} comments={comments} setComments={setComments} attestationChecked={attestationChecked} setAttestationChecked={setAttestationChecked} canSignOff={canSignOff} isSignedOff={isSignedOff} /> } :
        { label: 'Sign Off Strategy', icon: CheckCircleIcon, content: <AttestationView item={item} level="Strategy" onSubmit={handleSubmit} comments={comments} setComments={setComments} attestationChecked={attestationChecked} setAttestationChecked={setAttestationChecked} canSignOff={canSignOff} isSignedOff={isSignedOff} /> }
  ];

  if (!isProductLine) {
    tabs.splice(2, 0, 
        { label: 'FX Exposure', icon: GlobeAmericasIcon, content: <FxExposureView item={item as SignOffStrategy} /> },
        { label: 'Entity Details', icon: BuildingOfficeIcon, content: <EntityDetailsView item={item as SignOffStrategy} /> }
    );
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} fullScreen>
        <div className="flex flex-col h-full bg-slate-100">
            {/* Header */}
            <header className="flex-shrink-0 bg-white border-b border-slate-200 p-4 flex justify-between items-center shadow-sm">
              <h2 className="text-xl font-semibold text-slate-800">{level === 'ProductLine' ? "Review Product Line" : "Review Strategy"}: {item.name}</h2>
              <button onClick={onClose} className="text-slate-500 hover:text-slate-800 p-2 rounded-full hover:bg-slate-100 transition-colors" aria-label="Close">
                <CloseIcon className="w-6 h-6" />
              </button>
            </header>
            
            {/* Content */}
            <main className="flex-grow p-2 sm:p-4 md:p-6 overflow-y-auto">
                 <div className="mt-4 bg-slate-50 p-4 rounded-lg">
                    <Tabs tabs={tabs} initialActiveTabIndex={isProductLine ? 1 : 0} />
                </div>
            </main>
        </div>
    </Modal>
  );
};

export default SignOffDetailModal;
