
import React from 'react';
import { ProcessStatus, ExceptionStatus, AdjustmentStatus, PreSignOffTaskStatus, DeploymentStatus, CaseStatus } from '../types';

// New types from InvestigationPage and other specific contexts
type SpecificStatus = 
    | 'Approved' | 'Breached' // from PreTrade limitCheckStatus
    | 'Confirmed' | 'Unconfirmed' | 'Mismatch' // from Ops confirmationStatus
    | 'Settled' | 'Unsettled' | 'Failed' // from Ops settlementStatus
    | 'Booked' | 'Amended' | 'Cancelled' // From InvestigativeTrade status
    | 'Active' | 'Completed' | 'Rolled Back' // From ReleaseTrain status
    | 'Success'; // From DeploymentStatus ('Failed' is already covered)

// Union of all possible status types handled by this component
type PillStatus = ProcessStatus | ExceptionStatus | AdjustmentStatus | PreSignOffTaskStatus | DeploymentStatus | CaseStatus | SpecificStatus;

interface StatusPillProps {
  status: PillStatus;
}

/**
 * A reusable component to display a status as a colored "pill".
 * It centralizes the styling logic for all status types across the application.
 * @param {StatusPillProps} props - The props for the component.
 * @returns {JSX.Element} The rendered status pill.
 */
const StatusPill: React.FC<StatusPillProps> = ({ status }) => {
    const getStatusStyle = (): string => {
        // Using a single mapping object for clarity and maintainability
        const statusStyles: { [key in PillStatus]?: string } = {
            // Unique ProcessStatus values
            [ProcessStatus.SIGNED_OFF]: 'bg-green-100 text-green-800',
            [ProcessStatus.AWAITING_SIGN_OFF]: 'bg-yellow-100 text-yellow-800',
            [ProcessStatus.REJECTED]: 'bg-red-100 text-red-800',

            // Unique ExceptionStatus values
            [ExceptionStatus.IN_REVIEW]: 'bg-blue-100 text-blue-800',
            [ExceptionStatus.PENDING_ADJUSTMENT]: 'bg-yellow-100 text-yellow-800',
            [ExceptionStatus.RESOLVED]: 'bg-green-100 text-green-800',
            
            // AdjustmentStatus
            'DRAFT': 'bg-slate-200 text-slate-800',
            'SUBMITTED': 'bg-sky-100 text-sky-800',
            'CANCELLED': 'bg-red-100 text-red-800',

            // Unique PreSignOffTaskStatus values
            [PreSignOffTaskStatus.COMPLETED_OK]: 'bg-green-100 text-green-800',
            [PreSignOffTaskStatus.COMPLETED_BREAKS]: 'bg-yellow-100 text-yellow-800',
            [PreSignOffTaskStatus.REQUIRES_ATTENTION]: 'bg-red-100 text-red-800',
            [PreSignOffTaskStatus.ACKNOWLEDGED]: 'bg-indigo-100 text-indigo-800',

            // Unique CaseStatus values
            [CaseStatus.AWAITING_RESPONSE]: 'bg-purple-100 text-purple-800',
            
            // Common statuses defined once to avoid duplication
            'In Progress': 'bg-sky-100 text-sky-800',   // Shared by ProcessStatus, CaseStatus, PreSignOffTaskStatus, DeploymentStatus
            'Open': 'bg-orange-100 text-orange-800',     // Shared by ExceptionStatus, CaseStatus
            'Closed': 'bg-slate-200 text-slate-800',    // Shared by ExceptionStatus, CaseStatus
            'Failed': 'bg-red-100 text-red-800', // Shared by PreSignOffTaskStatus, DeploymentStatus, SpecificStatus
            'Pending': 'bg-slate-200 text-slate-800', // Shared by PreSignOffTaskStatus, DeploymentStatus

            // InvestigativeTrade Status
            'Booked': 'bg-blue-100 text-blue-800',
            'Amended': 'bg-yellow-100 text-yellow-800',
            
            // SpecificStatus for InvestigationPage etc.
            'Approved': 'bg-green-100 text-green-800',
            'Breached': 'bg-red-100 text-red-800',
            'Confirmed': 'bg-green-100 text-green-800',
            'Unconfirmed': 'bg-yellow-100 text-yellow-800',
            'Mismatch': 'bg-orange-100 text-orange-800',
            'Settled': 'bg-green-100 text-green-800',
            'Unsettled': 'bg-sky-100 text-sky-800',
            'Success': 'bg-green-100 text-green-800', // Deployment
            
            // ReleaseTrain Status
            'Active': 'bg-sky-100 text-sky-800',
            'Completed': 'bg-green-100 text-green-800',
            'Rolled Back': 'bg-red-100 text-red-800',
        };

        return statusStyles[status] || 'bg-gray-200 text-gray-800';
    };

    const formattedStatus = status.toString().replace(/_/g, ' ');

    return (
        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusStyle()}`}>
            {formattedStatus}
        </span>
    );
};

export default StatusPill;
