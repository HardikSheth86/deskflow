import React, { useState, useEffect } from 'react';
import { Commentary, CommentaryTemplate, CommentarySection, BusinessArea, CommentaryType, Region } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import Modal from './Modal';
import { CloseIcon, SaveIcon, LightbulbIcon, PlusCircleIcon } from './icons';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

interface CommentaryEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (commentary: Commentary) => void;
  businessArea: BusinessArea;
  existingCommentary: Commentary | null;
  template: CommentaryTemplate | null;
}

export const CommentaryEditorModal: React.FC<CommentaryEditorModalProps> = ({
  isOpen,
  onClose,
  onSave,
  businessArea,
  existingCommentary,
  template,
}) => {
  const { selectedProductLineIds, selectedStrategies, selectedRegions } = useAppContext();

  const [title, setTitle] = useState('');
  const [sections, setSections] = useState<CommentarySection[]>([]);
  const [commentaryType, setCommentaryType] = useState<CommentaryType>(CommentaryType.MARKET);
  const [generatingSuggestionFor, setGeneratingSuggestionFor] = useState<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      if (existingCommentary) {
        setTitle(existingCommentary.title);
        setSections(JSON.parse(JSON.stringify(existingCommentary.sections))); // Deep copy
        setCommentaryType(existingCommentary.type);
      } else if (template) {
        setTitle(`New ${template.name}`);
        setSections(template.defaultSections.map(s => ({
          title: s.title,
          userContent: '',
          aiSuggestion: s.aiPlaceholder,
        })));
        setCommentaryType(template.type);
      }
    } else {
        // Reset state on close
        setTitle('');
        setSections([]);
        setCommentaryType(CommentaryType.MARKET);
    }
  }, [isOpen, existingCommentary, template]);

  const handleSectionChange = (index: number, content: string) => {
    const newSections = [...sections];
    newSections[index].userContent = content;
    setSections(newSections);
  };
  
  const handleGenerateSuggestion = async (index: number) => {
      const section = sections[index];
      if (!process.env.API_KEY) {
          alert("API Key not configured.");
          return;
      }
      setGeneratingSuggestionFor(index);
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const prompt = `You are a financial analyst assistant. Write a short, professional paragraph for a commentary section titled "${section.title}". 
          The purpose of this section is: "${section.aiSuggestion || 'Provide a general market overview.'}".
          Focus on providing insightful content.`;
          
          const response: GenerateContentResponse = await ai.models.generateContent({
              model: 'gemini-2.5-flash',
              contents: prompt,
          });
          
          const newSections = [...sections];
          // Overwrite aiSuggestion with the new response, which can then be applied.
          newSections[index].aiSuggestion = response.text; 
          setSections(newSections);

      } catch (error) {
          console.error("Error generating suggestion:", error);
          alert("Failed to generate AI suggestion.");
      } finally {
          setGeneratingSuggestionFor(null);
      }
  };

  const applySuggestion = (index: number) => {
    const newSections = [...sections];
    if (newSections[index].aiSuggestion) {
        newSections[index].userContent = newSections[index].aiSuggestion!;
        setSections(newSections);
    }
  };

  const handleSave = () => {
    if (!title.trim()) {
      alert('Title cannot be empty.');
      return;
    }
    const commentaryToSave: Commentary = {
      id: existingCommentary?.id || `COM-${Date.now()}`,
      title,
      type: commentaryType,
      author: existingCommentary?.author || 'Valerie User',
      dateCreated: existingCommentary?.dateCreated || new Date().toISOString(),
      businessArea,
      sections,
      productLineId: existingCommentary?.productLineId || selectedProductLineIds[0] || 'ALL',
      strategyId: existingCommentary?.strategyId || selectedStrategies[0] || 'ALL',
      region: existingCommentary?.region || selectedRegions[0] || Region.NORTH_AMERICA,
    };
    onSave(commentaryToSave);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} fullScreen>
      <div className="flex flex-col h-full bg-slate-50">
        {/* Header */}
        <header className="flex-shrink-0 bg-white border-b border-slate-200 p-4 flex justify-between items-center shadow-sm">
          <h2 className="text-xl font-semibold text-slate-800">{existingCommentary ? 'Edit Commentary' : 'Create Commentary'}</h2>
          <div className="flex items-center space-x-3">
            <button onClick={handleSave} className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center">
              <SaveIcon className="w-5 h-5 mr-2" /> Save & Close
            </button>
            <button onClick={onClose} className="text-slate-500 hover:text-slate-800 p-2 rounded-full hover:bg-slate-100 transition-colors" aria-label="Close">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-grow p-6 overflow-y-auto space-y-6">
          <div className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
            <label htmlFor="commentary-title" className="block text-sm font-medium text-slate-700">Commentary Title</label>
            <input
              id="commentary-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 w-full p-2 border border-slate-300 rounded-md text-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              placeholder="Enter a descriptive title"
            />
          </div>
          
          <div className="space-y-4">
            {sections.map((section, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
                <h3 className="text-lg font-semibold text-slate-700 mb-3">{section.title}</h3>
                
                {section.aiSuggestion && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md mb-3 text-sm space-y-2">
                     <div className="flex justify-between items-center">
                       <p className="italic text-yellow-800">
                         <span className="font-semibold">AI Prompt Idea:</span> {section.aiSuggestion}
                       </p>
                       <div className="flex items-center space-x-2">
                           <button 
                                onClick={() => handleGenerateSuggestion(index)} 
                                disabled={generatingSuggestionFor === index}
                                className="px-2 py-1 bg-yellow-400 text-yellow-900 rounded-md hover:bg-yellow-500 text-xs font-medium flex items-center disabled:opacity-50"
                           >
                               <LightbulbIcon className="w-4 h-4 mr-1"/>
                               {generatingSuggestionFor === index ? 'Generating...' : 'Generate with AI'}
                           </button>
                           <button 
                                onClick={() => applySuggestion(index)}
                                className="px-2 py-1 bg-green-200 text-green-800 rounded-md hover:bg-green-300 text-xs font-medium flex items-center"
                           >
                               <PlusCircleIcon className="w-4 h-4 mr-1"/> Use Suggestion
                           </button>
                       </div>
                     </div>
                  </div>
                )}

                <textarea
                  value={section.userContent}
                  onChange={(e) => handleSectionChange(index, e.target.value)}
                  rows={8}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                  placeholder={`Enter content for ${section.title}...`}
                />
              </div>
            ))}
          </div>
        </main>
      </div>
    </Modal>
  );
};