import React, { useState } from 'react';
import Modal from './Modal';
import { Adjustment, AdjustmentType, BusinessArea, Region } from '../types';

interface BulkUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (adjustments: Adjustment[]) => void;
}

const SAMPLE_CSV = `type,amount,currency,debitAccount,creditAccount,justification,productLineId,strategyId,region
PNL_CORRECTION,5000,USD,DEBIT-ACC-1,CREDIT-ACC-1,To correct trade booking error,PL_LTERM_DEBT,SN_FID,North America
BS_REALIGNMENT,-12000,JPY,ASSET_RECLASS_A,ASSET_RECLASS_B,Realign balance sheet for JGBs,PL_LTERM_DEBT,SN_FID_ESG,Tokyo`;

const BulkUploadModal: React.FC<BulkUploadModalProps> = ({ isOpen, onClose, onUpload }) => {
    const [csvData, setCsvData] = useState('');
    const [parsedAdjustments, setParsedAdjustments] = useState<Adjustment[]>([]);
    const [error, setError] = useState('');

    const handleParse = () => {
        if (!csvData.trim()) {
            setError('CSV data cannot be empty.');
            setParsedAdjustments([]);
            return;
        }

        try {
            const lines = csvData.trim().split('\n');
            const header = lines[0].split(',').map(h => h.trim());
            const requiredHeaders = ['type', 'amount', 'currency', 'debitAccount', 'creditAccount', 'justification', 'productLineId', 'strategyId', 'region'];
            if (!requiredHeaders.every(h => header.includes(h))) {
                throw new Error(`CSV must contain the following headers: ${requiredHeaders.join(', ')}`);
            }

            const adjustments: Adjustment[] = lines.slice(1).map((line, index) => {
                const values = line.split(',');
                const row: any = header.reduce((obj, nextKey, i) => {
                    obj[nextKey] = values[i]?.trim();
                    return obj;
                }, {} as any);
                
                if (isNaN(parseFloat(row.amount))) throw new Error(`Invalid amount on line ${index + 2}`);
                if (!Object.values(AdjustmentType).includes(row.type as AdjustmentType)) throw new Error(`Invalid type on line ${index + 2}: ${row.type}`);
                if (!Object.values(Region).includes(row.region as Region)) throw new Error(`Invalid region on line ${index + 2}: ${row.region}`);

                return {
                    id: `BULK-ADJ-${Date.now()}-${index}`,
                    type: row.type as AdjustmentType,
                    amount: parseFloat(row.amount),
                    currency: row.currency,
                    debitAccount: row.debitAccount,
                    creditAccount: row.creditAccount,
                    justification: row.justification,
                    productLineId: row.productLineId,
                    strategyId: row.strategyId,
                    region: row.region as Region,
                    status: 'SUBMITTED',
                    createdBy: 'Bulk Upload',
                    createdAt: new Date().toISOString(),
                    businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS, // Assuming context
                };
            });
            setParsedAdjustments(adjustments);
            setError('');
        } catch (e: any) {
            setError(e.message);
            setParsedAdjustments([]);
        }
    };

    const handleUseSample = () => {
        setCsvData(SAMPLE_CSV);
    };

    const handleSubmit = () => {
        if (parsedAdjustments.length > 0 && !error) {
            onUpload(parsedAdjustments);
        } else {
            alert('Please parse valid CSV data before submitting.');
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Bulk Upload Adjustments" size="xl">
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Paste CSV Data</label>
                    <textarea 
                        rows={8} 
                        className="w-full p-2 border border-slate-300 rounded-md font-mono text-xs" 
                        value={csvData}
                        onChange={(e) => setCsvData(e.target.value)}
                        placeholder="Paste your CSV content here..."
                    ></textarea>
                    <div className="flex justify-between items-center mt-2 text-sm">
                        <div>
                             <a 
                                href={`data:text/csv;charset=utf-8,${encodeURIComponent(SAMPLE_CSV)}`} 
                                download="sample_adjustments.csv"
                                className="text-sky-600 hover:underline"
                            >
                                Download Sample CSV
                            </a>
                            <span className="text-slate-400 mx-2">|</span>
                             <button onClick={handleUseSample} className="text-sky-600 hover:underline">
                                Use Sample Data
                            </button>
                        </div>
                        <button onClick={handleParse} className="px-4 py-1.5 bg-slate-600 text-white rounded-md text-sm font-medium hover:bg-slate-700">Parse Data</button>
                    </div>
                </div>

                {error && <p className="text-red-600 bg-red-50 p-3 rounded-md text-sm">{error}</p>}

                {parsedAdjustments.length > 0 && (
                    <div>
                        <h4 className="font-semibold mb-2">Preview ({parsedAdjustments.length} adjustments to be created)</h4>
                        <div className="max-h-48 overflow-y-auto border rounded-md">
                            <table className="min-w-full text-xs">
                                <thead className="bg-slate-100 sticky top-0">
                                    <tr>
                                        <th className="p-2 text-left">Type</th>
                                        <th className="p-2 text-right">Amount</th>
                                        <th className="p-2 text-left">Justification</th>
                                        <th className="p-2 text-left">Region</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-200">
                                    {parsedAdjustments.map(adj => (
                                        <tr key={adj.id}>
                                            <td className="p-2">{adj.type}</td>
                                            <td className="p-2 text-right">{adj.amount.toLocaleString(undefined, {style: 'currency', currency: adj.currency})}</td>
                                            <td className="p-2 truncate" title={adj.justification}>{adj.justification}</td>
                                            <td className="p-2">{adj.region}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
                
                <div className="flex justify-end space-x-3 pt-4 border-t border-slate-200">
                    <button onClick={onClose} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancel</button>
                    <button 
                        onClick={handleSubmit} 
                        disabled={parsedAdjustments.length === 0 || !!error} 
                        className="px-4 py-2 bg-sky-600 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Submit {parsedAdjustments.length > 0 ? parsedAdjustments.length : ''} Adjustments
                    </button>
                </div>
            </div>
        </Modal>
    );
};

export default BulkUploadModal;