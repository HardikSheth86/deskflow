
import React, { useState, useEffect } from 'react';
import { Exception, Adjustment, AdjustmentType, RcaAnalysis } from '../types';
import Modal from './Modal';
import { LightbulbIcon, CpuChipIcon, ThumbUpIcon, ThumbDownIcon, ListBulletIcon } from './icons';
import DashboardCard from './DashboardCard';
import StatusPill from './StatusPill';
import { useAppContext } from '../hooks/useAppContext';

interface ExceptionDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  exception: Exception | null;
  onOpenAdjustmentModal: (exception: Exception, prefilledAdjustment: Adjustment) => void;
  onAnalyzeRca: (exception: Exception) => Promise<RcaAnalysis>;
  onSuggestAdjustment: (exception: Exception) => Promise<any>;
  onUpdateException: (updatedException: Exception) => void;
  actionToTrigger?: 'analyze' | 'suggest' | null;
}

const DetailItem: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
    <div>
        <dt className="text-xs font-medium text-slate-500">{label}</dt>
        <dd className="mt-1 text-sm text-slate-900">{value}</dd>
    </div>
);

const ExceptionDetailModal: React.FC<ExceptionDetailModalProps> = ({ 
    isOpen, 
    onClose, 
    exception, 
    onOpenAdjustmentModal,
    onAnalyzeRca,
    onSuggestAdjustment,
    onUpdateException,
    actionToTrigger = null,
}) => {
  const [analysis, setAnalysis] = useState<RcaAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [suggestedAdjustment, setSuggestedAdjustment] = useState<any>(null);
  const [isSuggesting, setIsSuggesting] = useState(false);

  // AI Feedback state
  const [feedback, setFeedback] = useState<'accurate' | 'inaccurate' | null>(null);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  const handleAnalyze = async () => {
    if (!exception) return;
    setIsAnalyzing(true);
    setAnalysis(null);
    const rca = await onAnalyzeRca(exception);
    setAnalysis(rca);
    setIsAnalyzing(false);
  };
  
  const handleSuggest = async () => {
    if (!exception) return;
    setIsSuggesting(true);
    setSuggestedAdjustment(null);
    const suggestion = await onSuggestAdjustment(exception);
    setSuggestedAdjustment(suggestion);
    setIsSuggesting(false);
  };

  useEffect(() => {
    if (exception) {
      setAnalysis(null);
      setSuggestedAdjustment(null);
      
      // Handle AI Feedback state
      setFeedback(exception.aiAnalysisFeedback || null);
      setFeedbackComment(exception.aiAnalysisFeedbackComment || '');
      setFeedbackSubmitted(!!exception.aiAnalysisFeedback);
      
      if (actionToTrigger === 'analyze') {
        handleAnalyze();
      } else if (actionToTrigger === 'suggest') {
        handleSuggest();
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exception, actionToTrigger]);
  
  const handleFeedbackSubmit = () => {
    if (!exception || !feedback) return;
    onUpdateException({
        ...exception,
        aiAnalysisFeedback: feedback,
        aiAnalysisFeedbackComment: feedbackComment,
    });
    setFeedbackSubmitted(true);
  };

  if (!exception) return null;

  const handleApplySuggestion = () => {
      if (!suggestedAdjustment) return;
      const transientAdjustment: Adjustment = {
        id: `ADJ-${Date.now()}`,
        relatedExceptionId: exception.id,
        type: suggestedAdjustment.type || AdjustmentType.PNL_CORRECTION,
        amount: suggestedAdjustment.amount || 0,
        currency: suggestedAdjustment.currency || exception.position.currency,
        debitAccount: suggestedAdjustment.debitAccount || '',
        creditAccount: suggestedAdjustment.creditAccount || '',
        justification: suggestedAdjustment.justification || '',
        status: 'DRAFT',
        createdBy: 'AI Agent Proposal',
        createdAt: new Date().toISOString(),
        businessArea: exception.businessArea,
        productLineId: exception.productLineId,
        strategyId: exception.strategyId,
        region: exception.region,
        suggestedAmount: suggestedAdjustment.amount,
        suggestedCurrency: suggestedAdjustment.currency,
        suggestedDebitAccount: suggestedAdjustment.debitAccount,
        suggestedCreditAccount: suggestedAdjustment.creditAccount,
        suggestedJustification: suggestedAdjustment.justification,
    };
    onOpenAdjustmentModal(exception, transientAdjustment);
    onClose();
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Exception Details: ${exception.id}`} size="xl">
        <div className="space-y-4">
            {/* Top Info Section */}
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <h3 className="font-semibold text-lg text-slate-800">{exception.description}</h3>
                <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <DetailItem label="Financial Impact" value={
                        <span className={`${exception.financialImpact >= 0 ? 'text-green-700' : 'text-red-700'} font-semibold`}>
                            {exception.financialImpact.toLocaleString(undefined, {style:'currency', currency: exception.position.currency})}
                        </span>
                    } />
                    <DetailItem label="Status" value={<StatusPill status={exception.status} />} />
                    <DetailItem label="CUSIP" value={exception.position.cusip} />
                    <DetailItem label="Trading Account" value={exception.position.tapsAccount} />
                    <DetailItem label="Counterparty" value={exception.position.counterparty} />
                    <DetailItem label="Date Identified" value={new Date(exception.dateIdentified).toLocaleDateString()} />
                </div>
            </div>

            {/* AI Action Center */}
            <DashboardCard title={<div className="flex items-center"><CpuChipIcon className="w-5 h-5 mr-2" /> AI Action Center</div>}>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Root Cause Analysis */}
                    <div className="space-y-3">
                        <button 
                            onClick={handleAnalyze} 
                            disabled={isAnalyzing}
                            className="w-full px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center justify-center disabled:opacity-50"
                        >
                            <LightbulbIcon className="w-5 h-5 mr-2" />
                            {isAnalyzing ? 'Analyzing...' : 'Analyze Root Cause & Investigation'}
                        </button>
                        {isAnalyzing && <p className="text-center text-slate-500 text-xs">AI is investigating...</p>}
                        {analysis && (
                            <div className="p-3 bg-sky-50 border border-sky-200 rounded-md animate-fadeIn space-y-3">
                                <div>
                                    <h4 className="font-semibold text-sky-800 text-sm mb-1">Likely Root Cause:</h4>
                                    <p className="text-xs text-slate-700">{analysis.likelyRootCause}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-sky-800 text-sm mb-1">Investigation Steps:</h4>
                                    <ol className="list-decimal list-inside text-xs text-slate-700 space-y-1">
                                        {analysis.investigationSteps.map((step, i) => <li key={i}>{step}</li>)}
                                    </ol>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-sky-800 text-sm mb-1">Key Data Points to Check:</h4>
                                    <ul className="list-disc list-inside text-xs text-slate-700 space-y-1">
                                        {analysis.keyDataPoints.map((point, i) => <li key={i}>{point}</li>)}
                                    </ul>
                                </div>
                                
                                {/* Feedback Section */}
                                <div className="mt-4 pt-3 border-t border-sky-200">
                                    {feedbackSubmitted ? (
                                        <p className="text-sm text-green-700 font-medium text-center">Thank you for your feedback!</p>
                                    ) : (
                                        <div className="space-y-2">
                                            <p className="text-xs font-medium text-slate-600">Was this analysis helpful?</p>
                                            <div className="flex items-center space-x-2">
                                                <button onClick={() => setFeedback('accurate')} className={`p-1.5 rounded-full transition-colors ${feedback === 'accurate' ? 'bg-green-100 text-green-600 ring-2 ring-green-500' : 'bg-slate-100 text-slate-500 hover:bg-green-100'}`} title="Accurate">
                                                    <ThumbUpIcon className="w-5 h-5" />
                                                </button>
                                                <button onClick={() => setFeedback('inaccurate')} className={`p-1.5 rounded-full transition-colors ${feedback === 'inaccurate' ? 'bg-red-100 text-red-600 ring-2 ring-red-500' : 'bg-slate-100 text-slate-500 hover:bg-red-100'}`} title="Inaccurate">
                                                    <ThumbDownIcon className="w-5 h-5" />
                                                </button>
                                                {feedback === 'inaccurate' && (
                                                    <input
                                                        type="text"
                                                        value={feedbackComment}
                                                        onChange={(e) => setFeedbackComment(e.target.value)}
                                                        placeholder="Optional: What was wrong?"
                                                        className="flex-grow p-1.5 border border-slate-300 rounded-md text-xs"
                                                    />
                                                )}
                                                <button onClick={handleFeedbackSubmit} disabled={!feedback} className="px-3 py-1 bg-slate-600 text-white rounded-md text-xs font-medium disabled:opacity-50">
                                                    Submit
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                    {/* Suggestive Adjustment */}
                    <div className="space-y-3">
                        <button 
                            onClick={handleSuggest} 
                            disabled={isSuggesting}
                            className="w-full px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors text-sm font-medium flex items-center justify-center disabled:opacity-50"
                        >
                            <LightbulbIcon className="w-5 h-5 mr-2" />
                            {isSuggesting ? 'Generating...' : 'Generate Suggestive Adjustment'}
                        </button>
                        {isSuggesting && <p className="text-center text-slate-500 text-xs">AI is generating suggestion...</p>}
                        {suggestedAdjustment && (
                            <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-md animate-fadeIn space-y-2">
                                <h4 className="font-semibold text-indigo-800 text-sm mb-1">AI Suggested Adjustment:</h4>
                                <div className="text-xs text-slate-700 space-y-1">
                                    <p><strong>Type:</strong> {suggestedAdjustment.type}</p>
                                    <p><strong>Amount:</strong> {suggestedAdjustment.amount?.toLocaleString(undefined, {style:'currency', currency: suggestedAdjustment.currency})}</p>
                                    <p><strong>Debit:</strong> {suggestedAdjustment.debitAccount} / <strong>Credit:</strong> {suggestedAdjustment.creditAccount}</p>
                                    <p className="italic">"{suggestedAdjustment.justification}"</p>
                                </div>
                                <button onClick={handleApplySuggestion} className="w-full text-center mt-2 px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 text-xs font-medium">
                                    Apply & Create Adjustment
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </DashboardCard>
        </div>
        <style>{`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fadeIn {
            animation: fadeIn 0.5s ease-out forwards;
          }
        `}</style>
    </Modal>
  );
};

export default ExceptionDetailModal;
