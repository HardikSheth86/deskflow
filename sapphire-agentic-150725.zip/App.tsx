
import React from 'react';
import { HashRouter, Routes, Route, Outlet } from 'react-router-dom';
import TopNav from './components/TopNav';
import Header from './components/Header';
import DashboardPage from './pages/DashboardPage';
import PreSignOffPage from './pages/PreSignOffPage';
import ExceptionSummaryPage from './pages/ExceptionSummaryPage';
import AdjustmentsPage from './pages/AdjustmentsPage';
import SignOffPage from './pages/SignOffPage';
import CommentaryPage from './pages/CommentaryPage';
import AnalyticsPage from './pages/AnalyticsPage';
import CaseManagementPage from './pages/CaseManagementPage';
import InvestigationPage from './pages/InvestigationPage';
import TraderReviewPage from './pages/TraderReviewPage';
import ManagementPage from './pages/ManagementPage';
import HelpWidget from './components/HelpWidget';
import DocumentationPage from './pages/DocumentationPage';
import TestingPage from './pages/TestingPage';
import ErrorBoundary from './components/ErrorBoundary';

/**
 * The main layout component for the application.
 * It establishes the consistent structure of every page, including the top navigation bar,
 * the header with page titles and filters, and the main content area.
 * The `Outlet` from `react-router-dom` renders the specific page component for the current route.
 * @returns {JSX.Element} The rendered main layout structure.
 */
const MainLayout: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <TopNav />
      <Header />
      <main className="flex-1 flex flex-col bg-slate-50">
        <Outlet />
      </main>
    </div>
  );
};


/**
 * The root component of the application.
 * It sets up the main routing structure using `HashRouter` and `Routes`.
 * The `ErrorBoundary` is placed at a high level to catch any rendering errors in its children.
 * The `HelpWidget` is rendered outside the main layout to ensure it is always available.
 * @returns {JSX.Element} The rendered application.
 */
const App: React.FC = () => {
  return (
    <HashRouter>
      <ErrorBoundary>
        <div className="relative">
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<DashboardPage />} />
              <Route path="trader-review" element={<TraderReviewPage />} />
              <Route path="presignoff" element={<PreSignOffPage />} />
              <Route path="exceptions" element={<ExceptionSummaryPage />} />
              <Route path="adjustments" element={<AdjustmentsPage />} />
              <Route path="sign-off" element={<SignOffPage />} />
              <Route path="commentary" element={<CommentaryPage />} />
              <Route path="analytics" element={<AnalyticsPage />} />
              <Route path="investigation" element={<InvestigationPage />} />
              <Route path="management" element={<ManagementPage />} />
              <Route path="cases" element={<CaseManagementPage />} />
              <Route path="documentation" element={<DocumentationPage />} />
              <Route path="testing" element={<TestingPage />} />
              {/* Catch-all for undefined routes within the layout, redirects to dashboard */}
              <Route path="*" element={<DashboardPage />} /> 
            </Route>
          </Routes>
          <HelpWidget />
        </div>
      </ErrorBoundary>
    </HashRouter>
  );
};

export default App;
