import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../hooks/useAppContext';
import { MOCK_PROCESS_STAGES } from '../constants';
import { KPI, ProcessStage, ExceptionCategory, ExceptionStatus } from '../types';
import DashboardCard from '../components/DashboardCard';
import ProgressBar from '../components/ProgressBar';
import { EyeIcon } from '../components/icons';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import StatusPill from '../components/StatusPill';

/**
 * The main dashboard page of the application.
 * It provides a high-level overview of the daily process, key performance indicators (KPIs),
 * exception summaries, and sign-off statuses for the currently selected business area.
 * @returns {JSX.Element} The rendered dashboard page.
 */
const DashboardPage: React.FC = () => {
  const { 
    setCurrentPageTitle, 
    exceptions, 
    productLinesByArea,
    selectedBusinessAreas,
    selectedProductLineIds,
    selectedStrategies,
    selectedRegions,
  } = useAppContext();
  
  /** State for the stages of the daily validation process. */
  const [processStages, setProcessStages] = useState<ProcessStage[]>([]);
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const staticMetrics: KPI[] = [
    { label: 'Funding Balance', value: '$1.8B', variance: '+$5M (0.28%)', varianceType: 'positive' },
    { label: 'Investment Balance', value: '$1.4B', variance: '+$10M (0.72%)', varianceType: 'positive' },
    { label: 'Funding Cost', value: '$220K', variance: '+$2K (0.91%)', varianceType: 'negative' },
    { label: 'Investment Income', value: '$670K', variance: '+$10K (1.52%)', varianceType: 'positive' },
  ];

  // Effect to set the page title when the component mounts.
  useEffect(() => {
    setCurrentPageTitle('Dashboard');
    setProcessStages(MOCK_PROCESS_STAGES);
  }, [setCurrentPageTitle]);

  /**
   * Memoized calculation for the exception summary pie chart data.
   * This re-calculates only when its dependencies (exceptions, filters) change, improving performance.
   * @returns {Array<{name: string, value: number}>} Data formatted for the recharts Pie component.
   */
  const exceptionSummaryData = useMemo(() => {
    const exceptionsForArea = exceptions.filter(ex => 
      (selectedBusinessAreas.length === 0 || selectedBusinessAreas.includes(ex.businessArea)) &&
      (selectedProductLineIds.length === 0 || selectedProductLineIds.includes(ex.productLineId)) &&
      (selectedRegions.length === 0 || selectedRegions.includes(ex.region)) &&
      (selectedStrategies.length === 0 || selectedStrategies.includes(ex.strategyId))
    );
    const summary: Record<ExceptionCategory, number> = {
      [ExceptionCategory.NEW_ACTIVITY]: 0,
      [ExceptionCategory.DOD_VARIANCE]: 0,
      [ExceptionCategory.TREASURY_VS_BU]: 0,
    };
    exceptionsForArea.forEach(ex => {
      if (ex.status !== ExceptionStatus.CLOSED && ex.status !== ExceptionStatus.RESOLVED) {
        summary[ex.category] = (summary[ex.category] || 0) + 1;
      }
    });
    return Object.entries(summary)
        .map(([name, value]) => ({ name, value }))
        .filter(item => item.value > 0);
  }, [exceptions, selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions]);

  /**
   * Memoized calculation for the sign-off summary table data.
   * Filters product lines based on the current global filter context.
   * @returns {SignOffProductLine[]} The filtered product lines to display.
   */
  const signOffSummary = useMemo(() => {
    const allForArea = Object.values(productLinesByArea).flat();
    return allForArea.filter(pl => 
        (selectedBusinessAreas.length === 0 || selectedBusinessAreas.includes(pl.businessArea)) &&
        (selectedProductLineIds.length === 0 || selectedProductLineIds.includes(pl.id)) &&
        (selectedRegions.length === 0 || pl.regions.some(r => selectedRegions.includes(r)))
    );
  }, [productLinesByArea, selectedBusinessAreas, selectedProductLineIds, selectedRegions]);


  return (
    <div className="space-y-6">
      <DashboardCard title="Treasury Capital Markets Summary" className="bg-gradient-to-r from-sky-500 to-indigo-500 text-white shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {staticMetrics.map((kpi) => (
            <div key={kpi.label} className="bg-white/20 p-4 rounded-lg backdrop-blur-sm">
              <p className="text-sm text-sky-100">{kpi.label}</p>
              <p className="text-2xl font-bold">{kpi.value}</p>
              <p className={`text-xs ${
                kpi.varianceType === 'positive' ? 'text-green-300' :
                kpi.varianceType === 'negative' ? 'text-red-300' : 'text-sky-100'
              }`}>{kpi.variance}</p>
            </div>
          ))}
        </div>
      </DashboardCard>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <DashboardCard title="Daily Process Update" className="lg:col-span-2">
            <ProgressBar stages={processStages} currentStageName={processStages.find(s => s.status === 'in-progress')?.name} />
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-xs">
                {processStages.map(stage => (
                    <div key={stage.id} className="text-center">
                        <p className="font-medium text-slate-600">{stage.name}</p>
                        <p className="text-slate-500">
                            {stage.status === 'completed' && stage.completedAt ? new Date(stage.completedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : stage.status.replace('-', ' ')}
                        </p>
                    </div>
                ))}
            </div>
        </DashboardCard>

        <DashboardCard title="Exception Summary" actions={
            <Link to="/exceptions" className="text-sm text-sky-600 hover:text-sky-800 font-medium flex items-center">
                View Details <EyeIcon className="w-4 h-4 ml-1" />
            </Link>
        }>
          {exceptionSummaryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={exceptionSummaryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} label>
                  {exceptionSummaryData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="vertical" align="right" verticalAlign="middle" iconSize={10} wrapperStyle={{fontSize: "12px"}}/>
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-500 text-center py-8">No outstanding exceptions match the current filters.</p>
          )}
        </DashboardCard>
      </div>

      <DashboardCard title="Sign-off Status">
        {signOffSummary.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Entity/Segment</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Last Updated</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {signOffSummary.map((entity) => (
                  <tr key={`${entity.id}-${entity.regions.join('-')}`}>
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-800">{entity.name} ({entity.businessArea})</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm">
                      <StatusPill status={entity.status} />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{new Date(entity.lastUpdated).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
             <p className="text-slate-500 text-center py-4">No sign-off entities match the current filters.</p>
        )}
      </DashboardCard>
    </div>
  );
};

export default DashboardPage;
