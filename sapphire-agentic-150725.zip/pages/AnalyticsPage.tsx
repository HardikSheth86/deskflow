

import React, { useEffect, useState, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { ChatBubbleLeftRightIcon, PaperAirplaneIcon, LinkIcon, ChevronDownIcon, ChevronUpIcon } from '../components/icons';
import SendReportModal from '../components/SendReportModal';
import FullScreenReportViewer from '../components/FullScreenReportViewer';
import { MOCK_DISTRIBUTION_LISTS, MOCK_REPORTS_DATA } from '../constants';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ReportItem, Adjustment } from '../types';
import { formatCurrency } from '../utils/helpers';
import StatusPill from '../components/StatusPill';
import ReportCard from '../components/ReportCard';

const AnalyticsPage: React.FC = () => {
  const { setCurrentPageTitle, exceptions, productLinesByArea, adjustments, selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions } = useAppContext();
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [reportToSend, setReportToSend] = useState<ReportItem | null>(null);
  
  const [isFullScreenViewerOpen, setIsFullScreenViewerOpen] = useState(false);
  const [reportToViewInFullScreen, setReportToViewInFullScreen] = useState<ReportItem | null>(null);
  
  // State for "Talk to your data"
  const [analyticsQuestion, setAnalyticsQuestion] = useState('');
  const [analyticsAnswer, setAnalyticsAnswer] = useState('');
  const [analyticsSources, setAnalyticsSources] = useState<any[]>([]);
  const [isAsking, setIsAsking] = useState(false);

  // New state for accordion layout
  const [openAccordion, setOpenAccordion] = useState<string | null>(MOCK_REPORTS_DATA[0]?.categoryId || null);

  useEffect(() => {
    setCurrentPageTitle('Analytics & Reporting');
  }, [setCurrentPageTitle]);

  const adjustmentsToday = useMemo(() => {
    const today = new Date().toDateString();
    return adjustments.filter(adj => 
        new Date(adj.createdAt).toDateString() === today &&
        (selectedBusinessAreas.length === 0 || selectedBusinessAreas.includes(adj.businessArea)) &&
        (selectedProductLineIds.length === 0 || selectedProductLineIds.includes(adj.productLineId)) &&
        (selectedRegions.length === 0 || selectedRegions.includes(adj.region)) &&
        (selectedStrategies.length === 0 || selectedStrategies.includes(adj.strategyId))
    );
  }, [adjustments, selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions]);
  
  const handleTalkToData = async () => {
    if (!process.env.API_KEY || !analyticsQuestion.trim()) return;

    setIsAsking(true);
    setAnalyticsAnswer('');
    setAnalyticsSources([]);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        const dataContext = `
        The application contains data filtered by the user with the following context:
        - Divisions: ${selectedBusinessAreas.join(', ')}
        - Product Lines: ${selectedProductLineIds.join(', ')}
        - Strategies: ${selectedStrategies.join(', ') || 'All'}
        - Regions: ${selectedRegions.join(', ')}
        
        Within this context:
        - There are ${exceptions.filter(e => selectedRegions.length === 0 || selectedRegions.includes(e.region)).length} total exceptions.
        - The top product line P&L is approximately ${Object.values(productLinesByArea).flat().find(p => selectedProductLineIds.includes(p.id))?.currentNetPnL.toLocaleString() || 'N/A'}.
        `;
        
        const prompt = `You are a financial analyst AI for the Sapphire application. Answer the user's question about their data. 
        Use the provided data context and Google Search for real-time information if needed. Always cite your sources from Google Search if you use them.
        Data Context: ${dataContext}
        User Question: "${analyticsQuestion}"`;

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{googleSearch: {}}],
            },
        });

        setAnalyticsAnswer(response.text);
        setAnalyticsSources(response.candidates?.[0]?.groundingMetadata?.groundingChunks || []);

    } catch (error) {
        console.error("Error with conversational analytics:", error);
        setAnalyticsAnswer("I'm sorry, I encountered an error trying to answer your question. Please try again.");
    } finally {
        setIsAsking(false);
    }
  };

  const handleViewReportFullScreen = (report: ReportItem) => {
    setReportToViewInFullScreen(report);
    setIsFullScreenViewerOpen(true);
  };

  const handleOpenSendModal = (report: ReportItem) => {
    setReportToSend(report);
    setIsSendModalOpen(true);
  };
  
  const handleCloseFullScreenViewer = () => {
    setIsFullScreenViewerOpen(false);
    setReportToViewInFullScreen(null);
  };

  const handleSendFromFullScreen = (report: ReportItem) => {
    setIsFullScreenViewerOpen(false);
    setReportToViewInFullScreen(null);
    handleOpenSendModal(report);
  };

  const handleConfirmSendReport = (
    title: string,
    selectedListIds: string[],
    customEmails: string,
    format: 'PDF' | 'Excel' | 'CSV'
  ) => {
    const selectedListNames = MOCK_DISTRIBUTION_LISTS
      .filter(list => selectedListIds.includes(list.id))
      .map(list => list.name)
      .join(', ');

    let message = `Simulating send for report: "${title}" in ${format} format.\n`;
    if (selectedListNames) message += `Selected Distribution Lists: ${selectedListNames}\n`;
    if (customEmails) message += `Custom Emails: ${customEmails}\n`;
    if (!selectedListNames && !customEmails) message += "No recipients specified.\n";
    
    alert(message + "(In a real app, this would dispatch the report)");
    setIsSendModalOpen(false);
    setReportToSend(null);
  };
    
  const reportsByFrequency = (reports: ReportItem[]) => {
      return reports.sort((a, b) => {
        const order = { Daily: 1, Weekly: 2, Monthly: 3, Quarterly: 4 };
        return order[a.frequency] - order[b.frequency];
      }).reduce((acc, report) => {
        const freq = report.frequency;
        if (!acc[freq]) {
          acc[freq] = [];
        }
        acc[freq].push(report);
        return acc;
      }, {} as Record<string, ReportItem[]>);
  };
  
  const frequencies: ('Daily' | 'Weekly' | 'Monthly' | 'Quarterly')[] = ['Daily', 'Weekly', 'Monthly', 'Quarterly'];

  return (
    <div className="space-y-6">
      <DashboardCard title={<div className="flex items-center"><ChatBubbleLeftRightIcon className="w-6 h-6 mr-2"/>Talk to Your Data</div>}>
        <div className="space-y-3">
            <div className="flex space-x-2">
                 <input
                    type="text"
                    value={analyticsQuestion}
                    onChange={(e) => setAnalyticsQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleTalkToData()}
                    placeholder="e.g., What was the biggest market news affecting my strategies today?"
                    className="flex-grow w-full p-2 border border-slate-300 rounded-lg focus:ring-sky-500 focus:border-sky-500 text-sm"
                    disabled={isAsking}
                />
                <button
                    onClick={handleTalkToData}
                    disabled={isAsking || !analyticsQuestion.trim()}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg disabled:bg-indigo-300 disabled:cursor-not-allowed hover:bg-indigo-700 transition-colors flex items-center"
                    aria-label="Ask AI Analyst"
                >
                    <PaperAirplaneIcon className="w-5 h-5 mr-2" />
                    {isAsking ? 'Thinking...' : 'Ask'}
                </button>
            </div>
            {(analyticsAnswer || isAsking) && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg animate-fadeIn">
                    {isAsking ? (
                        <p className="text-slate-500">The AI analyst is reviewing your question...</p>
                    ) : (
                        <>
                            <p className="text-slate-700 whitespace-pre-wrap">{analyticsAnswer}</p>
                            {analyticsSources.length > 0 && (
                                <div className="mt-4 pt-2 border-t border-slate-200">
                                    <h5 className="text-xs font-semibold text-slate-600 mb-1 flex items-center"><LinkIcon className="w-3 h-3 mr-1.5"/>Sources:</h5>
                                    <ul className="space-y-1">
                                        {analyticsSources.map((source, index) => source.web && (
                                            <li key={index}>
                                                <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-sky-600 hover:underline">
                                                    {source.web.title || source.web.uri}
                                                </a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </>
                    )}
                </div>
            )}
        </div>
         <style>{`
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
        `}</style>
      </DashboardCard>
      
      <DashboardCard title="Analytics Hub">
        <div className="space-y-3">
          {MOCK_REPORTS_DATA.map((category) => {
            const isOpen = openAccordion === category.categoryId;
            const currentReportsByFreq = reportsByFrequency(category.reports);

            return (
              <div key={category.categoryId} className="border border-slate-200 rounded-lg overflow-hidden transition-all duration-300">
                <h2>
                  <button
                    type="button"
                    className="w-full flex justify-between items-center p-4 text-left bg-slate-50 hover:bg-slate-100 transition-colors"
                    onClick={() => setOpenAccordion(isOpen ? null : category.categoryId)}
                    aria-expanded={isOpen}
                    aria-controls={`accordion-content-${category.categoryId}`}
                  >
                    <span className="text-lg font-semibold text-slate-700">{category.categoryTitle}</span>
                    {isOpen ? <ChevronUpIcon className="w-5 h-5 text-slate-500" /> : <ChevronDownIcon className="w-5 h-5 text-slate-500" />}
                  </button>
                </h2>
                {isOpen && (
                  <div
                    id={`accordion-content-${category.categoryId}`}
                    className="p-4 bg-white"
                  >
                    <div className="space-y-6">
                      {category.categoryId === 'mgmt_reports' && (
                          <div className="mb-6">
                            <h3 className="text-base font-bold text-slate-600 mb-3">Adjustments Created Today</h3>
                            {adjustmentsToday.length > 0 ? (
                                <div className="overflow-x-auto rounded-lg border border-slate-200">
                                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                                        <thead className="bg-slate-100">
                                            <tr>
                                                <th className="px-3 py-2 text-left font-semibold text-slate-600">ID</th>
                                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Type</th>
                                                <th className="px-3 py-2 text-right font-semibold text-slate-600">Amount</th>
                                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Justification</th>
                                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-slate-100">
                                            {adjustmentsToday.map(adj => (
                                                <tr key={adj.id}>
                                                    <td className="px-3 py-2 whitespace-nowrap font-medium text-sky-700">{adj.id}</td>
                                                    <td className="px-3 py-2 whitespace-nowrap">{adj.type}</td>
                                                    <td className={`px-3 py-2 whitespace-nowrap text-right font-semibold ${adj.amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(adj.amount, adj.currency)}</td>
                                                    <td className="px-3 py-2 whitespace-normal max-w-xs truncate">{adj.justification}</td>
                                                    <td className="px-3 py-2 whitespace-nowrap"><StatusPill status={adj.status} /></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <p className="text-slate-500 text-center py-4 bg-slate-50 rounded-md">No adjustments have been created today for the selected filters.</p>
                            )}
                          </div>
                      )}

                      {frequencies.map(freq => (
                        currentReportsByFreq[freq] && (
                          <div key={freq}>
                            <h3 className="text-base font-bold text-slate-600 mb-3">{freq} Reports</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                              {currentReportsByFreq[freq].map(report => (
                                <ReportCard 
                                    key={report.id} 
                                    report={report} 
                                    onView={handleViewReportFullScreen} 
                                    onSend={handleOpenSendModal}
                                />
                              ))}
                            </div>
                          </div>
                        )
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </DashboardCard>
      
      {reportToSend && (
        <SendReportModal
          isOpen={isSendModalOpen}
          onClose={() => setIsSendModalOpen(false)}
          reportTitle={reportToSend.title}
          defaultFormat={reportToSend.defaultFormat}
          distributionLists={MOCK_DISTRIBUTION_LISTS}
          onConfirmSend={handleConfirmSendReport}
        />
      )}

      {isFullScreenViewerOpen && reportToViewInFullScreen && (
        <FullScreenReportViewer
          report={reportToViewInFullScreen}
          onClose={handleCloseFullScreenViewer}
          onSend={handleSendFromFullScreen}
        />
      )}
    </div>
  );
};

export default AnalyticsPage;
