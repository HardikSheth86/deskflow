
import React, { useEffect, useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { BeakerIcon, CheckCircleIcon, XCircleIcon } from '../components/icons';
import { formatCurrency, calculateDoDChange, determineProductLineStatus, formatDateDistance, calculateProductLineAggregates } from '../utils/helpers';
import { ExceptionStatus, ProcessStatus, SignOffStrategy, BusinessArea, Region, Adjustment, AdjustmentType, ExceptionCategory } from '../types';
import StatusPill from '../components/StatusPill';

interface TestResult {
    description: string;
    pass: boolean;
    details?: string;
    error?: string;
}

const TestResultItem: React.FC<{ result: TestResult }> = ({ result }) => {
    return (
        <div className={`p-3 flex justify-between items-center border-l-4 ${result.pass ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
            <div>
                <p className={`font-semibold ${result.pass ? 'text-green-800' : 'text-red-800'}`}>{result.description}</p>
                {result.details && <p className="text-xs text-slate-600 mt-1"><strong>Details:</strong> {result.details}</p>}
                {!result.pass && <p className="text-xs text-red-700 mt-1"><strong>Error:</strong> {result.error || 'Test failed without a specific error message.'}</p>}
            </div>
            {result.pass ? 
                <div className="flex items-center text-green-600">
                    <CheckCircleIcon className="w-5 h-5 mr-1" />
                    <span>PASS</span>
                </div>
                : 
                <div className="flex items-center text-red-600">
                    <XCircleIcon className="w-5 h-5 mr-1" />
                    <span>FAIL</span>
                </div>
            }
        </div>
    );
}

const TestingPage: React.FC = () => {
    const { setCurrentPageTitle, exceptions, updateException, saveAdjustment } = useAppContext();
    const [testResults, setTestResults] = useState<TestResult[]>([]);
    const [isRunning, setIsRunning] = useState(true);

    useEffect(() => {
        setCurrentPageTitle('Application Test Suite');
    }, [setCurrentPageTitle]);

    const runTests = () => {
        setIsRunning(true);
        const results: TestResult[] = [];

        // --- Utility Function Tests ---
        const runUtilTests = () => {
            const suite = 'Utility Function Tests';
            // formatCurrency
            try {
                const positive = formatCurrency(12345.67, 'USD');
                const negative = formatCurrency(-500, 'JPY');
                const withSign = formatCurrency(100, 'EUR', true);
                if (positive === '$12,346' && negative === '-¥500' && withSign === '+€100') {
                    results.push({ description: `[${suite}] \`formatCurrency\` should format positive, negative, and signed values.`, pass: true });
                } else {
                    results.push({ description: `[${suite}] \`formatCurrency\` should format values.`, pass: false, error: `Got: ${positive}, ${negative}, ${withSign}` });
                }
            } catch (e: any) { results.push({ description: `[${suite}] \`formatCurrency\``, pass: false, error: e.message }); }

            // calculateDoDChange
            try {
                const dod = calculateDoDChange(110, 100);
                const fromZero = calculateDoDChange(50, 0);
                if (dod.amount === 10 && dod.percentage === 10 && fromZero.percentage === 100) {
                    results.push({ description: `[${suite}] \`calculateDoDChange\` should calculate positive and from-zero change.`, pass: true });
                } else {
                    results.push({ description: `[${suite}] \`calculateDoDChange\` should calculate positive and from-zero change.`, pass: false, error: `Got amount: ${dod.amount}, percentage: ${dod.percentage}` });
                }
            } catch (e: any) { results.push({ description: `[${suite}] \`calculateDoDChange\``, pass: false, error: e.message }); }

            // determineProductLineStatus
            try {
                const s = (status: ProcessStatus) => ({ status } as SignOffStrategy);
                const statusAllSignedOff = determineProductLineStatus([ s(ProcessStatus.SIGNED_OFF) ]);
                const statusOneRejected = determineProductLineStatus([ s(ProcessStatus.SIGNED_OFF), s(ProcessStatus.REJECTED) ]);
                const statusInProgress = determineProductLineStatus([ s(ProcessStatus.SIGNED_OFF), s(ProcessStatus.AWAITING_SIGN_OFF) ]);
                if (statusAllSignedOff === ProcessStatus.AWAITING_SIGN_OFF && statusOneRejected === ProcessStatus.REJECTED && statusInProgress === ProcessStatus.IN_PROGRESS) {
                     results.push({ description: `[${suite}] \`determineProductLineStatus\` should correctly roll up status.`, pass: true, details: `Got: Awaiting Sign-off, Rejected, In Progress` });
                } else {
                     results.push({ description: `[${suite}] \`determineProductLineStatus\` should correctly roll up status.`, pass: false, error: `Expected Awaiting/Rejected/In Progress, got ${statusAllSignedOff}/${statusOneRejected}/${statusInProgress}` });
                }
            } catch (e: any) { results.push({ description: `[${suite}] \`determineProductLineStatus\``, pass: false, error: e.message }); }

             // calculateProductLineAggregates
            try {
                const strategies = [
                    { currentNetPnL: 100, previousNetPnL: 80, currentTotalAssets: 1000, previousTotalAssets: 900, currentTotalLiabilities: 500, previousTotalLiabilities: 450 },
                    { currentNetPnL: 50, previousNetPnL: 50, currentTotalAssets: 500, previousTotalAssets: 500, currentTotalLiabilities: 200, previousTotalLiabilities: 200 },
                ] as SignOffStrategy[];
                const aggs = calculateProductLineAggregates(strategies);
                if(aggs.currentNetPnL === 150 && aggs.currentTotalAssets === 1500) {
                    results.push({ description: `[${suite}] \`calculateProductLineAggregates\` should sum financials correctly.`, pass: true });
                } else {
                    results.push({ description: `[${suite}] \`calculateProductLineAggregates\` should sum financials correctly.`, pass: false, error: `Expected 150/1500, got ${aggs.currentNetPnL}/${aggs.currentTotalAssets}` });
                }
            } catch (e: any) { results.push({ description: `[${suite}] \`calculateProductLineAggregates\``, pass: false, error: e.message }); }

        };
        runUtilTests();
        
        // --- Component Rendering Smoke Tests ---
        const runSmokeTests = () => {
            const suite = 'Smoke Tests';
             try {
                const Card = () => <DashboardCard title="Test">Child</DashboardCard>;
                Card(); // "Render"
                results.push({ description: `[${suite}] Component \`DashboardCard\` should render without crashing.`, pass: true });
            } catch(e: any) { results.push({ description: `[${suite}] Component \`DashboardCard\``, pass: false, error: e.message }); }
            
            try {
                const Pill = () => <StatusPill status={ProcessStatus.SIGNED_OFF} />;
                Pill(); // "Render"
                results.push({ description: `[${suite}] Component \`StatusPill\` should render without crashing.`, pass: true });
            } catch(e: any) { results.push({ description: `[${suite}] Component \`StatusPill\``, pass: false, error: e.message }); }
        };
        runSmokeTests();

        // --- Context State Management Tests ---
        const runCtxtTests = () => {
            const suite = 'Context Tests';
            try {
                const testExceptionId = 'EXC-TCM-01';
                const originalException = exceptions.find(ex => ex.id === testExceptionId);
                
                if (originalException) {
                    const updatedException = { ...originalException, status: ExceptionStatus.RESOLVED };
                    updateException(updatedException);
                    results.push({ description: `[${suite}] \`updateException\` context function should be callable.`, pass: true });
                } else {
                    results.push({ description: `[${suite}] \`updateException\` context function should be callable.`, pass: false, error: `Test exception with ID ${testExceptionId} not found.`});
                }
            } catch (e: any) { results.push({ description: `[${suite}] \`updateException\``, pass: false, error: e.message }); }
            
            try {
                const newAdjustment: Adjustment = {
                    id: 'ADJ-TEST-123', type: AdjustmentType.OTHER, amount: 100, currency: 'USD', debitAccount: 'TEST_DR',
                    creditAccount: 'TEST_CR', justification: 'Test adjustment', status: 'DRAFT', createdBy: 'Test Suite',
                    createdAt: new Date().toISOString(), businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS, productLineId: 'PL_LTERM_DEBT',
                    strategyId: 'SN_FID', region: Region.NORTH_AMERICA
                };
                saveAdjustment(newAdjustment); // Calling the function
                results.push({ description: `[${suite}] \`saveAdjustment\` context function should be callable without error.`, pass: true });
            } catch (e: any) { results.push({ description: `[${suite}] \`saveAdjustment\``, pass: false, error: e.message }); }
        };
        runCtxtTests();
        
        setTestResults(results);
        setIsRunning(false);
    };

    useEffect(() => {
        runTests();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // Run tests once on mount

    const passedCount = testResults.filter(r => r.pass).length;
    const failedCount = testResults.length - passedCount;

    return (
        <div className="space-y-6">
            <DashboardCard title={<div className="flex items-center"><BeakerIcon className="w-6 h-6 mr-2" /> Application Test Suite</div>}>
                <div className="flex justify-between items-center">
                    <p className="text-slate-600">
                        This page runs a series of automated unit and integration tests to verify core application functionality.
                    </p>
                    <button 
                        onClick={runTests} 
                        disabled={isRunning}
                        className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50"
                    >
                        {isRunning ? 'Running...' : 'Re-run Tests'}
                    </button>
                </div>
            </DashboardCard>

            <DashboardCard title="Test Results">
                <div className="flex justify-between items-center mb-4 p-3 bg-slate-50 rounded-lg">
                    <div className="text-lg font-semibold text-slate-700">
                        Summary: {testResults.length} tests run
                    </div>
                    <div className="flex space-x-4">
                        <span className="font-semibold text-green-600">Passed: {passedCount}</span>
                        <span className="font-semibold text-red-600">Failed: {failedCount}</span>
                    </div>
                </div>
                <div className="space-y-2">
                    {testResults.map((result, index) => (
                        <TestResultItem key={index} result={result} />
                    ))}
                </div>
                 {isRunning && <p className="text-center p-4 text-slate-500">Tests are running...</p>}
            </DashboardCard>
        </div>
    );
};

export default TestingPage;
