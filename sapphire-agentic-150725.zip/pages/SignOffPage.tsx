

import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { ProcessStatus, SignOffProductLine, SignOffStrategy, ContextMenuItemType, SelectionLevel } from '../types';
import { formatCurrency, calculateProductLineAggregates, determineProductLineStatus } from '../utils/helpers';
import StatusPill from '../components/StatusPill';
import { CheckCircleIcon, XCircleIcon, ChevronDownIcon, ChevronUpIcon, CpuChipIcon, ListBulletIcon, EyeIcon, ArrowLeftIcon } from '../components/icons';
import Modal from '../components/Modal';
import SignOffDrillDown from '../components/SignOffDrillDown';
import ContextMenu from '../components/ContextMenu';
import SignOffBriefingModal from '../components/SignOffBriefingModal';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Hierarchical Data Structure: ProductLine -> Strategy Group -> Regional Strategy Instance
type GroupedData = Record<string, Record<string, SignOffStrategy[]>>; // { [plId]: { [strategyName]: regionalInstances[] } }

/**
 * A memoized component for rendering a Product Line row in the sign-off table.
 * Encapsulates the logic and layout for a top-level item.
 */
const ProductLineRow = React.memo(({ 
    pl, 
    plAggregates, 
    isExpanded, 
    onToggleExpand, 
    isSelected, 
    onSelect, 
    onContextMenu, 
    onCommentaryEdit, 
    editingCommentary, 
    onCommentaryChange,
    isMenuOpen,
    menuItems,
    onCloseMenu
}: any) => {
    return (
        <tr className="bg-slate-50 border-t-2 border-slate-300 hover:bg-slate-100" onContextMenu={onContextMenu}>
            <td className="px-4 py-2 text-center relative">
                <input type="checkbox" className="h-4 w-4 rounded border-slate-400 text-sky-600 focus:ring-sky-500" onChange={onSelect} checked={isSelected} />
            </td>
            <td className="px-4 py-2 font-bold text-slate-800 truncate">
                <button onClick={onToggleExpand} className="flex items-center">
                    {isExpanded ? <ChevronUpIcon className="w-4 h-4 mr-2" /> : <ChevronDownIcon className="w-4 h-4 mr-2" />} {pl.name}
                </button>
            </td>
            <td className="px-4 py-2"><StatusPill status={pl.status} /></td>
            <td className="px-4 py-2 text-right font-semibold">{formatCurrency(plAggregates.currentNetPnL!, pl.currency)}</td>
            <td className="px-4 py-2 text-right font-semibold">{formatCurrency(plAggregates.currentTotalAssets!, pl.currency)}</td>
            <td className="px-4 py-2 truncate" onClick={onCommentaryEdit}>
                {editingCommentary?.id === pl.id ? 
                    <textarea defaultValue={pl.commentary} autoFocus onBlur={(e) => onCommentaryChange(pl.id, 'ProductLine', e.target.value)} className="w-full text-xs p-1 border rounded" /> : 
                    <span className="text-slate-600 text-xs italic truncate block cursor-pointer">{pl.commentary || "Click to add comment..."}</span> }
            </td>
            <td className="px-4 py-2 text-center relative">
                <button onClick={onContextMenu} className="p-1 rounded-full hover:bg-slate-200" aria-label={`Actions for ${pl.name}`}>
                    <ListBulletIcon className="w-5 h-5 text-slate-500" />
                </button>
                {isMenuOpen && <ContextMenu isOpen={true} items={menuItems} onClose={onCloseMenu} />}
            </td>
        </tr>
    );
});

/**
 * A memoized component for rendering a Strategy Group row in the sign-off table.
 * Encapsulates the logic and layout for a mid-level aggregate item.
 */
const StrategyGroupRow = React.memo(({ 
    strategyName, 
    aggregates, 
    status, 
    isExpanded, 
    onToggleExpand, 
    isSelected, 
    onSelect, 
    onContextMenu,
    isMenuOpen,
    menuItems,
    onCloseMenu
}: any) => {
    return (
        <tr className="bg-white hover:bg-slate-50" onContextMenu={onContextMenu}>
            <td className="pl-8 pr-4 py-2 text-center relative">
                <input type="checkbox" className="h-4 w-4 rounded border-slate-400 text-sky-600 focus:ring-sky-500" onChange={onSelect} checked={isSelected} />
            </td>
            <td className="pl-8 pr-4 py-2 font-semibold text-slate-700 truncate">
                <button onClick={onToggleExpand} className="flex items-center">
                    {isExpanded ? <ChevronUpIcon className="w-4 h-4 mr-2" /> : <ChevronDownIcon className="w-4 h-4 mr-2" />} {strategyName}
                </button>
            </td>
            <td className="px-4 py-2"><StatusPill status={status} /></td>
            <td className="px-4 py-2 text-right font-medium">{formatCurrency(aggregates.currentNetPnL!, aggregates.currency)}</td>
            <td className="px-4 py-2 text-right font-medium">{formatCurrency(aggregates.currentTotalAssets!, aggregates.currency)}</td>
            <td className="px-4 py-2"></td>
            <td className="px-4 py-2 text-center relative">
                <button onClick={onContextMenu} className="p-1 rounded-full hover:bg-slate-200" aria-label={`Actions for strategy ${strategyName}`}>
                    <ListBulletIcon className="w-5 h-5 text-slate-500" />
                </button>
                 {isMenuOpen && <ContextMenu isOpen={true} items={menuItems} onClose={onCloseMenu} />}
            </td>
        </tr>
    );
});

/**
 * A memoized component for rendering a regional Strategy instance row in the sign-off table.
 * Encapsulates the logic and layout for the lowest-level granular item.
 */
const StrategyRow = React.memo(({ 
    s, 
    isSelected, 
    onSelect, 
    onContextMenu, 
    onCommentaryEdit, 
    editingCommentary, 
    onCommentaryChange,
    isMenuOpen,
    menuItems,
    onCloseMenu
}: any) => {
    return (
        <tr className="hover:bg-sky-50" onContextMenu={onContextMenu}>
            <td className="pl-16 pr-4 py-2 text-center relative">
                <input type="checkbox" className="h-4 w-4 rounded border-slate-400 text-sky-600 focus:ring-sky-500" onChange={onSelect} checked={isSelected} />
            </td>
            <td className="pl-16 pr-4 py-2 text-slate-700">{s.region}</td>
            <td className="px-4 py-2"><StatusPill status={s.status} /></td>
            <td className="px-4 py-2 text-right">{formatCurrency(s.currentNetPnL, s.currency)}</td>
            <td className="px-4 py-2 text-right">{formatCurrency(s.currentTotalAssets, s.currency)}</td>
            <td className="px-4 py-2 truncate" onClick={onCommentaryEdit}>
                {editingCommentary?.id === s.id ? 
                    <textarea defaultValue={s.commentary} autoFocus onBlur={(e) => onCommentaryChange(s.id, 'Strategy', e.target.value)} className="w-full text-xs p-1 border rounded" /> : 
                    <span className="text-slate-600 text-xs italic truncate block cursor-pointer">{s.commentary || "Click to add comment..."}</span> }
            </td>
            <td className="px-4 py-2 text-center relative">
                <button onClick={onContextMenu} className="p-1 rounded-full hover:bg-slate-200" aria-label={`Actions for ${s.name} in ${s.region}`}>
                    <ListBulletIcon className="w-5 h-5 text-slate-500" />
                </button>
                 {isMenuOpen && <ContextMenu isOpen={true} items={menuItems} onClose={onCloseMenu} />}
            </td>
        </tr>
    );
});

const SignOffPage: React.FC = () => {
    const { 
        setCurrentPageTitle,
        productLinesByArea,
        updateSignOffStatus,
        updateSignOffItem,
        selectedBusinessAreas,
        selectedProductLineIds,
        selectedStrategies,
        selectedRegions,
    } = useAppContext();

    const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
    const [selectedItems, setSelectedItems] = useState<Record<string, SelectionLevel>>({});
    const [isRejectionModalOpen, setIsRejectionModalOpen] = useState(false);
    const [rejectionComment, setRejectionComment] = useState('');
    const [editingCommentary, setEditingCommentary] = useState<{ id: string, level: 'ProductLine' | 'Strategy', originalValue: string } | null>(null);
    const [drillDownStrategy, setDrillDownStrategy] = useState<SignOffStrategy | null>(null);
    
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);
    const [contextMenuItem, setContextMenuItem] = useState<{ item: any; level: SelectionLevel | '' } | null>(null);

    // AI Briefing State
    const [isBriefingModalOpen, setIsBriefingModalOpen] = useState(false);
    const [briefingContent, setBriefingContent] = useState('');
    const [isGeneratingBriefing, setIsGeneratingBriefing] = useState(false);
    const [briefingTargetName, setBriefingTargetName] = useState('');


    useEffect(() => {
        setCurrentPageTitle('Sign-Off Workbench');
        const initialExpanded: Record<string, boolean> = {};
        Object.values(productLinesByArea).flat().forEach(pl => {
            initialExpanded[pl.id] = true;
            const strategyNames = new Set(pl.strategies.map(s => s.name));
            strategyNames.forEach(name => {
                const strategyGroupId = `${pl.id}-${name.replace(/\s+/g, '_')}`;
                initialExpanded[strategyGroupId] = true;
            });
        });
        setExpandedRows(initialExpanded);
    }, [setCurrentPageTitle, productLinesByArea]);
    
    useEffect(() => {
        setSelectedItems({});
        setDrillDownStrategy(null);
    }, [selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions]);

    const groupedData: GroupedData = useMemo(() => {
        const allPls = Object.values(productLinesByArea).flat();
        const data: GroupedData = {};

        allPls
            .filter(pl => (selectedBusinessAreas.length === 0 || selectedBusinessAreas.includes(pl.businessArea)))
            .filter(pl => (selectedProductLineIds.length === 0 || selectedProductLineIds.includes(pl.id)))
            .forEach(pl => {
                const strategyMap: Record<string, SignOffStrategy[]> = {};
                pl.strategies
                    .filter(s => (selectedRegions.length === 0 || selectedRegions.includes(s.region)))
                    .filter(s => (selectedStrategies.length === 0 || selectedStrategies.includes(s.id)))
                    .forEach(s => {
                        if (!strategyMap[s.name]) {
                            strategyMap[s.name] = [];
                        }
                        strategyMap[s.name].push(s);
                    });

                if (Object.keys(strategyMap).length > 0) {
                    data[pl.id] = strategyMap;
                }
            });
        return data;
    }, [productLinesByArea, selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions]);


    const allProductLines = useMemo(() => Object.values(productLinesByArea).flat(), [productLinesByArea]);

    const handleToggleExpand = (id: string) => setExpandedRows(prev => ({ ...prev, [id]: !prev[id] }));

    const handleSelect = (id: string, level: SelectionLevel, children: {id: string, level: SelectionLevel}[] = []) => {
        setDrillDownStrategy(null);
        setSelectedItems(prev => {
            const newSelected = { ...prev };
            const isSelected = !!newSelected[id];
            
            if (isSelected) {
                delete newSelected[id];
                children.forEach(child => delete newSelected[child.id]);
            } else {
                newSelected[id] = level;
                children.forEach(child => {
                    newSelected[child.id] = child.level
                });
            }
            // If selecting a strategy instance, show drilldown
            if(level === 'Strategy' && !isSelected) {
                const pl = allProductLines.find(p => p.strategies.some(s => s.id === id));
                const strat = pl?.strategies.find(s => s.id === id);
                if(strat) {
                     setDrillDownStrategy(strat);
                }
            }
            return newSelected;
        });
    };

    const handleCommentaryChange = (id: string, level: 'ProductLine' | 'Strategy', newComment: string) => {
        let itemToUpdate = null;
        if(level === 'ProductLine') {
            itemToUpdate = allProductLines.find(pl => pl.id === id);
        } else { // Strategy instance
             for (const pl of allProductLines) {
                const found = pl.strategies.find(s => s.id === id);
                if (found) {
                    itemToUpdate = found;
                    break;
                }
            }
        }
        if (itemToUpdate) {
            updateSignOffItem({ ...itemToUpdate, commentary: newComment });
        }
        setEditingCommentary(null);
    }
    
    const performBulkUpdate = (newStatus: ProcessStatus) => {
        const itemsToUpdate = Object.entries(selectedItems);
        if (itemsToUpdate.length === 0) return;
        
        let updateCount = 0;

        itemsToUpdate.forEach(([id, level]) => {
            if (level === 'ProductLine') {
                updateSignOffStatus(id, 'ProductLine', newStatus);
                updateCount++;
            } else if (level === 'Strategy') {
                updateSignOffStatus(id, 'Strategy', newStatus);
                updateCount++;
            } else if (level === 'StrategyGroup') {
                const [plId, ...strategyNameParts] = id.split('-');
                const strategyName = strategyNameParts.join('-').replace(/_/g, ' ');
                const regionalInstances = groupedData[plId]?.[strategyName] || [];
                regionalInstances.forEach(s => {
                    updateSignOffStatus(s.id, 'Strategy', newStatus);
                });
                updateCount++;
            }
        });
        
        let actionVerb = 'updated';
        if (newStatus === ProcessStatus.SIGNED_OFF) actionVerb = 'signed off';
        if (newStatus === ProcessStatus.REJECTED) actionVerb = 'rejected';
        if (newStatus === ProcessStatus.AWAITING_SIGN_OFF) actionVerb = 'unsigned';

        alert(`${updateCount} items have been ${actionVerb}.`);
        setSelectedItems({});
        setRejectionComment('');
        setIsRejectionModalOpen(false);
    }

    const handleOpenRejectionModal = () => {
        if (Object.keys(selectedItems).length > 0) {
            setIsRejectionModalOpen(true);
        }
    }

    const handleConfirmRejection = () => {
        if (!rejectionComment.trim()) {
            alert('A comment is required to reject items.');
            return;
        }
        performBulkUpdate(ProcessStatus.REJECTED);
    };

    const handleGenerateBriefing = async (targetItem: any, targetLevel: string) => {
        if (!process.env.API_KEY) {
            setBriefingContent("API Key not configured. AI features are unavailable.");
            return;
        }
        setIsGeneratingBriefing(true);
        setBriefingContent('');
        setBriefingTargetName(targetItem.name);
        setIsBriefingModalOpen(true);

        const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
        
        let dataSummary = `Level: ${targetLevel}, Name: ${targetItem.name}, Status: ${targetItem.status}, Currency: ${targetItem.currency}`;
        dataSummary += `, PnL: ${formatCurrency(targetItem.currentNetPnL, targetItem.currency)}, Assets: ${formatCurrency(targetItem.currentTotalAssets, targetItem.currency)}`;
        if(targetLevel === 'ProductLine' || targetLevel === 'StrategyGroup') {
            dataSummary += `, Contained Items: ${targetItem.strategies?.length || 'N/A'}`;
        }
        
        const prompt = `You are an AI financial analyst, the "AI Sign-Off Steward". Generate a concise sign-off briefing based on the following data summary. 
        Highlight key metrics, status, significant changes, and any potential risks or items requiring attention based on the numbers. 
        Structure your response with these sections: 
        1. **Overall Status & Recommendation:** A quick summary and a suggested action (e.g., 'Ready for Sign-off', 'Requires further investigation').
        2. **Key Financials:** A brief rundown of the P&L and Asset values.
        3. **Items for Attention:** Any notable points, like a rejected status or large variance that a controller should be aware of.
        The tone should be professional and informative.
        
        Data Summary:
        ${dataSummary}`;
        
        try {
            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });
            setBriefingContent(response.text);
        } catch (error) {
            console.error(error);
            setBriefingContent("An error occurred while generating the AI briefing.");
        } finally {
            setIsGeneratingBriefing(false);
        }
    }
    
    const handleContextMenu = (event: React.MouseEvent, item: any, level: SelectionLevel, id: string) => {
        event.preventDefault();
        event.stopPropagation();
        setOpenMenuId(openMenuId === id ? null : id); // Toggle behavior
        setContextMenuItem({ item, level });
    }

    const closeContextMenu = () => {
        setOpenMenuId(null);
        setContextMenuItem(null);
    }
    
    const getContextMenuItems = (): ContextMenuItemType[] => {
        if (!contextMenuItem || !contextMenuItem.item || !contextMenuItem.level) return [];
        const { item, level } = contextMenuItem;
        
        const isGroup = level === 'StrategyGroup';
        
        const singleAction = (newStatus: ProcessStatus) => {
            if (isGroup) {
                const { strategies } = item;
                strategies.forEach((s: SignOffStrategy) => updateSignOffStatus(s.id, 'Strategy', newStatus));
            } else {
                updateSignOffStatus(item.id, level as 'ProductLine' | 'Strategy', newStatus);
            }
        };

        const isSignedOff = item.status === ProcessStatus.SIGNED_OFF;
        const isRejected = item.status === ProcessStatus.REJECTED;
        const isAwaitingOrInProgress = !isSignedOff && !isRejected;

        return [
            { label: "Sign Off", icon: CheckCircleIcon, onClick: () => singleAction(ProcessStatus.SIGNED_OFF), disabled: isSignedOff },
            { label: "Unsign Off", icon: ArrowLeftIcon, onClick: () => singleAction(ProcessStatus.AWAITING_SIGN_OFF), disabled: isAwaitingOrInProgress },
            { label: "Reject", icon: XCircleIcon, onClick: () => singleAction(ProcessStatus.REJECTED), disabled: isRejected },
            { isSeparator: true },
            { label: "AI Briefing", icon: CpuChipIcon, onClick: () => handleGenerateBriefing(item, level) },
            { label: "View Details", icon: EyeIcon, onClick: () => setDrillDownStrategy(item), disabled: level !== 'Strategy'},
        ];
    }

  return (
    <div className="flex flex-col h-full">
      <div className="space-y-6 p-6 flex-shrink-0">
        <DashboardCard title="Bulk Sign-Off Workbench">
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <p className="text-slate-600 max-w-3xl text-sm">
                Expand items to view the hierarchy. Select items using checkboxes for bulk actions, or click the action button for individual actions. 
                Select a single strategy's regional instance to view its detailed drill-down at the bottom.
              </p>
              <div className="flex-shrink-0 flex items-center space-x-2">
                  <button
                      onClick={() => performBulkUpdate(ProcessStatus.SIGNED_OFF)}
                      disabled={Object.keys(selectedItems).length === 0}
                      className="px-3 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                      <CheckCircleIcon className="w-4 h-4 mr-2" /> Sign Off
                  </button>
                   <button
                      onClick={() => performBulkUpdate(ProcessStatus.AWAITING_SIGN_OFF)}
                      disabled={Object.keys(selectedItems).length === 0}
                      className="px-3 py-1.5 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                      <ArrowLeftIcon className="w-4 h-4 mr-2" /> Unsign Off
                  </button>
                   <button
                      onClick={handleOpenRejectionModal}
                      disabled={Object.keys(selectedItems).length === 0}
                      className="px-3 py-1.5 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                      <XCircleIcon className="w-4 h-4 mr-2" /> Reject
                  </button>
                  <button
                      onClick={() => alert("Multi-item briefing not yet implemented. Please right-click one item for a briefing.")}
                      disabled={Object.keys(selectedItems).length === 0}
                      className="px-3 py-1.5 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                      <CpuChipIcon className="w-4 h-4 mr-2" /> AI Briefing
                  </button>
              </div>
          </div>
        </DashboardCard>
      </div>

      <div className="flex-grow overflow-y-auto px-6 pb-6">
        <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
          <table className="min-w-full text-sm table-fixed">
              <thead className="bg-slate-100">
                  <tr>
                      <th className="w-12 px-2"></th>
                      <th className="w-[30%] px-4 py-2 text-left font-semibold text-slate-600">Name</th>
                      <th className="w-36 px-4 py-2 text-left font-semibold text-slate-600">Status</th>
                      <th className="w-40 px-4 py-2 text-right font-semibold text-slate-600">Net P&L</th>
                      <th className="w-40 px-4 py-2 text-right font-semibold text-slate-600">Total Assets</th>
                      <th className="flex-1 px-4 py-2 text-left font-semibold text-slate-600">Commentary</th>
                      <th className="w-24 px-4 py-2 text-center font-semibold text-slate-600">Actions</th>
                  </tr>
              </thead>
              <tbody>
                  {Object.keys(groupedData).length === 0 && (
                      <tr><td colSpan={7} className="text-center p-8 text-slate-500">No sign-off items match the current filters.</td></tr>
                  )}
                  {Object.entries(groupedData).map(([plId, strategiesByName]) => {
                      const pl = allProductLines.find(p => p.id === plId)!;
                      const allStrategiesInView = Object.values(strategiesByName).flat();
                      const plAggregates = calculateProductLineAggregates(allStrategiesInView);
                      const isPlExpanded = !!expandedRows[pl.id];
                      const plChildrenToSelect = Object.entries(strategiesByName).flatMap(([strategyName, regionalInstances]) => {
                        const strategyGroupId = `${pl.id}-${strategyName.replace(/\s+/g, '_')}`;
                        return [
                            { id: strategyGroupId, level: 'StrategyGroup' as SelectionLevel },
                            ...regionalInstances.map(s => ({ id: s.id, level: 'Strategy' as SelectionLevel }))
                        ];
                      });

                      return (
                          <React.Fragment key={pl.id}>
                              <ProductLineRow
                                  pl={pl}
                                  plAggregates={plAggregates}
                                  isExpanded={isPlExpanded}
                                  onToggleExpand={() => handleToggleExpand(pl.id)}
                                  isSelected={!!selectedItems[pl.id]}
                                  onSelect={() => handleSelect(pl.id, 'ProductLine', plChildrenToSelect)}
                                  onContextMenu={(e: React.MouseEvent) => handleContextMenu(e, {...pl, ...plAggregates, strategies: allStrategiesInView}, 'ProductLine', pl.id)}
                                  onCommentaryEdit={() => setEditingCommentary({id: pl.id, level: 'ProductLine', originalValue: pl.commentary || ''})}
                                  editingCommentary={editingCommentary}
                                  onCommentaryChange={handleCommentaryChange}
                                  isMenuOpen={openMenuId === pl.id}
                                  menuItems={getContextMenuItems()}
                                  onCloseMenu={closeContextMenu}
                              />
                              
                              {isPlExpanded && Object.entries(strategiesByName).map(([strategyName, regionalInstances]) => {
                                  const strategyGroupAggregates = calculateProductLineAggregates(regionalInstances);
                                  const strategyGroupId = `${pl.id}-${strategyName.replace(/\s+/g, '_')}`;
                                  const isStrategyExpanded = !!expandedRows[strategyGroupId];
                                  const strategyGroupChildrenToSelect = regionalInstances.map(s => ({ id: s.id, level: 'Strategy' as SelectionLevel }));
                                  const strategyGroupStatus = determineProductLineStatus(regionalInstances);
                                  const strategyGroupItemForMenu = { id: strategyGroupId, name: strategyName, ...strategyGroupAggregates, currency: pl.currency, strategies: regionalInstances, status: strategyGroupStatus };

                                  return (
                                      <React.Fragment key={strategyGroupId}>
                                          <StrategyGroupRow
                                              strategyName={strategyName}
                                              aggregates={{...strategyGroupAggregates, currency: pl.currency}}
                                              status={strategyGroupStatus}
                                              isExpanded={isStrategyExpanded}
                                              onToggleExpand={() => handleToggleExpand(strategyGroupId)}
                                              isSelected={!!selectedItems[strategyGroupId]}
                                              onSelect={() => handleSelect(strategyGroupId, 'StrategyGroup', strategyGroupChildrenToSelect)}
                                              onContextMenu={(e: React.MouseEvent) => handleContextMenu(e, strategyGroupItemForMenu, 'StrategyGroup', strategyGroupId)}
                                              isMenuOpen={openMenuId === strategyGroupId}
                                              menuItems={getContextMenuItems()}
                                              onCloseMenu={closeContextMenu}
                                          />

                                          {isStrategyExpanded && regionalInstances.map(s => (
                                              <React.Fragment key={s.id}>
                                                  <StrategyRow
                                                      s={s}
                                                      isSelected={!!selectedItems[s.id]}
                                                      onSelect={() => handleSelect(s.id, 'Strategy')}
                                                      onContextMenu={(e: React.MouseEvent) => handleContextMenu(e, s, 'Strategy', s.id)}
                                                      onCommentaryEdit={() => setEditingCommentary({id: s.id, level: 'Strategy', originalValue: s.commentary || ''})}
                                                      editingCommentary={editingCommentary}
                                                      onCommentaryChange={handleCommentaryChange}
                                                      isMenuOpen={openMenuId === s.id}
                                                      menuItems={getContextMenuItems()}
                                                      onCloseMenu={closeContextMenu}
                                                  />
                                              </React.Fragment>
                                          ))}
                                      </React.Fragment>
                                  );
                              })}
                          </React.Fragment>
                      );
                  })}
              </tbody>
          </table>
        </div>
      </div>
      
      {drillDownStrategy && (
        <div className="flex-shrink-0 border-t-2 border-slate-300 p-4 bg-slate-100 shadow-[0_-5px_15px_-5px_rgba(0,0,0,0.1)]">
           <SignOffDrillDown strategy={drillDownStrategy} onClose={() => setDrillDownStrategy(null)} />
        </div>
      )}
      
      {isRejectionModalOpen && (
          <Modal isOpen={isRejectionModalOpen} onClose={() => setIsRejectionModalOpen(false)} title="Rejection Reason">
              <div className="space-y-4">
                  <p>A comment is required to reject the selected {Object.keys(selectedItems).length} item(s).</p>
                  <textarea value={rejectionComment} onChange={(e) => setRejectionComment(e.target.value)} rows={4} className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500" placeholder="Provide a clear reason for rejection..." />
                  <div className="flex justify-end space-x-2">
                      <button onClick={() => setIsRejectionModalOpen(false)} className="px-4 py-2 bg-slate-200 text-slate-800 rounded-md hover:bg-slate-300">Cancel</button>
                      <button onClick={handleConfirmRejection} disabled={!rejectionComment.trim()} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50">Confirm Rejection</button>
                  </div>
              </div>
          </Modal>
      )}
      
      <SignOffBriefingModal 
        isOpen={isBriefingModalOpen} 
        onClose={() => setIsBriefingModalOpen(false)}
        isLoading={isGeneratingBriefing}
        briefingContent={briefingContent}
        productLineName={briefingTargetName}
      />
    </div>
  );
};

export default SignOffPage;
