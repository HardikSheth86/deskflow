

import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Exception, Adjustment, AdjustmentType, ExceptionCategory, ReconDrillDown, ContextMenuItemType, RcaAnalysis } from '../types';
import DashboardCard from '../components/DashboardCard';
import ExceptionDetailModal from '../components/ExceptionDetailModal';
import { AdjustmentModal } from '../components/AdjustmentModal';
import ContextMenu from '../components/ContextMenu';
import { formatCurrency } from '../utils/helpers';
import { 
    CpuChipIcon, 
    AdjustmentIcon,
    ListBulletIcon,
    LightbulbIcon,
    EyeIcon,
    CloseIcon
} from '../components/icons';
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { MOCK_RECON_DRILLDOWN_DATA } from '../constants';

const CATEGORY_FILTERS: (ExceptionCategory | 'ALL')[] = [
  'ALL',
  ExceptionCategory.NEW_ACTIVITY,
  ExceptionCategory.DOD_VARIANCE,
  ExceptionCategory.TREASURY_VS_BU,
];

/**
 * A sub-component to render the detailed, tabular drill-down view for a single exception.
 * It fetches and displays multi-source reconciliation data.
 */
const DrillDownView: React.FC<{ exceptionId: string }> = ({ exceptionId }) => {
  const [drillDownData, setDrillDownData] = useState<ReconDrillDown | null>(null);

  useEffect(() => {
    // In a real app, this would be an API call
    const data = MOCK_RECON_DRILLDOWN_DATA[exceptionId] || null;
    setDrillDownData(data);
  }, [exceptionId]);

  if (!drillDownData) {
    return (
      <DashboardCard title="Drill Down">
        <p className="text-slate-500 text-center py-4">Drill-down data not available for this exception.</p>
      </DashboardCard>
    );
  }

  // Get all unique keys from all sources to build the table rows
  const allKeys = Array.from(new Set(drillDownData.sourceDetails.flatMap(sd => Object.keys(sd.values))));

  return (
    <div className="max-h-96 overflow-y-auto overflow-x-auto rounded-lg border border-slate-200 bg-white p-2">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-100 sticky top-0">
          <tr>
            <th className="px-3 py-2 text-left font-semibold text-slate-600 sticky left-0 bg-slate-100 z-10">Attribute</th>
            {drillDownData.sourceDetails.map(source => (
              <th key={source.sourceSystem} className="px-3 py-2 text-right font-semibold text-slate-600">
                {source.sourceSystem}
              </th>
            ))}
            <th className="px-3 py-2 text-right font-semibold text-slate-600">Variance</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-slate-100">
          {allKeys.map(key => {
            const values = drillDownData.sourceDetails.map(sd => sd.values[key]);
            const numericValues = values.filter(v => typeof v === 'number') as number[];
            const variance = numericValues.length > 1 ? Math.max(...numericValues) - Math.min(...numericValues) : null;
            // A row has a difference if the set of non-null/undefined values has more than one member
            const isDifferent = new Set(values.filter(v => v !== null && v !== undefined)).size > 1;

            return (
              <tr key={key} className={isDifferent ? 'bg-yellow-50' : ''}>
                <td className="px-3 py-2 font-medium text-slate-700 sticky left-0 bg-inherit z-10">{key}</td>
                {drillDownData.sourceDetails.map((source, index) => (
                  <td key={source.sourceSystem} className="px-3 py-2 text-right text-slate-600">
                    {values[index]?.toLocaleString() ?? 'N/A'}
                  </td>
                ))}
                <td className={`px-3 py-2 text-right font-semibold ${variance !== null && variance > 0 ? 'text-red-600' : 'text-slate-600'}`}>
                  {variance !== null ? variance.toLocaleString() : 'N/A'}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  );
};


const ExceptionSummaryPage: React.FC = () => {
  const { 
    setCurrentPageTitle, 
    exceptions, 
    updateException, 
    saveAdjustment,
    selectedBusinessAreas,
    selectedProductLineIds,
    selectedStrategies,
    selectedRegions,
  } = useAppContext();

  // Component State
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<ExceptionCategory | 'ALL'>('ALL');
  const [drillDownException, setDrillDownException] = useState<Exception | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
  const [modalTargetException, setModalTargetException] = useState<Exception | null>(null);
  const [adjustmentForModal, setAdjustmentForModal] = useState<Adjustment | null>(null);
  const [detailModalAction, setDetailModalAction] = useState<'analyze' | 'suggest' | null>(null);
  
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [contextMenuItem, setContextMenuItem] = useState<Exception | null>(null);

  useEffect(() => {
    setCurrentPageTitle('Exception Summary');
  }, [setCurrentPageTitle]);
  
  // When filters change, clear selection and drilldown
  useEffect(() => {
    setDrillDownException(null);
  }, [selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions, activeCategoryFilter]);

  const filteredExceptions = useMemo(() => {
    return exceptions.filter(ex =>
      (selectedBusinessAreas.length === 0 || selectedBusinessAreas.includes(ex.businessArea)) &&
      (selectedProductLineIds.length === 0 || selectedProductLineIds.includes(ex.productLineId)) &&
      (selectedRegions.length === 0 || selectedRegions.includes(ex.region)) &&
      (selectedStrategies.length === 0 || selectedStrategies.includes(ex.strategyId)) &&
      (activeCategoryFilter === 'ALL' || ex.category === activeCategoryFilter)
    ).sort((a,b) => Math.abs(b.financialImpact) - Math.abs(a.financialImpact));
  }, [exceptions, selectedBusinessAreas, selectedProductLineIds, selectedStrategies, selectedRegions, activeCategoryFilter]);
  
  const handleSaveAdjustment = useCallback((adj: Adjustment) => {
      saveAdjustment(adj);
      setIsAdjustmentModalOpen(false);
      setAdjustmentForModal(null);
  }, [saveAdjustment]);


  const analyzeRca = async (exception: Exception): Promise<RcaAnalysis> => {
      const fallbackAnalysis: RcaAnalysis = {
        likelyRootCause: "AI analysis could not be completed.",
        investigationSteps: ["Please review the exception details manually."],
        keyDataPoints: ["Financial Impact", "Position Details"],
      };

      if (!process.env.API_KEY) {
          console.error("API Key not configured. AI analysis unavailable.");
          return fallbackAnalysis;
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const schema = {
        type: Type.OBJECT,
        properties: {
            likelyRootCause: { type: Type.STRING, description: 'A brief, probable reason for the break.' },
            investigationSteps: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of actions to take.' },
            keyDataPoints: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of specific data to examine.' }
        },
        required: ["likelyRootCause", "investigationSteps", "keyDataPoints"]
      };

      const prompt = `
        As a financial operations analyst, provide a root cause analysis for the following financial exception.
        Be concise and suggest specific actions.
        Exception Details:
        - ID: ${exception.id}
        - Category: ${exception.category}
        - Description: ${exception.description}
        - Financial Impact: ${exception.financialImpact} ${exception.position.currency}
        - Position: CUSIP ${exception.position.cusip}, Account ${exception.position.tapsAccount}
        - Additional Data: ${JSON.stringify(exception.details)}
      `;

      try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema
            }
        });
        const jsonStr = response.text.trim();
        return JSON.parse(jsonStr) as RcaAnalysis;
      } catch (error) {
          console.error("RCA Analysis Error:", error);
          return fallbackAnalysis;
      }
  };

  const suggestAdjustment = async (exception: Exception): Promise<any> => {
      if (!process.env.API_KEY) return { justification: "API Key not configured." };
       const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
       const schema = {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING, enum: Object.values(AdjustmentType), description: "The type of adjustment." },
          amount: { type: Type.NUMBER, description: "The monetary value of the adjustment." },
          currency: { type: Type.STRING, description: "The currency of the adjustment amount." },
          debitAccount: { type: Type.STRING, description: "The account to be debited." },
          creditAccount: { type: Type.STRING, description: "The account to be credited." },
          justification: { type: Type.STRING, description: "The reason for the adjustment." },
        },
        required: ["type", "amount", "currency", "debitAccount", "creditAccount", "justification"]
      };

      const prompt = `
        Analyze the following financial exception and suggest a JSON object for a financial adjustment to resolve it.
        The adjustment amount should counteract the exception's financial impact (e.g., if impact is -100, adjustment is 100).
        Base the debit/credit accounts on the exception category. For a 'Treasury vs BU' difference, a PNL_CORRECTION is likely.
        For a 'New Activity Check' on a fee, it might be a FEE_POSTING.
        Exception Details:
        - ID: ${exception.id}
        - Category: ${exception.category}
        - Description: ${exception.description}
        - Financial Impact: ${exception.financialImpact} ${exception.position.currency}
        - Position: CUSIP ${exception.position.cusip}, Account ${exception.position.tapsAccount}
        - Additional Data: ${JSON.stringify(exception.details)}
      `;

      try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema
            }
        });
        
        let jsonStr = response.text.trim();
        // Basic cleanup in case the model wraps the JSON in markdown
        if (jsonStr.startsWith("```json")) {
            jsonStr = jsonStr.substring(7, jsonStr.length - 3).trim();
        }
        return JSON.parse(jsonStr);
      } catch (error) {
          console.error("Suggest Adjustment Error:", error);
          return { justification: "An error occurred while generating the suggestion." };
      }
  };


  const closeContextMenu = () => {
    setOpenMenuId(null);
    setContextMenuItem(null);
  };

  const handleContextMenuClick = useCallback((event: React.MouseEvent, exception: Exception) => {
    event.preventDefault();
    event.stopPropagation();
    setOpenMenuId(exception.id);
    setContextMenuItem(exception);
  }, []);

  const handleOpenDetailModal = (exception: Exception, action: 'analyze' | 'suggest' | null = null) => {
    setModalTargetException(exception);
    setDetailModalAction(action);
    setIsDetailModalOpen(true);
    closeContextMenu();
  };
  
  const handleOpenAdjustmentModal = (exception: Exception) => {
    setAdjustmentForModal({
        id: `ADJ-${Date.now()}`,
        relatedExceptionId: exception.id,
        type: AdjustmentType.PNL_CORRECTION,
        amount: 0,
        currency: exception.position.currency,
        debitAccount: '',
        creditAccount: '',
        justification: `Manual adjustment for exception ${exception.id}`,
        status: 'DRAFT',
        createdBy: 'Valerie User',
        createdAt: new Date().toISOString(),
        businessArea: exception.businessArea,
        productLineId: exception.productLineId,
        strategyId: exception.strategyId,
        region: exception.region,
      });
      setIsAdjustmentModalOpen(true);
      closeContextMenu();
  }

  const contextMenuItems: ContextMenuItemType[] = useMemo(() => {
    if (!contextMenuItem) return [];
    const ex = contextMenuItem;
    return [
      {
        label: 'View Drill Down',
        icon: EyeIcon,
        onClick: () => {
            setDrillDownException(ex);
            closeContextMenu();
        },
        disabled: drillDownException?.id === ex.id,
      },
      { isSeparator: true },
      {
        label: 'AI Root Cause Analysis',
        icon: CpuChipIcon,
        onClick: () => handleOpenDetailModal(ex, 'analyze'),
      },
      {
        label: 'AI Suggested Adjustment',
        icon: LightbulbIcon,
        onClick: () => handleOpenDetailModal(ex, 'suggest'),
      },
      { isSeparator: true },
      {
        label: 'Create Adjustment',
        icon: AdjustmentIcon,
        onClick: () => handleOpenAdjustmentModal(ex),
      },
    ];
  }, [contextMenuItem, drillDownException]);


  return (
    <div className="flex flex-col h-full">
        <div className="flex-grow p-6 space-y-6 overflow-y-auto">
            <DashboardCard title="Triage & Investigation Workbench">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                    <div className="flex-grow">
                        <p className="text-slate-600 mb-2 text-sm">
                            Filter exceptions by category. Click a row to see reconciliation details. Use the action menu (...) for more options.
                        </p>
                        <div className="flex space-x-2 border-b border-slate-200 pb-2 overflow-x-auto">
                            {CATEGORY_FILTERS.map(category => (
                                <button
                                    key={category}
                                    onClick={() => setActiveCategoryFilter(category)}
                                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${activeCategoryFilter === category ? 'bg-sky-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                                >
                                    {category}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </DashboardCard>

            <DashboardCard title={`Exceptions (${filteredExceptions.length})`}>
                <div className="overflow-x-auto rounded-lg border border-slate-200">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-100">
                            <tr>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600 uppercase tracking-wider">ID</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600 uppercase tracking-wider">Description</th>
                                <th className="px-3 py-2 text-right font-semibold text-slate-600 uppercase tracking-wider">Impact</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600 uppercase tracking-wider hidden md:table-cell">CUSIP</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600 uppercase tracking-wider hidden lg:table-cell">Date Identified</th>
                                <th className="px-3 py-2 text-center font-semibold text-slate-600 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-100">
                            {filteredExceptions.map(ex => (
                                <tr 
                                    key={ex.id}
                                    className={`hover:bg-sky-50 transition-colors cursor-pointer ${drillDownException?.id === ex.id ? 'bg-sky-100' : ''}`}
                                    onClick={() => setDrillDownException(ex)}
                                >
                                    <td className="px-3 py-2 whitespace-nowrap font-medium text-sky-700">{ex.id}</td>
                                    <td className="px-3 py-2 whitespace-normal max-w-sm">{ex.description}</td>
                                    <td className={`px-3 py-2 whitespace-nowrap text-right font-semibold ${ex.financialImpact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                        {formatCurrency(ex.financialImpact, ex.position.currency)}
                                    </td>
                                    <td className="px-3 py-2 whitespace-nowrap hidden md:table-cell">{ex.position.cusip}</td>
                                    <td className="px-3 py-2 whitespace-nowrap hidden lg:table-cell">{new Date(ex.dateIdentified).toLocaleDateString()}</td>
                                    <td className="px-3 py-2 text-center relative">
                                        <button onClick={(e) => handleContextMenuClick(e, ex)} className="p-1 rounded-full hover:bg-slate-200">
                                            <ListBulletIcon className="w-5 h-5 text-slate-500" />
                                        </button>
                                        {openMenuId === ex.id && contextMenuItem && (
                                            <ContextMenu isOpen={true} items={contextMenuItems} onClose={closeContextMenu} />
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {filteredExceptions.length === 0 && (
                        <p className="text-center text-slate-500 p-8">No exceptions found for the current filters.</p>
                    )}
                </div>
            </DashboardCard>
        </div>

      {drillDownException && (
        <div className="flex-shrink-0 border-t-2 border-slate-300 p-4 bg-slate-100 shadow-[0_-5px_15px_-5px_rgba(0,0,0,0.1)] animate-slideUp">
             <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold text-lg text-slate-800">Reconciliation Details: {drillDownException.id}</h3>
                <button 
                    onClick={() => setDrillDownException(null)}
                    className="p-1 rounded-full text-slate-500 hover:bg-slate-200"
                    aria-label="Close drill-down view"
                >
                    <CloseIcon className="w-5 h-5" />
                </button>
            </div>
            <DrillDownView exceptionId={drillDownException.id} />
        </div>
      )}

      {modalTargetException && (
        <ExceptionDetailModal
            isOpen={isDetailModalOpen}
            onClose={() => setIsDetailModalOpen(false)}
            exception={modalTargetException}
            onOpenAdjustmentModal={(ex, adj) => {
                setAdjustmentForModal(adj);
                setIsAdjustmentModalOpen(true);
            }}
            onAnalyzeRca={analyzeRca}
            onSuggestAdjustment={suggestAdjustment}
            onUpdateException={updateException}
            actionToTrigger={detailModalAction}
        />
      )}

      {isAdjustmentModalOpen && adjustmentForModal && (
        <AdjustmentModal
            isOpen={isAdjustmentModalOpen}
            onClose={() => setIsAdjustmentModalOpen(false)}
            onSave={handleSaveAdjustment}
            exception={exceptions.find(ex => ex.id === adjustmentForModal.relatedExceptionId)}
            existingAdjustment={adjustmentForModal}
            isAiGenerated={!!adjustmentForModal.suggestedJustification}
        />
      )}

       <style>{`
          @keyframes slideUp {
              from { transform: translateY(20px); opacity: 0; }
              to { transform: translateY(0); opacity: 1; }
          }
          .animate-slideUp { animation: slideUp 0.3s ease-out forwards; }
       `}</style>
    </div>
  );
};

export default ExceptionSummaryPage;
