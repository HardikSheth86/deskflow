

/**
 * This file contains mock data used throughout the application for development and demonstration purposes.
 * In a real-world scenario, this data would be fetched from APIs.
 */
import {
  BusinessArea, ProcessStage, KPI, ExceptionCategory, Exception, ExceptionStatus,
  Adjustment, ActivityLogItem,
  CommentaryType, CommentaryTemplate, Commentary,
  DistributionList, AdjustmentType, AdjustmentStatus,
  SignOffProductLine, SignOffStrategy, ProcessStatus,
  PreSignOffTask, PreSignOffTaskStatus, PreSignOffCheckType, PreSignOffDrillDown, PreSignOffAction,
  StackItem, ReleaseTrain, DeploymentStatus, InvestigativeTrade, TraderPnlSummary, FAQ,
  Case, CaseStatus, Region, ReconDrillDown, ReportCategory
} from './types';
import { AnalyticsIcon, CalculatorIcon, AdjustmentIcon, DocumentReportIcon } from './components/icons';
import { calculateProductLineAggregates, determineProductLineStatus } from './utils/helpers';

/**
 * An array of all available business areas in the application.
 * @type {BusinessArea[]}
 */
export const ALL_BUSINESS_AREAS: BusinessArea[] = [
  BusinessArea.TREASURY_CAPITAL_MARKETS,
];

/**
 * An array of all available regions in the application.
 * @type {Region[]}
 */
export const ALL_REGIONS: Region[] = [
  Region.NORTH_AMERICA,
  Region.EMEA,
  Region.NON_JAPAN_ASIA,
  Region.TOKYO,
];

/**
 * Mock data representing the stages of the daily financial validation process.
 * Used for the progress bar on the dashboard.
 * @type {ProcessStage[]}
 */
export const MOCK_PROCESS_STAGES: ProcessStage[] = [
  { id: 'data_loading', name: 'Data Loading', completedAt: '2024-07-28 08:00 AM', status: 'completed' },
  { id: 'initial_validation', name: 'Initial Validation', completedAt: '2024-07-28 09:30 AM', status: 'completed' },
  { id: 'exception_generation', name: 'Exception Generation', completedAt: '2024-07-28 10:15 AM', status: 'completed' },
  { id: 'ready_for_review', name: 'Ready for Review', completedAt: null, status: 'in-progress' },
  { id: 'final_sign_off', name: 'Final Sign-off', completedAt: null, status: 'pending' },
];

/**
 * Mock Key Performance Indicator (KPI) data, categorized by business area.
 * Used for the main summary cards on the dashboard.
 * @type {Record<BusinessArea, KPI[]>}
 */
export const MOCK_KPIS: Record<BusinessArea, KPI[]> = {
  [BusinessArea.TREASURY_CAPITAL_MARKETS]: [
    { label: 'Total Assets', value: '$3.2B', variance: '+$15M (0.47%)', varianceType: 'positive' },
    { label: 'Total Liabilities', value: '$2.8B', variance: '+$10M (0.36%)', varianceType: 'neutral' },
    { label: 'Net P&L', value: '$450K', variance: '+$12K (2.74%)', varianceType: 'positive' },
    { label: 'Gross P&L', value: '$600K', variance: '+$20K (3.45%)', varianceType: 'positive' },
  ],
};

/**
 * Mock data representing financial exceptions. This is a core dataset for the application.
 * Used on the Exception Summary page and for various dashboard widgets.
 * @type {Exception[]}
 */
export const MOCK_EXCEPTIONS: Exception[] = [
  {
    id: 'EXC-TCM-01', category: ExceptionCategory.TREASURY_VS_BU,
    position: { tapsAccount: 'TCM-SN-FID', cusip: 'SN95732VXY4', currency: 'USD', counterparty: 'Internal' },
    financialImpact: 15000.00,
    description: 'Treasury GL does not match BU ledger for Structured Note P&L.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-29', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    productLineId: 'PL_LTERM_DEBT', strategyId: 'SN_FID_NA', region: Region.NORTH_AMERICA,
    details: { 'Treasury P&L': 210000, 'BU P&L': 195000 },
    history: [{ timestamp: '2024-07-29 10:00', action: 'Created', user: 'System'}],
    aiRcaCommentary: "AI Analysis: Difference of $15,000 between Treasury and BU ledgers for SN_FID. This is likely a timing issue on an end-of-day trade booking or a manual adjustment posted to one ledger and not the other. Recommend verifying all T-0 trades and adjustments."
  },
  {
    id: 'EXC-TCM-02', category: ExceptionCategory.DOD_VARIANCE,
    position: { tapsAccount: 'TCM-SN-EQUITY', cusip: 'SN34567ABC1', currency: 'EUR', counterparty: 'Credit Suisse' },
    financialImpact: 50000.00,
    description: 'Day-over-Day P&L change exceeds threshold of 25K.', status: ExceptionStatus.IN_REVIEW, assignedTo: 'Valerie User',
    dateIdentified: '2024-07-29', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    productLineId: 'PL_LTERM_DEBT', strategyId: 'SN_EQUITY_EMEA', region: Region.EMEA,
    details: { 'DoD P&L Change': 50000, 'Threshold': 25000 },
    history: [{ timestamp: '2024-07-29 10:05', action: 'Created', user: 'System'}],
  },
    {
    id: 'EXC-TCM-04', category: ExceptionCategory.DOD_VARIANCE,
    position: { tapsAccount: 'TCM-SN-FID-ESG', cusip: 'SN11223ESG5', currency: 'JPY', counterparty: 'Nomura' },
    financialImpact: 1200000.00,
    description: 'DoD Balance Sheet variance on ESG note exceeds tolerance.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-29', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    productLineId: 'PL_LTERM_DEBT', strategyId: 'SN_ESG_TKO', region: Region.TOKYO,
    details: { 'DoD BS Change': '3.5%', 'Tolerance': '1.5%' },
    history: [{ timestamp: '2024-07-29 10:15', action: 'Created', user: 'System'}],
  },
];

const mockTcmActivityLog: ActivityLogItem[] = [
  { id: 'ACT-TCM-01', timestamp: '2024-07-29 09:15 AM', type: 'Trade', description: 'Issued 10M SN-FID-XYZ-001 @ 102.50', financialImpact: { amount: 10250000, currency: 'USD', liabilityEffect: 10250000 }, user: 'TraderTCM' },
  { id: 'ACT-TCM-02', timestamp: '2024-07-29 11:00 AM', type: 'Adjustment', description: 'Model calibration adjustment', financialImpact: { amount: 0, currency: 'USD', pnlEffect: 5200 }, user: 'QuantTeam' },
];

const STRATEGIES_TCM: SignOffStrategy[] = [
  // Strategy: STRUCTURED NOTES FID - present in NA and NJA
  { 
    id: 'SN_FID_NA', name: 'STRUCTURED NOTES FID', parentId: 'PL_LTERM_DEBT', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 11:00 AM', currency: 'USD', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.NORTH_AMERICA,
    previousNetPnL: 200000, currentNetPnL: 210000, pnlTrading: 15000, pnlFxReval: -2000, pnlAdjustments: -3000,
    previousTotalAssets: 1500000000, currentTotalAssets: 1510000000, assetChangeTrading: 8000000, assetChangeFxReval: 1000000, assetChangeAdjustments: 1000000,
    previousTotalLiabilities: 1300000000, currentTotalLiabilities: 1305000000, liabilityChangeTrading: 3000000, liabilityChangeFxReval: 1000000, liabilityChangeAdjustments: 1000000,
    activityLog: mockTcmActivityLog,
    commentary: "P&L driven by new issuance and favorable market conditions.",
    fxExposure: [ { currency: 'EUR', amount: 50000000 }, { currency: 'CAD', amount: 25000000 } ],
    entityDetails: [ { name: 'Legal Entity', value: 'Global Banking & Markets NA' }, { name: 'Booking Center', value: 'New York' } ]
  },
  { // This was SN_IED_ESG, now repurposed to be another instance of SN_FID
    id: 'SN_FID_NJA', name: 'STRUCTURED NOTES FID', parentId: 'PL_LTERM_DEBT', status: ProcessStatus.REJECTED, lastUpdated: '2024-07-29 11:05 AM', currency: 'USD', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.NON_JAPAN_ASIA,
    previousNetPnL: 10000, currentNetPnL: 8000, pnlTrading: -1500, pnlFxReval: -500, pnlAdjustments: 0,
    previousTotalAssets: 100000000, currentTotalAssets: 98000000, assetChangeTrading: -2000000, assetChangeFxReval: 0, assetChangeAdjustments: 0,
    previousTotalLiabilities: 80000000, currentTotalLiabilities: 79000000, liabilityChangeTrading: -1000000, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: [],
    fxExposure: [],
    entityDetails: [ { name: 'Legal Entity', value: 'Asia Pacific Trading Ltd.' }, { name: 'Booking Center', value: 'Singapore' } ]
  },

  // Strategy: STRUCTURED NOTES EQUITY - present in EMEA
  { 
    id: 'SN_EQUITY_EMEA', name: 'STRUCTURED NOTES EQUITY', parentId: 'PL_LTERM_DEBT', status: ProcessStatus.AWAITING_SIGN_OFF, lastUpdated: '2024-07-29 11:05 AM', currency: 'USD', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.EMEA,
    previousNetPnL: 50000, currentNetPnL: 55000, pnlTrading: 6000, pnlFxReval: -1000, pnlAdjustments: 0,
    previousTotalAssets: 500000000, currentTotalAssets: 510000000, assetChangeTrading: 10000000, assetChangeFxReval: 0, assetChangeAdjustments: 0,
    previousTotalLiabilities: 450000000, currentTotalLiabilities: 455000000, liabilityChangeTrading: 5000000, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: [],
    fxExposure: [ { currency: 'GBP', amount: 120000000 }, { currency: 'CHF', amount: 80000000 } ],
    entityDetails: [ { name: 'Legal Entity', value: 'EMEA Holdings PLC' }, { name: 'Booking Center', value: 'London' } ]
  },
  
  // Strategy: STRUCTURED NOTES ESG - present in TOKYO
  { // This was SN_FID_ESG
    id: 'SN_ESG_TKO', name: 'STRUCTURED NOTES ESG', parentId: 'PL_LTERM_DEBT', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 11:05 AM', currency: 'JPY', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.TOKYO,
    previousNetPnL: 2500000, currentNetPnL: 2800000, pnlTrading: 300000, pnlFxReval: 0, pnlAdjustments: 0,
    previousTotalAssets: 25000000000, currentTotalAssets: 25500000000, assetChangeTrading: 500000000, assetChangeFxReval: 0, assetChangeAdjustments: 0,
    previousTotalLiabilities: 20000000000, currentTotalLiabilities: 20200000000, liabilityChangeTrading: 200000000, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: [],
    commentary: "Awaiting final confirmation from Ops on one trade.",
    fxExposure: [],
    entityDetails: [ { name: 'Legal Entity', value: 'Japan Securities Co.' }, { name: 'Booking Center', value: 'Tokyo' } ]
  },

  // Strategy: L-TERM DEBT SN ALLOC - present in NA
  { // This was SN_ALLOC
    id: 'SN_ALLOC_NA', name: 'L-TERM DEBT SN ALLOC', parentId: 'PL_LTERM_DEBT', status: ProcessStatus.IN_PROGRESS, lastUpdated: '2024-07-29 11:05 AM', currency: 'USD', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.NORTH_AMERICA,
    previousNetPnL: 5000, currentNetPnL: 5000, pnlTrading: 0, pnlFxReval: 0, pnlAdjustments: 0,
    previousTotalAssets: 0, currentTotalAssets: 0, assetChangeTrading: 0, assetChangeFxReval: 0, assetChangeAdjustments: 0,
    previousTotalLiabilities: 0, currentTotalLiabilities: 0, liabilityChangeTrading: 0, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: [],
    fxExposure: [],
    entityDetails: []
  },
];


const aggregates = calculateProductLineAggregates(STRATEGIES_TCM);
const allRegionsForTCM = Array.from(new Set(STRATEGIES_TCM.map(s => s.region)));

const tcmProductLine: SignOffProductLine = {
    id: 'PL_LTERM_DEBT',
    name: 'Long-Term Debt - Structured Notes',
    businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    currency: 'USD',
    regions: allRegionsForTCM,
    strategies: STRATEGIES_TCM.map(s => ({...s, parentId: 'PL_LTERM_DEBT'})),
    status: determineProductLineStatus(STRATEGIES_TCM),
    lastUpdated: new Date().toISOString(),
    currentNetPnL: aggregates.currentNetPnL ?? 0,
    previousNetPnL: aggregates.previousNetPnL ?? 0,
    currentTotalAssets: aggregates.currentTotalAssets ?? 0,
    previousTotalAssets: aggregates.previousTotalAssets ?? 0,
    currentTotalLiabilities: aggregates.currentTotalLiabilities ?? 0,
    previousTotalLiabilities: aggregates.previousTotalLiabilities ?? 0,
};


/**
 * Mock data for sign-off product lines, categorized by business area.
 * This structure drives the Sign-Off page and includes nested strategies.
 * It's pre-aggregated using helper functions.
 * @type {Record<BusinessArea, SignOffProductLine[]>}
 */
export const MOCK_PRODUCT_LINES_BY_AREA: Record<BusinessArea, SignOffProductLine[]> = {
  [BusinessArea.TREASURY_CAPITAL_MARKETS]: [tcmProductLine],
};


/**
 * Mock data representing financial adjustments.
 * Used on the Adjustments page.
 * @type {Adjustment[]}
 */
export const MOCK_ADJUSTMENTS: Adjustment[] = [
    {
        id: 'ADJ-TCM-01',
        relatedExceptionId: 'EXC-TCM-01',
        type: AdjustmentType.PNL_CORRECTION,
        amount: -11000.00,
        currency: 'USD',
        debitAccount: 'TCM_PNL_ADJ',
        creditAccount: 'TCM_VALUATION_RESERVE',
        justification: 'Partial P&L correction for valuation break on SN-FID-XYZ-001.',
        status: 'SUBMITTED',
        createdBy: 'Valerie User',
        createdAt: '2024-07-29 15:00 PM',
        businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
        productLineId: 'PL_LTERM_DEBT', strategyId: 'SN_FID_NA', region: Region.NORTH_AMERICA,
    },
    {
        id: 'ADJ-TCM-02',
        type: AdjustmentType.FINANCING_PNL_FLATTENING,
        amount: 2500.00,
        currency: 'USD',
        debitAccount: 'FINANCING_COST',
        creditAccount: 'INTEREST_INCOME',
        justification: 'Auto-adjustment for financing P&L flattening.',
        status: 'SUBMITTED',
        createdBy: 'System',
        createdAt: new Date().toISOString(),
        businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
        productLineId: 'PL_LTERM_DEBT', strategyId: 'SN_ALLOC_NA', region: Region.NORTH_AMERICA,
    },
];

/**
 * Mock data for commentary templates.
 * Used on the Commentary page to allow users to create new commentaries from a predefined structure.
 * @type {CommentaryTemplate[]}
 */
export const MOCK_COMMENTARY_TEMPLATES: CommentaryTemplate[] = [
  {
    type: CommentaryType.MARKET,
    name: 'Market Event Impact',
    description: 'Explain P&L movements due to market events.',
    defaultSections: [
      { title: 'Market Overview', aiPlaceholder: 'e.g., Summary of key indices performance, volatility changes...' },
      { title: 'Impact on Portfolio', aiPlaceholder: 'e.g., Specific assets affected, P&L attribution to market factors...' },
      { title: 'Outlook & Actions', aiPlaceholder: 'e.g., Expected future impact, planned hedging strategies...' },
    ],
  },
  {
    type: CommentaryType.DAILY_TRADER_PACK,
    name: 'Daily Trader Pack',
    description: 'A summary pack for traders to review their daily activity.',
    defaultSections: [
      { title: 'T-0 P&L and Position Reconciliation', aiPlaceholder: 'e.g., Summary of key P&L movements, significant new positions, and any reconciliation breaks noted.' },
      { title: 'T-1 Adjustments and Events', aiPlaceholder: 'e.g., Details of any T-1 adjustments that impacted the book, corporate actions, or late trades.' },
      { title: 'Forward-looking Items & Watchlist', aiPlaceholder: 'e.g., Upcoming settlements, market events to watch, or positions nearing risk limits.' },
    ],
  },
];

/**
 * Mock data for existing commentary documents.
 * Used on the Commentary page.
 * @type {Commentary[]}
 */
export const MOCK_COMMENTARIES: Commentary[] = [
  {
    id: 'COM-TCM-01',
    type: CommentaryType.MARKET,
    title: 'Structured Notes Market Update - July 29',
    author: 'John Analyst',
    dateCreated: '2024-07-29T14:00:00Z',
    businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    productLineId: 'PL_LTERM_DEBT', strategyId: 'ALL', region: Region.NORTH_AMERICA,
    sections: [{ title: 'Market Overview', userContent: 'Volatility remains high in the credit markets, impacting pricing on new issuances.', aiSuggestion: 'AI could elaborate on specific credit indices.' }],
    tags: ['structured notes', 'tcm', 'volatility'],
  },
];

/**
 * Mock data for distribution lists for sending reports.
 * Used in the Send Report modal on the Analytics page.
 * @type {DistributionList[]}
 */
export const MOCK_DISTRIBUTION_LISTS: DistributionList[] = [
  { id: 'dl_seniormgmt', name: 'Senior Management', description: 'C-suite and Head of Departments' },
  { id: 'dl_tcmdesk', name: 'TCM Desk', description: 'All traders and analysts on the TCM team' },
  { id: 'dl_compliance', name: 'Compliance Team', description: 'Global compliance officers' },
  { id: 'dl_risk', name: 'Risk Management', description: 'Market Risk and Operational Risk teams' },
  { id: 'dl_financecontrollers', name: 'Finance Controllers', description: 'Product control and financial reporting teams' },
];

/**
 * Mock data for pre-sign-off automated tasks, categorized by business area.
 * Used on the Pre-Sign Off page.
 * @type {Record<BusinessArea, PreSignOffTask[]>}
 */
export const MOCK_PRE_SIGN_OFF_TASKS_BY_AREA: Record<BusinessArea, PreSignOffTask[]> = {
  [BusinessArea.TREASURY_CAPITAL_MARKETS]: [
    {
      id: 'PSOT-01',
      checkType: PreSignOffCheckType.T0_T1,
      title: 'T0-T1 P&L Estimate vs Actuals',
      description: 'Compares the trader estimate P&L at T0 with the final actual P&L calculated at T1.',
      status: PreSignOffTaskStatus.COMPLETED_BREAKS,
      businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
      lastRun: '2024-07-30 08:00 AM',
      breakCount: 1,
      responsibleTeam: 'Product Control',
      productLineId: 'PL_LTERM_DEBT',
      strategyId: 'SN_FID',
      region: Region.NORTH_AMERICA,
      breakDetails: [{ id: 'BRK_T0T1_01', description: 'Variance of $12.5K exceeds tolerance for SN_FID.', severity: 'High' }],
    },
    {
      id: 'PSOT-02',
      checkType: PreSignOffCheckType.VRS,
      title: 'VRS vs Finance Ledger Position Check',
      description: 'Reconciles position quantities between the Value-at-Risk system (VRS) and the official Finance Sub-Ledger to catch late or mis-booked trades.',
      status: PreSignOffTaskStatus.COMPLETED_BREAKS,
      businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
      lastRun: '2024-07-30 08:15 AM',
      breakCount: 2,
      responsibleTeam: 'Ops',
      productLineId: 'PL_LTERM_DEBT',
      strategyId: 'SN_EQUITY',
      region: Region.EMEA,
      breakDetails: [
        { id: 'BRK_VRS_01', description: 'Position mismatch for SN34567ABC1.', severity: 'Medium' },
        { id: 'BRK_VRS_02', description: 'Late trade T-EMEA-9987 missing from ledger.', severity: 'High' },
      ],
    },
    {
      id: 'PSOT-03',
      checkType: PreSignOffCheckType.CANCEL_CORRECT,
      title: 'Trader Cancel/Correct Behavior Check',
      description: 'Monitors frequency and timing of trade cancellations and corrections to identify potential behavioral patterns.',
      status: PreSignOffTaskStatus.COMPLETED_OK,
      businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
      lastRun: '2024-07-30 08:30 AM',
      breakCount: 0,
      responsibleTeam: 'Compliance',
      productLineId: 'ALL',
      strategyId: 'ALL',
      region: Region.NORTH_AMERICA,
    },
    {
      id: 'PSOT-04',
      checkType: PreSignOffCheckType.EVE,
      title: 'EVE vs Finance Ledger Settlement Check',
      description: 'Compares settled cash and positions in the EVE Operations ledger against the Finance ledger to find settlement discrepancies.',
      status: PreSignOffTaskStatus.REQUIRES_ATTENTION,
      businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
      lastRun: '2024-07-30 08:45 AM',
      breakCount: 1,
      responsibleTeam: 'Settlements',
      productLineId: 'PL_LTERM_DEBT',
      strategyId: 'SN_FID_ESG',
      region: Region.TOKYO,
      breakDetails: [{ id: 'BRK_EVE_01', description: 'JPY settlement failed for trade T-TKO-1234.', severity: 'High' }],
    },
  ],
};

/**
 * Mock data for manual actions available on the Pre-Sign Off page, categorized by business area.
 * @type {Record<BusinessArea, PreSignOffAction[]>}
 */
export const MOCK_PRE_SIGN_OFF_ACTIONS_BY_AREA: Record<BusinessArea, PreSignOffAction[]> = {
    [BusinessArea.TREASURY_CAPITAL_MARKETS]: [
       {
            id: 'tcm_finance_flatten',
            title: 'Finance Flattening',
            description: 'Create an adjustment to flatten financing P&L for structured notes based on funding costs.',
            icon: CalculatorIcon,
            businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
            adjustmentType: AdjustmentType.FINANCING_PNL_FLATTENING,
        },
        {
            id: 'tcm_attr_correction',
            title: 'Attribution Correction',
            description: 'Create an adjustment to correct the attribution of P&L between different strategies.',
            icon: AdjustmentIcon,
            businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
            adjustmentType: AdjustmentType.ATTRIBUTION_ADJUSTMENT,
        },
    ],
};

/**
 * Mock data for software release trains.
 * Used on the Documentation page to show deployment status.
 * @type {ReleaseTrain[]}
 */
export const MOCK_RELEASE_TRAINS: ReleaseTrain[] = [
    {
        id: 'train_24_w31', name: 'Feature Train - Week 31', version: '2.3.0', status: 'Active',
        stages: [
            { name: 'Build', status: DeploymentStatus.SUCCESS, completedAt: '2024-07-30 10:00 AM' },
            { name: 'Unit Tests', status: DeploymentStatus.SUCCESS, completedAt: '2024-07-30 10:05 AM' },
            { name: 'Integration Tests', status: DeploymentStatus.IN_PROGRESS, startedAt: '2024-07-30 10:05 AM' },
            { name: 'Deploy to Staging', status: DeploymentStatus.PENDING },
            { name: 'UAT', status: DeploymentStatus.PENDING },
            { name: 'Deploy to Production', status: DeploymentStatus.PENDING },
        ]
    },
];

/**
 * Mock data for the P&L summary on the Trader Review page.
 * @type {TraderPnlSummary}
 */
export const MOCK_TRADER_PNL_SUMMARY: TraderPnlSummary = {
  dod: 12000,
  mtd: 450000,
  ytd: 3200000,
  currency: 'USD',
};

/**
 * Mock data for Frequently Asked Questions.
 * Used in the Help Widget.
 * @type {FAQ[]}
 */
export const MOCK_FAQS: FAQ[] = [
  { id: 'faq-1', question: 'How do I create an adjustment for an exception?', answer: "From the Exception Summary page, right-click on an exception and select 'Create Adjustment'. This will open the adjustment modal with the exception details pre-filled.", keywords: ['adjustment', 'exception', 'create'] },
  { id: 'faq-2', question: 'Where can I find the sign-off screen?', answer: "The sign-off workflow is located on the 'Sign-Off' page, accessible from the top navigation bar.", keywords: ['sign-off', 'attestation', 'approve'] },
];


/**
 * Mock data representing cases for the Case Management page.
 * Cases are formal follow-ups on exceptions.
 * @type {Case[]}
 */
export const MOCK_CASES: Case[] = [
  {
    id: 'CASE-TCM-01', title: 'Valuation discrepancy on SN (EXC-TCM-01)', exceptionId: 'EXC-TCM-01',
    assignedTo: 'Charles Controller', status: CaseStatus.OPEN, dateOpened: '2024-07-29T10:30:00Z',
    region: Region.NORTH_AMERICA,
    comments: [
      { user: 'System', timestamp: '2024-07-29T10:30:00Z', comment: 'Case automatically opened for new high-value VRS break in Treasury Capital Markets.' },
    ]
  },
];

/**
 * Mock data for the detailed reconciliation drill-down view for exceptions.
 * @type {Record<string, ReconDrillDown>}
 */
export const MOCK_RECON_DRILLDOWN_DATA: Record<string, ReconDrillDown> = {
  'EXC-TCM-01': {
    exceptionId: 'EXC-TCM-01',
    sourceDetails: [
      {
        sourceSystem: 'Treasury GL',
        positionId: 'TCM-SN-FID-PNL-USD',
        values: { 'P&L': 210000, 'MV': 1510000000, 'Accrued Interest': 50000 },
        lastUpdated: '2024-07-29 09:55 AM',
      },
      {
        sourceSystem: 'BU Ledger',
        positionId: 'BU-SNFID-PNL-USD',
        values: { 'P&L': 195000, 'MV': 1510000000, 'Accrued Interest': 50000 },
        lastUpdated: '2024-07-29 09:56 AM',
      },
      {
        sourceSystem: 'Risk System',
        positionId: 'RISK-SNFID-95732VXY4',
        values: { 'P&L': 210500, 'MV': 1510050000, 'Accrued Interest': 50000 },
        lastUpdated: '2024-07-29 09:50 AM',
      }
    ]
  }
};

/**
 * Mock data for the detailed drill-down view for pre-sign-off checks.
 * @type {Record<string, PreSignOffDrillDown>}
 */
export const MOCK_PRE_SIGN_OFF_DRILLDOWN_DATA: Record<string, PreSignOffDrillDown> = {
  'PSOT-01': {
    taskId: 'PSOT-01',
    details: {
      type: PreSignOffCheckType.T0_T1,
      data: [
        { metric: 'Trading P&L', t0Value: 10000, t1Value: 15000, variance: 5000, currency: 'USD' },
        { metric: 'FX P&L', t0Value: -2000, t1Value: -2000, variance: 0, currency: 'USD' },
        { metric: 'Fees', t0Value: -3000, t1Value: -10500, variance: -7500, currency: 'USD' },
      ],
    },
  },
  'PSOT-02': {
    taskId: 'PSOT-02',
    details: {
      type: PreSignOffCheckType.VRS,
      data: [
        { positionId: 'POS-EUR-1', cusip: 'SN34567ABC1', riskSystemValue: 10000, financeLedgerValue: 10000, difference: 0, currency: 'EUR' },
        { positionId: 'POS-EUR-2', cusip: 'SN34567ABC2', riskSystemValue: 5000, financeLedgerValue: 0, difference: 5000, currency: 'EUR' },
        { positionId: 'POS-EUR-3', cusip: 'SN34567ABC3', riskSystemValue: 20000, financeLedgerValue: 20000, difference: 0, currency: 'EUR' },
      ],
    },
  },
  'PSOT-04': {
    taskId: 'PSOT-04',
    details: {
      type: PreSignOffCheckType.EVE,
      data: [
        { positionId: 'SET-JPY-1', opsLedgerValue: 5000000, financeLedgerValue: 5000000, difference: 0, currency: 'JPY' },
        { positionId: 'SET-JPY-2', opsLedgerValue: 10000000, financeLedgerValue: 0, difference: 10000000, currency: 'JPY' },
      ],
    },
  },
};


/**
 * Mock data for the application's technology stack.
 * Used on the Documentation page.
 * @type {StackItem[]}
 */
export const MOCK_STACK_ITEMS: StackItem[] = [
    { name: 'React 18', category: 'Frontend', description: 'Core UI library for building the user interface components.' },
    { name: 'TypeScript', category: 'Frontend', description: 'Provides static typing for more robust and maintainable code.' },
    { name: 'Tailwind CSS', category: 'Frontend', description: 'A utility-first CSS framework for rapid UI development.' },
    { name: 'Recharts', category: 'Frontend', description: 'A composable charting library built on React components.' },
    { name: 'Google Gemini API', category: 'API', description: 'Used for AI-powered features like RCA suggestions and commentary assistance.' },
    { name: 'Vite', category: 'Tooling', description: 'Next-generation frontend tooling for a faster development experience.' },
    { name: 'ESM.sh', category: 'Tooling', description: 'A fast, global content delivery network for ES modules.' },
    { name: 'Internal Cloud', category: 'Platform', description: 'Proprietary cloud platform for application hosting and services.' },
];

/**
 * Mock data for comprehensive trade objects.
 * Used on the Investigation Workbench page.
 * @type {InvestigativeTrade[]}
 */
export const MOCK_INVESTIGATIVE_TRADES: InvestigativeTrade[] = [
  {
    id: 'T-TCM-55555', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS, product: 'SN-FID-XYZ-001', quantity: 11000000, price: 102.50, currency: 'USD', counterparty: 'JP Morgan',
    status: 'Booked', tradeDate: '2024-07-29', productLineId: 'PL_LTERM_DEBT', strategyId: 'SN_FID', region: Region.NORTH_AMERICA,
    preTrade: { approvalId: 'PTA-125', limitCheckStatus: 'Approved', timestamp: '2024-07-29 11:00:00 EST', checkedBy: 'AutoLimitSys' },
    tradeCapture: { bookingSystem: 'TradeMaster', tradeTime: '2024-07-29 11:01:10 EST', traderId: 'TraderTCM', salesperson: 'SalesTCM' },
    risk: { delta: 35000, gamma: 120, vega: 8000, theta: -400, var99: 95000 },
    ops: { confirmationStatus: 'Confirmed', settlementStatus: 'Unsettled', settlementDate: '2024-08-05' },
    ledger: { journalId: 'JRN-54323', debitAccount: 'ASSET_SN_XYZ', creditAccount: 'CASH_CLEARING', amount: 11275000, currency: 'USD', postingDate: '2024-07-29' }
  },
];

export const MOCK_REPORTS_DATA: ReportCategory[] = [
    {
        categoryId: 'traders_reports',
        categoryTitle: 'For Traders & Desks',
        reports: [
            { id: 'tr_daily_pnl', title: 'Daily T1 P&L and BS Summary', description: 'Detailed P&L and Balance Sheet summary for your desk.', icon: DocumentReportIcon, defaultFormat: 'Excel', frequency: 'Daily', powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=c5c8e4d7-1b0f-4e1e-9a9c-2f9d1e4a3b7c&autoAuth=true&ctid=common' },
            { id: 'tr_t0t1', title: 'T-0 vs T-1 Break Report', description: 'Highlights differences between estimated and final P&L.', icon: DocumentReportIcon, defaultFormat: 'CSV', frequency: 'Daily' },
            { id: 'tr_cancel_correct', title: 'Cancel/Correct Activity Report', description: 'Monitors high-volume cancel and correct activity.', icon: DocumentReportIcon, defaultFormat: 'CSV', frequency: 'Daily' },
            { id: 'tr_weekly_vol', title: 'Weekly Volatility Analysis', description: 'Analysis of portfolio volatility over the past week.', icon: AnalyticsIcon, defaultFormat: 'PDF', frequency: 'Weekly' },
        ]
    },
    {
        categoryId: 'mgmt_reports',
        categoryTitle: 'For Management',
        reports: [
            { id: 'mgmt_pnl_summary', title: 'Daily P&L Summary by Desk', description: 'Aggregated P&L performance for all desks.', icon: DocumentReportIcon, defaultFormat: 'PDF', frequency: 'Daily', powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=c5c8e4d7-1b0f-4e1e-9a9c-2f9d1e4a3b7c&autoAuth=true&ctid=common' },
            { id: 'mgmt_mcr', title: 'Management Control Report (MCR)', description: 'Monthly summary of key controls, exceptions, and sign-off status.', icon: AnalyticsIcon, defaultFormat: 'PDF', frequency: 'Monthly' },
            { id: 'mgmt_exception_trends', title: 'Exception Trend Analysis', description: 'Monthly report on exception volumes, aging, and root causes.', icon: AnalyticsIcon, defaultFormat: 'Excel', frequency: 'Monthly' },
            { id: 'mgmt_quarterly_review', title: 'Quarterly Business Review Pack', description: 'Comprehensive performance and risk package for senior management.', icon: AnalyticsIcon, defaultFormat: 'PDF', frequency: 'Quarterly' },
        ]
    },
    {
        categoryId: 'reg_reports',
        categoryTitle: 'Regulatory & Disclosures',
        reports: [
            { id: 'reg_volcker', title: 'Volcker Rule Metrics', description: 'Daily metrics required for Volcker Rule compliance.', icon: DocumentReportIcon, defaultFormat: 'CSV', frequency: 'Daily' },
            { id: 'reg_basel_risk', title: 'Basel III Risk Exposure', description: 'Monthly risk-weighted asset calculations for regulatory reporting.', icon: DocumentReportIcon, defaultFormat: 'Excel', frequency: 'Monthly' },
            { id: 'reg_disclosures', title: 'Quarterly Disclosures Report', description: 'Draft report for public financial disclosures (e.g., 10-Q/10-K).', icon: DocumentReportIcon, defaultFormat: 'PDF', frequency: 'Quarterly' },
        ]
    }
];
