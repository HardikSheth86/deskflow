import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { MOCK_INVESTIGATIVE_TRADES } from '../constants';
import { InvestigativeTrade, PreTradeApprovalDetails, TradeCaptureDetails, RiskDetails, OpsDetails, LedgerDetails } from '../types';
import DashboardCard from '../components/DashboardCard';
import Tabs, { TabItem } from '../components/Tabs';
import { 
    FilterIcon, CloseIcon, ShieldCheckIcon, 
    ArchiveBoxIcon, BeakerIcon, BriefcaseIcon, ReceiptPercentIcon 
} from '../components/icons';
import StatusPill from '../components/StatusPill'; // Using the new reusable component

const DetailListItem: React.FC<{ label: string; value: React.ReactNode; }> = ({ label, value }) => (
    <div className="flex justify-between items-center py-1.5 px-2 border-b border-slate-100">
        <span className="font-medium text-slate-600">{label}:</span>
        <div className="text-slate-800 text-right">{value}</div>
    </div>
);

const PreTradeView: React.FC<{ data: PreTradeApprovalDetails }> = ({ data }) => (
    <div className="space-y-1">
        <DetailListItem label="Approval ID" value={data.approvalId} />
        <DetailListItem label="Limit Check Status" value={<StatusPill status={data.limitCheckStatus} />} />
        <DetailListItem label="Timestamp" value={data.timestamp} />
        <DetailListItem label="Checked By" value={data.checkedBy} />
    </div>
);

const TradeCaptureView: React.FC<{ data: TradeCaptureDetails }> = ({ data }) => (
    <div className="space-y-1">
        <DetailListItem label="Booking System" value={data.bookingSystem} />
        <DetailListItem label="Trade Time" value={data.tradeTime} />
        <DetailListItem label="Trader ID" value={data.traderId} />
        <DetailListItem label="Salesperson" value={data.salesperson} />
    </div>
);

const RiskView: React.FC<{ data: RiskDetails }> = ({ data }) => (
     <div className="space-y-1">
        <DetailListItem label="Delta" value={data.delta.toLocaleString()} />
        <DetailListItem label="Gamma" value={data.gamma.toLocaleString()} />
        <DetailListItem label="Vega" value={data.vega.toLocaleString()} />
        <DetailListItem label="Theta" value={data.theta.toLocaleString()} />
        <DetailListItem label="99% VaR" value={data.var99.toLocaleString('en-US', { style: 'currency', currency: 'USD' })} />
    </div>
);

const OpsView: React.FC<{ data: OpsDetails }> = ({ data }) => (
    <div className="space-y-1">
        <DetailListItem label="Confirmation Status" value={<StatusPill status={data.confirmationStatus} />} />
        <DetailListItem label="Settlement Status" value={<StatusPill status={data.settlementStatus} />} />
        <DetailListItem label="Settlement Date" value={data.settlementDate} />
    </div>
);

const LedgerView: React.FC<{ data: LedgerDetails }> = ({ data }) => (
     <div className="space-y-1">
        <DetailListItem label="Journal ID" value={data.journalId} />
        <DetailListItem label="Debit Account" value={data.debitAccount} />
        <DetailListItem label="Credit Account" value={data.creditAccount} />
        <DetailListItem label="Amount" value={data.amount.toLocaleString('en-US', { style: 'currency', currency: data.currency })} />
        <DetailListItem label="Posting Date" value={data.postingDate} />
    </div>
);

const TradeDetailView: React.FC<{ trade: InvestigativeTrade }> = ({ trade }) => {
    const tabs: TabItem[] = [
        { label: "Pre-Trade", content: <PreTradeView data={trade.preTrade} />, icon: ShieldCheckIcon },
        { label: "Trade Capture", content: <TradeCaptureView data={trade.tradeCapture} />, icon: ArchiveBoxIcon },
        { label: "Risk", content: <RiskView data={trade.risk} />, icon: BeakerIcon },
        { label: "Ops", content: <OpsView data={trade.ops} />, icon: BriefcaseIcon },
        { label: "Ledger", content: <LedgerView data={trade.ledger} />, icon: ReceiptPercentIcon },
    ];
    return <Tabs tabs={tabs} />;
}

const InvestigationPage: React.FC = () => {
    const { setCurrentPageTitle, currentBusinessArea } = useAppContext();
    const [trades] = useState<InvestigativeTrade[]>(MOCK_INVESTIGATIVE_TRADES);
    const [selectedTrade, setSelectedTrade] = useState<InvestigativeTrade | null>(null);

    // Filters
    const [filterTradeId, setFilterTradeId] = useState('');
    const [filterProduct, setFilterProduct] = useState('');
    const [filterStatus, setFilterStatus] = useState<'ALL' | 'Booked' | 'Amended' | 'Cancelled'>('ALL');

    useEffect(() => {
        setCurrentPageTitle('Investigation Workbench');
    }, [setCurrentPageTitle]);

    const filteredTrades = useMemo(() => {
        return trades.filter(trade => 
            trade.businessArea === currentBusinessArea &&
            (filterTradeId ? trade.id.toLowerCase().includes(filterTradeId.toLowerCase()) : true) &&
            (filterProduct ? trade.product.toLowerCase().includes(filterProduct.toLowerCase()) : true) &&
            (filterStatus === 'ALL' || trade.status === filterStatus)
        );
    }, [trades, currentBusinessArea, filterTradeId, filterProduct, filterStatus]);
    
    useEffect(() => {
        setSelectedTrade(null);
    }, [filterTradeId, filterProduct, filterStatus, currentBusinessArea]);

    const handleSelectTrade = (trade: InvestigativeTrade) => {
        setSelectedTrade(trade.id === selectedTrade?.id ? null : trade);
    };

    return (
        <div className="space-y-6">
            <DashboardCard title="Trade Investigation Workbench">
                <p className="text-slate-600 mb-4">
                    Filter and select trades to view a comprehensive breakdown of their lifecycle data across multiple systems.
                </p>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col md:flex-row items-center space-y-3 md:space-y-0 md:space-x-4">
                    <div className="flex items-center text-slate-700">
                        <FilterIcon className="w-5 h-5 mr-2" />
                        <span className="font-semibold">Filters:</span>
                    </div>
                    <div className="flex-grow w-full md:w-auto">
                        <input
                            type="text"
                            placeholder="Filter by Trade ID..."
                            value={filterTradeId}
                            onChange={(e) => setFilterTradeId(e.target.value)}
                            className="w-full p-2 border border-slate-300 rounded-md text-sm"
                        />
                    </div>
                     <div className="flex-grow w-full md:w-auto">
                        <input
                            type="text"
                            placeholder="Filter by Product..."
                            value={filterProduct}
                            onChange={(e) => setFilterProduct(e.target.value)}
                            className="w-full p-2 border border-slate-300 rounded-md text-sm"
                        />
                    </div>
                     <div className="flex-grow w-full md:w-auto">
                        <select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value as any)}
                            className="w-full p-2 border border-slate-300 rounded-md text-sm bg-white"
                        >
                            <option value="ALL">All Statuses</option>
                            <option value="Booked">Booked</option>
                            <option value="Amended">Amended</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
            </DashboardCard>

            <DashboardCard title={`Trades for ${currentBusinessArea} (${filteredTrades.length})`}>
                <div className="overflow-x-auto rounded-lg border border-slate-200 max-h-[50vh]">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-100 sticky top-0">
                            <tr>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600">Trade ID</th>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600">Product</th>
                                <th className="px-4 py-3 text-right font-semibold text-slate-600">Quantity</th>
                                <th className="px-4 py-3 text-right font-semibold text-slate-600">Price</th>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600">Status</th>
                                <th className="px-4 py-3 text-left font-semibold text-slate-600 hidden md:table-cell">Trade Date</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-100">
                            {filteredTrades.map(trade => (
                                <tr 
                                    key={trade.id} 
                                    onClick={() => handleSelectTrade(trade)}
                                    className={`cursor-pointer hover:bg-sky-100 ${selectedTrade?.id === trade.id ? 'bg-sky-100 ring-2 ring-sky-500' : ''}`}
                                >
                                    <td className="px-4 py-3 whitespace-nowrap font-medium text-sky-700">{trade.id}</td>
                                    <td className="px-4 py-3 whitespace-nowrap">{trade.product}</td>
                                    <td className="px-4 py-3 whitespace-nowrap text-right">{trade.quantity.toLocaleString()}</td>
                                    <td className="px-4 py-3 whitespace-nowrap text-right">{trade.price.toLocaleString('en-US', { style: 'currency', currency: trade.currency })}</td>
                                    <td className="px-4 py-3 whitespace-nowrap">
                                        <StatusPill status={trade.status} />
                                    </td>
                                    <td className="px-4 py-3 whitespace-nowrap hidden md:table-cell">{trade.tradeDate}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {filteredTrades.length === 0 && (
                        <div className="text-center p-8 text-slate-500">No trades match the current filters for this business area.</div>
                    )}
                </div>
            </DashboardCard>

            {selectedTrade && (
                 <DashboardCard 
                    title={`Details for Trade: ${selectedTrade.id}`} 
                    actions={<button onClick={() => setSelectedTrade(null)} className="p-1 rounded-full hover:bg-slate-200"><CloseIcon className="w-5 h-5 text-slate-600"/></button>}
                >
                    <TradeDetailView trade={selectedTrade} />
                 </DashboardCard>
            )}
        </div>
    );
};

export default InvestigationPage;