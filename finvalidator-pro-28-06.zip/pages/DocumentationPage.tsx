import React, { useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { BookOpenIcon, BranchIcon, CpuChipIcon, ListBulletIcon } from '../components/icons';

const CodeBlock: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <pre className="bg-slate-800 text-slate-200 p-3 rounded-md text-xs overflow-x-auto">
        <code>{children}</code>
    </pre>
);

const DocumentationPage: React.FC = () => {
    const { setCurrentPageTitle } = useAppContext();

    useEffect(() => {
        setCurrentPageTitle('Application Documentation');
    }, [setCurrentPageTitle]);

    return (
        <div className="space-y-6">
            <DashboardCard title={<div className="flex items-center"><BookOpenIcon className="w-6 h-6 mr-2" /> FinValidator Pro - Architecture & Documentation</div>}>
                <p className="text-slate-600">
                    This document provides an overview of the application's architecture, state management, and coding standards.
                    It is intended to help developers understand the codebase and contribute effectively.
                </p>
            </DashboardCard>

            <DashboardCard title={<div className="flex items-center"><BranchIcon className="w-5 h-5 mr-2" /> Project Structure</div>}>
                <p className="text-slate-600 mb-4">The project follows a standard feature-based directory structure:</p>
                <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
                    <li><strong className="font-semibold">/components</strong>: Contains reusable React components used across multiple pages (e.g., `DashboardCard`, `Modal`, `StatusPill`).</li>
                    <li><strong className="font-semibold">/contexts</strong>: Holds React Context providers for global state management (e.g., `AppContext.tsx`).</li>
                    <li><strong className="font-semibold">/hooks</strong>: Custom React hooks that encapsulate reusable logic (e.g., `useAppContext.tsx`).</li>
                    <li><strong className="font-semibold">/pages</strong>: Top-level components that correspond to application routes (e.g., `DashboardPage.tsx`, `ExceptionSummaryPage.tsx`).</li>
                    <li><strong className="font-semibold">/types.ts</strong>: Contains all TypeScript type definitions and enums for the application.</li>
                    <li><strong className="font-semibold">/utils</strong>: Utility functions that are not React components (e.g., `helpers.ts` for formatting).</li>
                    <li><strong className="font-semibold">/index.tsx</strong>: The main entry point of the application.</li>
                </ul>
            </DashboardCard>
            
            <DashboardCard title={<div className="flex items-center"><CpuChipIcon className="w-5 h-5 mr-2" /> State Management (`AppContext`)</div>}>
                 <p className="text-slate-600 mb-4">
                    The application uses a centralized state management approach with React Context to ensure a single source of truth and predictable data flow.
                </p>
                 <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
                    <li><strong>Provider:</strong> The `AppProvider` in `contexts/AppContext.tsx` initializes all the application's data (exceptions, adjustments, etc.) from mock constants and holds them in its state.</li>
                    <li><strong>Consumption:</strong> Components access the global state and updater functions using the `useAppContext()` custom hook. This avoids prop-drilling.</li>
                    <li><strong>Immutability:</strong> All state updates are immutable. Updater functions in the context (e.g., `updateException`, `saveAdjustment`) receive new data, create copies of the state, and then use `setState` to trigger re-renders. We never mutate the original state arrays or objects directly.</li>
                 </ul>
                 <p className="text-slate-600 mt-4 mb-2">Example of updating an exception from a component:</p>
                 <CodeBlock>
{`const { exceptions, updateException } = useAppContext();

const handleResolveException = (id: string) => {
  const exceptionToResolve = exceptions.find(ex => ex.id === id);
  if (exceptionToResolve) {
    const updatedException = { ...exceptionToResolve, status: 'Resolved' };
    updateException(updatedException); // Call the updater from the context
  }
};`}
                </CodeBlock>
            </DashboardCard>

            <DashboardCard title={<div className="flex items-center"><ListBulletIcon className="w-5 h-5 mr-2" /> Documentation Standard (TSDoc)</div>}>
                <p className="text-slate-600 mb-4">
                    The codebase uses TSDoc comments for documenting functions, types, and components. This helps with maintainability and provides inline documentation in modern IDEs.
                </p>
                <p className="text-slate-600 mb-2">Key TSDoc tags used:</p>
                 <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
                    <li><strong className="font-semibold">@param</strong>: Describes a function parameter.</li>
                    <li><strong className="font-semibold">@returns</strong>: Describes the return value of a function.</li>
                    <li><strong className="font-semibold">@interface</strong>: Describes a TypeScript interface.</li>
                    <li><strong className="font-semibold">@property</strong>: Describes a property within an interface.</li>
                    <li><strong className="font-semibold">@type</strong>: Specifies the type of a variable or constant.</li>
                 </ul>
                 <p className="text-slate-600 mt-4 mb-2">Example of a documented utility function:</p>
                 <CodeBlock>
{`/**
 * Formats a number into a currency string.
 * @param {number} value - The numeric value to format.
 * @param {string} currency - The currency code (e.g., 'USD').
 * @returns {string} A formatted currency string.
 */
export const formatCurrency = (value: number, currency: string): string => {
  // ... implementation
};`}
                 </CodeBlock>
            </DashboardCard>
        </div>
    );
};

export default DocumentationPage;