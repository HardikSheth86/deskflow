import React, { useEffect, useState, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { Adjustment } from '../types';
import AdjustmentModal from '../components/AdjustmentModal';
import { PencilIcon, PlusCircleIcon } from '../components/icons';
import StatusPill from '../components/StatusPill';

const AdjustmentsPage: React.FC = () => {
  const { currentBusinessArea, setCurrentPageTitle, adjustments, saveAdjustment } = useAppContext();
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
  const [editingAdjustment, setEditingAdjustment] = useState<Adjustment | null>(null);

  useEffect(() => {
    setCurrentPageTitle('Adjustments Management');
  }, [setCurrentPageTitle]);

  const handleOpenNewAdjustmentModal = () => {
    setEditingAdjustment(null);
    setIsAdjustmentModalOpen(true);
  };
  
  const handleOpenEditAdjustmentModal = (adjustment: Adjustment) => {
    setEditingAdjustment(adjustment);
    setIsAdjustmentModalOpen(true);
  };

  const handleSaveAndClose = useCallback((savedAdj: Adjustment) => {
    saveAdjustment(savedAdj); // Use context action to save
    setIsAdjustmentModalOpen(false);
    setEditingAdjustment(null);
    alert(`Adjustment ${savedAdj.id} has been saved with status: ${savedAdj.status}`);
  }, [saveAdjustment]);

  return (
    <div className="space-y-6">
      <DashboardCard title="Adjustment Workflow & Control">
        <div className="flex justify-between items-center">
            <p className="text-slate-600 mb-4">
            Create, review, and manage financial adjustments with full audit trail and role-based access.
            </p>
            <button 
                onClick={handleOpenNewAdjustmentModal}
                className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors flex items-center text-sm font-medium"
            >
                <PlusCircleIcon className="w-5 h-5 mr-2"/>
                Create New Adjustment
            </button>
        </div>
      </DashboardCard>
      <DashboardCard title="Recent Adjustments">
        {adjustments.length > 0 ? (
             <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">ID</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Type</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Exception ID</th>
                  <th className="px-3 py-2 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Amount</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden md:table-cell">Created By</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden lg:table-cell">Created At</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {adjustments.slice().sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((adj) => (
                  <tr key={adj.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-3 py-2 whitespace-nowrap text-sm font-medium text-sky-700">{adj.id}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-700">{adj.type}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-700">{adj.relatedExceptionId || 'N/A'}</td>
                    <td className={`px-3 py-2 whitespace-nowrap text-sm font-semibold text-right ${adj.amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {adj.amount.toLocaleString(undefined, {style:'currency', currency: adj.currency})}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm">
                        <StatusPill status={adj.status} />
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-600 hidden md:table-cell">{adj.createdBy}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-600 hidden lg:table-cell">{new Date(adj.createdAt).toLocaleDateString()}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-sm text-center">
                        <button 
                            onClick={() => handleOpenEditAdjustmentModal(adj)}
                            className="text-yellow-500 hover:text-yellow-700 p-1 rounded-full hover:bg-yellow-100"
                            title="Edit Adjustment"
                        >
                            <PencilIcon className="w-4 h-4" />
                        </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
            <p className="text-slate-500 text-center py-4">No adjustments found. Click "Create New Adjustment" to add one.</p>
        )}
      </DashboardCard>

      {isAdjustmentModalOpen && (
        <AdjustmentModal
            isOpen={isAdjustmentModalOpen}
            onClose={() => {
                setIsAdjustmentModalOpen(false);
                setEditingAdjustment(null);
            }}
            onSave={handleSaveAndClose}
            existingAdjustment={editingAdjustment}
            businessArea={currentBusinessArea}
        />
      )}
    </div>
  );
};

export default AdjustmentsPage;