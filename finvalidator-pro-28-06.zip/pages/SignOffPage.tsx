import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { ProcessStatus, SignOffProductLine, SignOffStrategy } from '../types';
import SignOffDetailModal from '../components/SignOffDetailModal'; 
import { formatCurrency, calculateDoDChange } from '../utils/helpers';
import StatusPill from '../components/StatusPill';

const SignOffPage: React.FC = () => {
  const { 
    currentBusinessArea, 
    setCurrentPageTitle,
    productLinesByArea,
    updateSignOffStatus
  } = useAppContext();
  
  const displayedProductLines = useMemo(() => {
    return productLinesByArea[currentBusinessArea] || [];
  }, [productLinesByArea, currentBusinessArea]);

  const [selectedItem, setSelectedItem] = useState<SignOffProductLine | SignOffStrategy | null>(null);
  const [modalLevel, setModalLevel] = useState<'ProductLine' | 'Strategy' | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  useEffect(() => {
    setCurrentPageTitle('Sign-Off');
  }, [setCurrentPageTitle]);

  const handleOpenModal = (item: SignOffProductLine | SignOffStrategy, level: 'ProductLine' | 'Strategy') => {
    setSelectedItem(item);
    setModalLevel(level);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedItem(null);
    setModalLevel(null);
    setIsModalOpen(false);
  };

  const handleSignOffAction = useCallback((itemId: string, level: 'ProductLine' | 'Strategy', attestation: string, comments: string, approved: boolean) => {
    const newStatus = approved ? ProcessStatus.SIGNED_OFF : ProcessStatus.REJECTED;
    updateSignOffStatus(itemId, level, newStatus, approved);
    
    handleCloseModal();
    alert(`${level} ${itemId} has been ${approved ? 'Approved' : 'Rejected'}. Attestation: ${attestation}. Comments: ${comments}`);
  }, [updateSignOffStatus]);
  
  const getVarianceColorText = (isPositive: boolean, isPnL: boolean = false) => {
    if (isPnL) {
      return isPositive ? 'text-green-600' : 'text-red-600';
    }
    return isPositive ? 'text-green-600' : 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <DashboardCard title={`Sign-Off Status for ${currentBusinessArea}`}>
        <p className="text-slate-600 mb-4">
          Review Product Line financial summaries and Day-over-Day movements. Click "Review Product Line" for detailed strategy breakdown and attestation.
        </p>
         {displayedProductLines.length > 0 ? (
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Product Line</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Net P&L</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">P&L DoD</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total Assets</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Assets DoD</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider hidden md:table-cell">Last Updated</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {displayedProductLines.map((pl) => {
                  const pnlDoD = calculateDoDChange(pl.currentNetPnL, pl.previousNetPnL);
                  const assetsDoD = calculateDoDChange(pl.currentTotalAssets, pl.previousTotalAssets);
                  const canSignOffProductLine = pl.strategies.every(s => s.status === ProcessStatus.SIGNED_OFF);

                  return (
                    <tr key={pl.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-slate-800">{pl.name}</td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-600">{formatCurrency(pl.currentNetPnL, pl.currency)}</td>
                      <td className={`px-3 py-3 whitespace-nowrap text-sm font-medium ${getVarianceColorText(pnlDoD.isPositive, true)}`}>
                        {pnlDoD.amount >= 0 ? '+' : ''}{formatCurrency(pnlDoD.amount, pl.currency)} ({pnlDoD.percentage}%)
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-600">{formatCurrency(pl.currentTotalAssets, pl.currency)}</td>
                      <td className={`px-3 py-3 whitespace-nowrap text-sm font-medium ${getVarianceColorText(assetsDoD.isPositive)}`}>
                         {assetsDoD.amount >= 0 ? '+' : ''}{formatCurrency(assetsDoD.amount, pl.currency)} ({assetsDoD.percentage}%)
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                        <StatusPill status={pl.status} />
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-slate-500 hidden md:table-cell">{new Date(pl.lastUpdated).toLocaleString()}</td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                          {(pl.status === ProcessStatus.AWAITING_SIGN_OFF || pl.status === ProcessStatus.REJECTED || pl.status === ProcessStatus.IN_PROGRESS) && (
                               <button 
                                  onClick={() => handleOpenModal(pl, 'ProductLine')}
                                  className="px-3 py-1 bg-sky-600 text-white rounded-md hover:bg-sky-700 text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                                  disabled={pl.status === ProcessStatus.AWAITING_SIGN_OFF && !canSignOffProductLine}
                                  title={pl.status === ProcessStatus.AWAITING_SIGN_OFF && !canSignOffProductLine ? "All strategies must be signed off first" : "Review Product Line"}
                               >
                                  Review Product Line
                              </button>
                          )}
                           {pl.status === ProcessStatus.SIGNED_OFF && (
                               <span className="text-xs text-green-700 font-semibold">Signed Off</span>
                          )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
             <p className="text-slate-500 text-center py-4">No Product Lines to display for {currentBusinessArea}.</p>
        )}
      </DashboardCard>

      {selectedItem && modalLevel && (
        <SignOffDetailModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          item={selectedItem}
          level={modalLevel}
          onSignOffAction={handleSignOffAction}
          onOpenStrategyModal={(strategy) => handleOpenModal(strategy, 'Strategy')}
        />
      )}
    </div>
  );
};

export default SignOffPage;