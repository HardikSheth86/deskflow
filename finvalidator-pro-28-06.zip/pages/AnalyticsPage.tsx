
import React, { useEffect, useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { EyeIcon, SendIcon, DocumentReportIcon, ChevronDownIcon, ChevronUpIcon } from '../components/icons';
import SendReportModal from '../components/SendReportModal';
import FullScreenReportViewer from '../components/FullScreenReportViewer'; // New Import
import { MOCK_DISTRIBUTION_LISTS } from '../constants';

// Define ReportItem and ReportCategory interfaces
export interface ReportItem {
  id: string;
  title: string;
  description: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => React.ReactNode;
  defaultFormat: 'PDF' | 'Excel' | 'CSV';
  powerBiEmbedUrl?: string; // New field for Power BI
}

export interface ReportCategory {
  categoryId: string;
  categoryTitle: string;
  reports: ReportItem[];
}

const categorizedReports: ReportCategory[] = [
  {
    categoryId: 'pnl_bs_reports',
    categoryTitle: 'P&L and Balance Sheet Reports',
    reports: [
      {
        id: 'daily_summary_bs_pnl',
        title: 'Daily P&L and Balance Sheet Summary',
        description: 'A high-level overview of profit & loss and balance sheet figures for senior management.',
        icon: DocumentReportIcon,
        defaultFormat: 'PDF',
        powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=f6bfd646-b718-44dc-a37a-5409c593f2e1&autoAuth=true&ctid=common', // Example URL
      },
      {
        id: 'daily_pnl_detailed',
        title: 'Daily P&L Report (Detailed)',
        description: 'Comprehensive daily profit and loss statement with breakdowns by desk and product.',
        icon: DocumentReportIcon,
        defaultFormat: 'Excel',
        powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=c5c8e4d7-1b0f-4e1e-9a9c-2f9d1e4a3b7c&autoAuth=true&ctid=common', // Example URL
      },
      {
        id: 'top_movers',
        title: 'Top 10 P&L Movers',
        description: 'Highlights the most significant P&L changes by position or instrument.',
        icon: DocumentReportIcon,
        defaultFormat: 'PDF',
        // No Power BI URL - will show fallback in full screen
      },
    ]
  },
  {
    categoryId: 'exception_recon_reports',
    categoryTitle: 'Exception & Reconciliation Reports',
    reports: [
      {
        id: 'exception_aging',
        title: 'Exception Aging Report',
        description: 'Tracks the resolution time of outstanding exceptions, highlighting overdue items.',
        icon: DocumentReportIcon,
        defaultFormat: 'Excel',
        powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=another-report-id&autoAuth=true&ctid=common', // Example URL
      },
      {
        id: 't0_t1_reconciliation',
        title: 'T0 vs T+1 Reconciliation Report',
        description: 'Compares trade date P&L with T+1 settled P&L, highlighting discrepancies.',
        icon: DocumentReportIcon,
        defaultFormat: 'PDF',
        powerBiEmbedUrl: 'https://app.powerbi.com/reportEmbed?reportId=yet-another-report-id&autoAuth=true&ctid=common', // Example URL
      },
    ]
  },
  {
    categoryId: 'adjustment_reports',
    categoryTitle: 'Adjustment Analysis Reports',
    reports: [
      {
        id: 'adjustment_analysis',
        title: 'Adjustment Analysis Report',
        description: 'Summarizes the volume and value of adjustments by type and business area.',
        icon: DocumentReportIcon,
        defaultFormat: 'Excel',
        // No Power BI URL
      },
    ]
  },
];


const AnalyticsPage: React.FC = () => {
  const { setCurrentPageTitle } = useAppContext();
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [reportToSend, setReportToSend] = useState<ReportItem | null>(null);
  
  const [isFullScreenViewerOpen, setIsFullScreenViewerOpen] = useState(false);
  const [reportToViewInFullScreen, setReportToViewInFullScreen] = useState<ReportItem | null>(null);
  
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>(() => {
    // Open the first category by default
    const firstCategory = categorizedReports[0];
    return firstCategory ? { [firstCategory.categoryId]: true } : {};
  });

  useEffect(() => {
    setCurrentPageTitle('Analytics & Reporting');
  }, [setCurrentPageTitle]);

  const toggleCategory = (categoryId: string) => {
    setOpenCategories(prev => ({ ...prev, [categoryId]: !prev[categoryId] }));
  };

  const handleViewReportFullScreen = (report: ReportItem) => {
    setReportToViewInFullScreen(report);
    setIsFullScreenViewerOpen(true);
  };

  const handleOpenSendModal = (report: ReportItem) => {
    setReportToSend(report);
    setIsSendModalOpen(true);
  };
  
  const handleCloseFullScreenViewer = () => {
    setIsFullScreenViewerOpen(false);
    setReportToViewInFullScreen(null);
  };

  const handleSendFromFullScreen = (report: ReportItem) => {
    setIsFullScreenViewerOpen(false); // Close full screen viewer
    setReportToViewInFullScreen(null);
    handleOpenSendModal(report); // Open send modal
  };

  const handleConfirmSendReport = (
    title: string,
    selectedListIds: string[],
    customEmails: string,
    format: 'PDF' | 'Excel' | 'CSV'
  ) => {
    const selectedListNames = MOCK_DISTRIBUTION_LISTS
      .filter(list => selectedListIds.includes(list.id))
      .map(list => list.name)
      .join(', ');

    let message = `Simulating send for report: "${title}" in ${format} format.\n`;
    if (selectedListNames) {
      message += `Selected Distribution Lists: ${selectedListNames}\n`;
    }
    if (customEmails) {
      message += `Custom Emails: ${customEmails}\n`;
    }
    if (!selectedListNames && !customEmails) {
        message += "No recipients specified.\n"
    }
    
    alert(message + "(In a real app, this would dispatch the report via email/chosen channels)");
    setIsSendModalOpen(false);
    setReportToSend(null);
  };

  return (
    <div className="space-y-6">
      <DashboardCard title="Report Library">
        <p className="text-slate-600 mb-6">
          Access a categorized library of standard and Power BI embedded reports. Click 'View' to see a report in full-screen or 'Send' to share it.
        </p>
        <div className="space-y-3">
          {categorizedReports.map((category) => (
            <div key={category.categoryId} className="border border-slate-200 rounded-lg bg-slate-50 overflow-hidden">
              <button
                onClick={() => toggleCategory(category.categoryId)}
                className="w-full flex justify-between items-center p-3 text-left bg-slate-100 hover:bg-slate-200 focus:outline-none transition-colors"
                aria-expanded={openCategories[category.categoryId]}
                aria-controls={`category-content-${category.categoryId}`}
              >
                <h2 className="text-md font-semibold text-slate-700">{category.categoryTitle}</h2>
                {openCategories[category.categoryId] ? <ChevronUpIcon className="w-5 h-5 text-slate-600" /> : <ChevronDownIcon className="w-5 h-5 text-slate-600" />}
              </button>
              {openCategories[category.categoryId] && (
                <div id={`category-content-${category.categoryId}`} className="p-1 sm:p-3">
                  <div className="space-y-3">
                    {category.reports.map((report) => (
                      <div key={report.id} className="p-3 border border-slate-200 rounded-md bg-white hover:shadow-md transition-shadow">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                          <div className="flex items-start mb-3 sm:mb-0">
                            <report.icon className="w-7 h-7 text-sky-600 mr-3 flex-shrink-0 mt-1" />
                            <div>
                              <h3 className="text-sm font-semibold text-slate-800">{report.title}</h3>
                              <p className="text-xs text-slate-500">{report.description}</p>
                              <p className="text-xs text-indigo-500 mt-1">Default Send Format: {report.defaultFormat} {report.powerBiEmbedUrl && <span className="ml-2 px-1.5 py-0.5 bg-sky-100 text-sky-700 rounded-full text-xs">Power BI available</span>}</p>
                            </div>
                          </div>
                          <div className="flex space-x-2 flex-shrink-0 mt-2 sm:mt-0 self-center sm:self-auto sm:ml-4">
                            <button
                              onClick={() => handleViewReportFullScreen(report)}
                              className="px-3 py-1.5 bg-sky-500 text-white rounded-md hover:bg-sky-600 transition-colors text-xs font-medium flex items-center"
                              aria-label={`View ${report.title}`}
                            >
                              <EyeIcon className="w-4 h-4 mr-1" />
                              View
                            </button>
                            <button
                              onClick={() => handleOpenSendModal(report)}
                              className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-xs font-medium flex items-center"
                              aria-label={`Send ${report.title}`}
                            >
                              <SendIcon className="w-4 h-4 mr-1" />
                              Send
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </DashboardCard>
      
      <DashboardCard title="Custom Analytics Workspace">
        <p className="text-slate-600 mb-4">
          This area can be used for more ad-hoc analysis or custom-built dashboards not fitting the pre-canned library. (Placeholder)
        </p>
        <div className="h-48 bg-slate-200 rounded-md flex items-center justify-center">
          <p className="text-slate-500">Custom analytics components or another embedded BI tool could go here.</p>
        </div>
      </DashboardCard>

      {reportToSend && (
        <SendReportModal
          isOpen={isSendModalOpen}
          onClose={() => {
            setIsSendModalOpen(false);
            setReportToSend(null);
          }}
          reportTitle={reportToSend.title}
          defaultFormat={reportToSend.defaultFormat}
          distributionLists={MOCK_DISTRIBUTION_LISTS}
          onConfirmSend={handleConfirmSendReport}
        />
      )}

      {isFullScreenViewerOpen && reportToViewInFullScreen && (
        <FullScreenReportViewer
          report={reportToViewInFullScreen}
          onClose={handleCloseFullScreenViewer}
          onSend={handleSendFromFullScreen}
        />
      )}
    </div>
  );
};

export default AnalyticsPage;
