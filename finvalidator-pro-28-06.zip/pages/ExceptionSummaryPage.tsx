import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Exception, ExceptionCategory, ExceptionStatus, ContextMenuItemType, DrillDownContentType, PositionDrillDownInfo, TradeDrillDownInfo } from '../types';
import DashboardCard from '../components/DashboardCard';
import { FilterIcon, EyeIcon, PencilIcon, ListBulletIcon, ShareIcon, InformationCircleIcon, AdjustmentIcon, CheckCircleIcon, CloseIcon } from '../components/icons';
import ExceptionDetailModal from '../components/ExceptionDetailModal';
import ContextMenu from '../components/ContextMenu'; 
import AdjustmentModal from '../components/AdjustmentModal';
import { RenderPositionDetails, RenderTradeDetails } from '../components/DrillDownViews';
import StatusPill from '../components/StatusPill';

const ExceptionSummaryPage: React.FC = () => {
  const { 
    exceptions, 
    updateException, 
    updateMultipleExceptions, 
    saveAdjustment,
    currentBusinessArea, 
    setCurrentPageTitle 
  } = useAppContext();
  
  const [selectedException, setSelectedException] = useState<Exception | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<ExceptionCategory | 'ALL'>('ALL');
  const [selectedExceptionIds, setSelectedExceptionIds] = useState<string[]>([]);
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    exception: Exception | null;
  }>({ visible: false, x: 0, y: 0, exception: null });

  // State for inline drill-down view
  const [drilledDownException, setDrilledDownException] = useState<Exception | null>(null);
  const [drillDownContent, setDrillDownContent] = useState<DrillDownContentType | null>(null);

  // State for AdjustmentModal
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
  const [exceptionForAdjustment, setExceptionForAdjustment] = useState<Exception | null>(null);
  
  useEffect(() => {
    setCurrentPageTitle('Exception Summary');
  }, [setCurrentPageTitle]);

  const filteredExceptions = useMemo(() => {
    return exceptions.filter(ex => 
      ex.businessArea === currentBusinessArea &&
      (activeCategory === 'ALL' || ex.category === activeCategory) &&
      ex.status !== ExceptionStatus.CLOSED && ex.status !== ExceptionStatus.RESOLVED 
    );
  }, [exceptions, currentBusinessArea, activeCategory]);

  useEffect(() => {
    setSelectedExceptionIds([]);
    setDrillDownContent(null);
    setDrilledDownException(null);
  }, [currentBusinessArea, activeCategory]);

  const handleViewDetails = useCallback((exception: Exception) => {
    setSelectedException(exception);
    setIsDetailModalOpen(true);
    setContextMenu({ visible: false, x: 0, y: 0, exception: null }); 
  }, []);
  
  const handleOpenAdjustmentModal = useCallback((exception: Exception) => {
    setExceptionForAdjustment(exception);
    setIsAdjustmentModalOpen(true);
    closeContextMenu();
    setIsDetailModalOpen(false);
  }, []);
  
  const handleSaveAndLinkAdjustment = useCallback((adjustment) => {
    saveAdjustment(adjustment); // Save via context
    if (adjustment.relatedExceptionId) {
      const relatedExc = exceptions.find(ex => ex.id === adjustment.relatedExceptionId);
      if (relatedExc && relatedExc.status !== ExceptionStatus.PENDING_ADJUSTMENT) {
        updateException({ ...relatedExc, status: ExceptionStatus.PENDING_ADJUSTMENT });
      }
    }
    setIsAdjustmentModalOpen(false);
    setExceptionForAdjustment(null);
  }, [exceptions, saveAdjustment, updateException]);


  const handleToggleSelectAll = (isChecked: boolean) => {
    setSelectedExceptionIds(isChecked ? filteredExceptions.map(ex => ex.id) : []);
  };

  const handleToggleSelectOne = (exceptionId: string, isChecked: boolean) => {
    setSelectedExceptionIds(prev => isChecked ? [...prev, exceptionId] : prev.filter(id => id !== exceptionId));
  };

  const handleBulkAction = (action: string) => {
    if (selectedExceptionIds.length === 0) {
      alert("Please select one or more exceptions to perform a bulk action.");
      return;
    }

    if (action === 'Assign to Team') {
      alert(`Bulk Assign Action for exceptions: ${selectedExceptionIds.join(', ')}\n(Simulated: Would assign these to a chosen team.)`);
    } else if (action === 'Approve Selected') {
      const exceptionsToUpdate = exceptions.filter(ex => selectedExceptionIds.includes(ex.id))
        .map(ex => ({ ...ex, status: ExceptionStatus.RESOLVED, rcaCommentary: ex.rcaCommentary || "Bulk approved." }));
      
      updateMultipleExceptions(exceptionsToUpdate);
      alert(`Approved exceptions: ${selectedExceptionIds.join(', ')}.`);
      setSelectedExceptionIds([]);
    }
  };

  const handleContextMenu = (event: React.MouseEvent, exception: Exception) => {
    event.preventDefault();
    setContextMenu({
      visible: true,
      x: event.clientX,
      y: event.clientY,
      exception: exception,
    });
  };

  const closeContextMenu = () => {
    setContextMenu({ visible: false, x: 0, y: 0, exception: null });
  };
  
  const handleDrillDownPosition = (exception: Exception) => {
    const mockPositionData: PositionDrillDownInfo = {
      positionId: exception.positionId,
      marketValue: (Math.random() * 500000 + 100000).toLocaleString('en-US', { style: 'currency', currency: exception.currency }),
      quantity: Math.floor(Math.random() * 1000) + 50,
      costBasis: (Math.random() * 400000 + 80000).toLocaleString('en-US', { style: 'currency', currency: exception.currency }),
      lastPrice: (Math.random() * 200 + 50).toLocaleString('en-US', { style: 'currency', currency: exception.currency }),
      unrealizedPnL: (exception.financialImpact * (Math.random() * 0.5 + 0.8)).toLocaleString('en-US', { style: 'currency', currency: exception.currency }),
      relatedBook: `Book_${Math.floor(Math.random() * 10) + 1}`,
      assetClass: exception.details?.AssetClass as string || 'Equity',
    };
    setDrilledDownException(exception);
    setDrillDownContent({ type: 'position', data: mockPositionData });
    closeContextMenu();
  };

  const handleDrillDownTrades = (exception: Exception) => {
    const mockTradesData: TradeDrillDownInfo[] = Array.from({ length: Math.floor(Math.random() * 5) + 1 }, (_, i) => ({
      tradeId: `T-${exception.id.slice(-3)}-${String(i + 1).padStart(3, '0')}`,
      timestamp: new Date(new Date(exception.dateIdentified).getTime() - Math.random() * 86400000).toISOString(),
      quantity: Math.floor(Math.random() * 200) + 10,
      price: parseFloat((Math.random() * 100 + 10).toFixed(2)),
      currency: exception.currency,
      direction: Math.random() > 0.5 ? 'Buy' : 'Sell',
      counterparty: `CPTY-${String.fromCharCode(65 + Math.floor(Math.random()*10))}`,
      relatedExceptionId: exception.id,
    }));
    setDrilledDownException(exception);
    setDrillDownContent({ type: 'trades', data: mockTradesData });
    closeContextMenu();
  };

  const getContextMenuItems = (exception: Exception): ContextMenuItemType[] => [
    { label: "View Full Details (Modal)", icon: EyeIcon, onClick: () => handleViewDetails(exception) },
    { label: "Create Adjustment", icon: AdjustmentIcon, onClick: () => handleOpenAdjustmentModal(exception) },
    { isSeparator: true },
    { label: `Drill-down below: Position`, icon: InformationCircleIcon, onClick: () => handleDrillDownPosition(exception) },
    { label: `Drill-down below: Trades`, icon: ListBulletIcon, onClick: () => handleDrillDownTrades(exception) },
    { isSeparator: true },
    { label: "Assign Exception...", icon: ShareIcon, onClick: () => {
        alert(`Simulating Assignment:\nOpening dialog to assign Exception ID: ${exception.id}`);
        closeContextMenu();
      } 
    },
    { label: "Mark as Resolved", icon: CheckCircleIcon, onClick: () => {
        updateException({...exception, status: ExceptionStatus.RESOLVED, rcaCommentary: exception.rcaCommentary || "Resolved via context menu action."});
        alert(`Exception ${exception.id} marked as Resolved.`);
        closeContextMenu();
      }, 
      disabled: exception.status === ExceptionStatus.RESOLVED || exception.status === ExceptionStatus.CLOSED 
    },
  ];

  const getCategoryStyle = (category: ExceptionCategory) => {
    switch (category) {
        case ExceptionCategory.FOBO: return "border-red-500 bg-red-50";
        case ExceptionCategory.VRS: return "border-yellow-500 bg-yellow-50";
        case ExceptionCategory.DOD: return "border-purple-500 bg-purple-50";
        case ExceptionCategory.ATTRIBUTION: return "border-indigo-500 bg-indigo-50";
        case ExceptionCategory.CUSTOM_RULES: return "border-teal-500 bg-teal-50";
        default: return "border-gray-300 bg-gray-50";
    }
  };

  const exceptionCategories: ExceptionCategory[] = Object.values(ExceptionCategory);

  const exceptionsCountByCategory = useMemo(() => {
    const counts: Record<ExceptionCategory, number> = {} as Record<ExceptionCategory, number>;
    exceptionCategories.forEach(cat => counts[cat] = 0);
    exceptions.filter(ex => ex.businessArea === currentBusinessArea && ex.status !== ExceptionStatus.CLOSED && ex.status !== ExceptionStatus.RESOLVED)
                   .forEach(ex => {
                     counts[ex.category]++;
                   });
    return counts;
  }, [exceptions, currentBusinessArea]);

  const isAllSelected = useMemo(() => {
    return filteredExceptions.length > 0 && selectedExceptionIds.length === filteredExceptions.length;
  }, [filteredExceptions, selectedExceptionIds]);

  return (
    <div className="space-y-6">
      <DashboardCard title={`Exceptions for ${currentBusinessArea}`}>
        <div className="mb-4 flex space-x-2 border-b border-slate-200 pb-2 overflow-x-auto">
            <button
                onClick={() => setActiveCategory('ALL')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${activeCategory === 'ALL' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
                All ({exceptions.filter(ex => ex.businessArea === currentBusinessArea && ex.status !== ExceptionStatus.CLOSED && ex.status !== ExceptionStatus.RESOLVED).length})
            </button>
            {exceptionCategories.map(cat => (
                <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${activeCategory === cat ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                >
                    {cat} ({exceptionsCountByCategory[cat]})
                </button>
            ))}
        </div>
        
        <div className="flex justify-between items-center mb-4">
            <p className="text-slate-600 text-sm">
              Showing {filteredExceptions.length} exceptions. Selected: {selectedExceptionIds.length}. Right-click for more options.
            </p>
            <div className="flex space-x-2">
                <button 
                    onClick={() => handleBulkAction('Assign to Team')}
                    disabled={selectedExceptionIds.length === 0}
                    className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <ShareIcon className="w-4 h-4 mr-1.5" /> Bulk Assign
                </button>
                 <button 
                    onClick={() => handleBulkAction('Approve Selected')}
                    disabled={selectedExceptionIds.length === 0}
                    className="px-3 py-1.5 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors text-sm font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <CheckCircleIcon className="w-4 h-4 mr-1.5" /> Bulk Approve
                </button>
            </div>
        </div>

        {filteredExceptions.length > 0 ? (
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider w-12">
                    <input 
                      type="checkbox"
                      className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                      checked={isAllSelected}
                      onChange={(e) => handleToggleSelectAll(e.target.checked)}
                      aria-label="Select all exceptions"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Category</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Position ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Impact</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden sm:table-cell">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredExceptions.map((ex) => (
                  <tr 
                    key={ex.id} 
                    className={`hover:bg-sky-50 transition-colors ${getCategoryStyle(ex.category)} border-l-4 cursor-context-menu ${selectedExceptionIds.includes(ex.id) ? 'bg-sky-100' : ''}`}
                    onContextMenu={(e) => handleContextMenu(e, ex)}
                  >
                    <td className="px-4 py-3 whitespace-nowrap">
                      <input 
                        type="checkbox"
                        className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                        checked={selectedExceptionIds.includes(ex.id)}
                        onChange={(e) => handleToggleSelectOne(ex.id, e.target.checked)}
                        aria-label={`Select exception ${ex.id}`}
                      />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-sky-700">{ex.id}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-700">{ex.category}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600">{ex.positionId}</td>
                    <td className={`px-4 py-3 whitespace-nowrap text-sm font-semibold ${ex.financialImpact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {ex.financialImpact.toLocaleString(undefined, {style:'currency', currency: ex.currency})}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm">
                      <StatusPill status={ex.status} />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600">{new Date(ex.dateIdentified).toLocaleDateString()}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm space-x-2 hidden sm:table-cell">
                      <button onClick={() => handleViewDetails(ex)} className="text-sky-600 hover:text-sky-800" title="View Details">
                        <EyeIcon className="w-5 h-5"/>
                      </button>
                      <button onClick={() => handleViewDetails(ex)} className="text-yellow-500 hover:text-yellow-700" title="Edit/Comment">
                        <PencilIcon className="w-5 h-5"/>
                      </button>
                       <button onClick={() => handleOpenAdjustmentModal(ex)} className="text-indigo-500 hover:text-indigo-700" title="Create Adjustment">
                        <AdjustmentIcon className="w-5 h-5"/>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-slate-500 text-center py-8">No exceptions match the current filters for {currentBusinessArea}.</p>
        )}
      </DashboardCard>
      
      {drillDownContent && drilledDownException && (
        <DashboardCard
            title={`Drill-Down Details for Exception: ${drilledDownException.id}`}
            className="mt-6"
            actions={
                <button 
                onClick={() => { setDrillDownContent(null); setDrilledDownException(null); }} 
                className="text-slate-500 hover:text-slate-700 p-1 rounded-full"
                aria-label="Close drill-down view"
                >
                <CloseIcon className="w-5 h-5" />
                </button>
            }
        >
            {drillDownContent.type === 'position' && <RenderPositionDetails data={drillDownContent.data} />}
            {drillDownContent.type === 'trades' && <RenderTradeDetails data={drillDownContent.data} />}
        </DashboardCard>
      )}

      {selectedException && isDetailModalOpen && (
        <ExceptionDetailModal
          isOpen={isDetailModalOpen}
          onClose={() => {setIsDetailModalOpen(false); setSelectedException(null);}}
          exception={selectedException}
          onUpdateException={updateException}
          onInitiateAdjustment={() => selectedException && handleOpenAdjustmentModal(selectedException)}
        />
      )}

      {contextMenu.visible && contextMenu.exception && (
        <ContextMenu
          isOpen={contextMenu.visible}
          x={contextMenu.x}
          y={contextMenu.y}
          items={getContextMenuItems(contextMenu.exception)}
          onClose={closeContextMenu}
        />
      )}

      {isAdjustmentModalOpen && (
        <AdjustmentModal
          isOpen={isAdjustmentModalOpen}
          onClose={() => {
            setIsAdjustmentModalOpen(false);
            setExceptionForAdjustment(null);
          }}
          onSave={handleSaveAndLinkAdjustment}
          exception={exceptionForAdjustment}
          businessArea={currentBusinessArea}
        />
      )}
    </div>
  );
};

export default ExceptionSummaryPage;