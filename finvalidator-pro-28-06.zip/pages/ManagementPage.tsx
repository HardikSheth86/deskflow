import React, { useEffect, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { BusinessArea } from '../types';
import DashboardCard from '../components/DashboardCard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import StatusPill from '../components/StatusPill';
import { ALL_BUSINESS_AREAS } from '../constants';
import { formatCurrency } from '../utils/helpers';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const ManagementPage: React.FC = () => {
  const { setCurrentPageTitle, exceptions, productLinesByArea } = useAppContext();

  useEffect(() => {
    setCurrentPageTitle('Management Dashboard');
  }, [setCurrentPageTitle]);

  const pnlByArea = useMemo(() => {
    return ALL_BUSINESS_AREAS.map(area => {
      const pnl = (productLinesByArea[area] || []).reduce((sum, pl) => sum + pl.currentNetPnL, 0);
      return {
        name: area,
        'Net P&L': pnl,
      };
    });
  }, [productLinesByArea]);

  const exceptionsByArea = useMemo(() => {
    const counts: { [key in BusinessArea]?: number } = {};
    exceptions.forEach(ex => {
      if (ex.status === 'Open' || ex.status === 'In Review') {
        counts[ex.businessArea] = (counts[ex.businessArea] || 0) + 1;
      }
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value: value || 0 }));
  }, [exceptions]);

  const topExceptions = useMemo(() => {
    return exceptions
        .filter(ex => ex.status === 'Open' || ex.status === 'In Review')
        .sort((a, b) => Math.abs(b.financialImpact) - Math.abs(a.financialImpact))
        .slice(0, 5);
  }, [exceptions]);

  const recentActivity = useMemo(() => {
      const allActivities = Object.values(productLinesByArea).flat().flatMap(pl => 
          pl.strategies.flatMap(s => 
              s.activityLog.map(log => ({ ...log, businessArea: s.businessArea }))
          )
      );
      return allActivities
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 7);
  }, [productLinesByArea]);

  const allProductLines = useMemo(() => {
    return Object.values(productLinesByArea).flat();
  }, [productLinesByArea]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Net P&L Contribution by Business Area">
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={pnlByArea} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tickFormatter={(value) => `$${(Number(value) / 1000000).toFixed(1)}M`} tick={{ fontSize: 12 }}/>
                    <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                    <Legend />
                    <Bar dataKey="Net P&L" fill="#8884d8" />
                </BarChart>
            </ResponsiveContainer>
        </DashboardCard>
        <DashboardCard title="Open Exceptions by Business Area">
            <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                    <Pie
                        data={exceptionsByArea}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                    >
                        {exceptionsByArea.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value} exceptions`} />
                    <Legend />
                </PieChart>
            </ResponsiveContainer>
        </DashboardCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Top Outstanding Exceptions (by Financial Impact)">
          {topExceptions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-3 py-2 text-left font-medium text-slate-500">ID</th>
                    <th className="px-3 py-2 text-left font-medium text-slate-500">Area</th>
                    <th className="px-3 py-2 text-right font-medium text-slate-500">Impact</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {topExceptions.map(ex => (
                    <tr key={ex.id}>
                      <td className="px-3 py-2 font-medium text-sky-600">{ex.id}</td>
                      <td className="px-3 py-2 text-slate-600">{ex.businessArea}</td>
                      <td className={`px-3 py-2 text-right font-semibold ${ex.financialImpact < 0 ? 'text-red-600' : 'text-slate-700'}`}>
                        {formatCurrency(ex.financialImpact, ex.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-slate-500 text-center py-4">No open exceptions.</p>
          )}
        </DashboardCard>
        <DashboardCard title="Recent Firm-wide Activity">
          {recentActivity.length > 0 ? (
            <ul className="space-y-2">
              {recentActivity.map(log => (
                <li key={log.id} className="text-xs p-2 bg-slate-50 rounded-md border-l-4 border-slate-300">
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-700">{log.type} in {log.businessArea}</span>
                    <span className="text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-slate-600 truncate">{log.description}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-slate-500 text-center py-4">No recent activity.</p>
          )}
        </DashboardCard>
      </div>
      
      <DashboardCard title="Firm-wide Sign-Off Status">
        <div className="overflow-x-auto rounded-lg border border-slate-200 max-h-[60vh]">
            <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-100 sticky top-0">
                    <tr>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Product Line</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Business Area</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                        <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Net P&L</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden md:table-cell">Last Updated</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100">
                    {allProductLines.map(pl => (
                        <tr key={pl.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-800">{pl.name}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600">{pl.businessArea}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm"><StatusPill status={pl.status} /></td>
                            <td className={`px-4 py-3 whitespace-nowrap text-sm text-right font-semibold ${pl.currentNetPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {pl.currentNetPnL.toLocaleString('en-US', { style: 'currency', currency: pl.currency, minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500 hidden md:table-cell">{new Date(pl.lastUpdated).toLocaleString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </DashboardCard>
    </div>
  );
};

export default ManagementPage;