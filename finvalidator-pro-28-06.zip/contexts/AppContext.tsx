import React, { createContext, useState, ReactNode, useCallback } from 'react';
import { 
  BusinessArea, AppContextType, Exception, Adjustment, SignOffProductLine, 
  Commentary, PreSignOffTask, ProcessStatus 
} from '../types';
import { 
  ALL_BUSINESS_AREAS, 
  MOCK_EXCEPTIONS, 
  MOCK_ADJUSTMENTS, 
  MOCK_PRODUCT_LINES_BY_AREA, 
  MOCK_COMMENTARIES,
  MOCK_PRE_SIGN_OFF_TASKS_BY_AREA,
} from '../constants';
import { determineProductLineStatus } from '../utils/helpers';

/**
 * @type {React.Context<AppContextType | undefined>}
 * The main application context. Provides access to global state and updater functions.
 * It is initialized as `undefined` and should be consumed using the `useAppContext` hook,
 * which ensures it is only accessed within components wrapped by the `AppProvider`.
 */
export const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

/**
 * The provider component for the application's global state.
 * It initializes and manages all the core data (exceptions, adjustments, etc.)
 * and exposes functions to modify that data in an immutable way.
 * All components that need access to global state should be children of this provider.
 * @param {AppProviderProps} props - The component props.
 * @returns {JSX.Element} The provider component wrapping its children.
 */
export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [currentBusinessArea, setCurrentBusinessArea] = useState<BusinessArea>(ALL_BUSINESS_AREAS[0]);
  const [currentPageTitle, setCurrentPageTitle] = useState<string>('Dashboard');

  // Centralized State Management for all mock data
  const [exceptions, setExceptions] = useState<Exception[]>(() => JSON.parse(JSON.stringify(MOCK_EXCEPTIONS)));
  const [adjustments, setAdjustments] = useState<Adjustment[]>(() => JSON.parse(JSON.stringify(MOCK_ADJUSTMENTS)));
  const [productLinesByArea, setProductLinesByArea] = useState<Record<BusinessArea, SignOffProductLine[]>>(() => JSON.parse(JSON.stringify(MOCK_PRODUCT_LINES_BY_AREA)));
  const [commentaries, setCommentaries] = useState<Commentary[]>(() => JSON.parse(JSON.stringify(MOCK_COMMENTARIES)));
  const [preSignOffTasksByArea, setPreSignOffTasksByArea] = useState<Record<BusinessArea, PreSignOffTask[]>>(() => JSON.parse(JSON.stringify(MOCK_PRE_SIGN_OFF_TASKS_BY_AREA)));

  /**
   * Updates a single exception in the global state.
   * @param {Exception} updatedException - The exception object with the updated values.
   */
  const updateException = useCallback((updatedException: Exception) => {
    setExceptions(prev => prev.map(ex => ex.id === updatedException.id ? updatedException : ex));
  }, []);

  /**
   * Updates multiple exceptions in the global state, typically for bulk actions.
   * @param {Exception[]} updatedExceptions - An array of exception objects with updated values.
   */
  const updateMultipleExceptions = useCallback((updatedExceptions: Exception[]) => {
    setExceptions(prev => {
        const updatedIds = new Set(updatedExceptions.map(ue => ue.id));
        return prev.map(ex => {
            const foundUpdate = updatedExceptions.find(ue => ue.id === ex.id);
            return foundUpdate ? foundUpdate : ex;
        });
    });
  }, []);

  /**
   * Saves or creates an adjustment in the global state.
   * If an adjustment with the same ID exists, it's updated; otherwise, it's added.
   * @param {Adjustment} adjustmentToSave - The adjustment object to save.
   */
  const saveAdjustment = useCallback((adjustmentToSave: Adjustment) => {
    setAdjustments(prev => {
      const index = prev.findIndex(adj => adj.id === adjustmentToSave.id);
      if (index > -1) {
        const updated = [...prev];
        updated[index] = adjustmentToSave;
        return updated;
      }
      return [...prev, adjustmentToSave];
    });
  }, []);

  /**
   * Updates the sign-off status of a Product Line or a Strategy.
   * Also handles the logic for rolling up statuses (e.g., if a strategy is rejected, the parent product line status is updated).
   * @param {string} itemId - The ID of the item to update (ProductLine or Strategy).
   * @param {'ProductLine' | 'Strategy'} level - The level of the item being updated.
   * @param {ProcessStatus} newStatus - The new status to apply.
   * @param {boolean} approved - A flag indicating if the action was an approval (true) or rejection (false).
   */
  const updateSignOffStatus = useCallback((itemId: string, level: 'ProductLine' | 'Strategy', newStatus: ProcessStatus, approved: boolean) => {
    setProductLinesByArea(prevAreaState => {
      const newAreaState = { ...prevAreaState };
      const productLinesForCurrentArea = [...newAreaState[currentBusinessArea]];
      
      let parentProductLine: SignOffProductLine | undefined;
      let parentProductLineIndex = -1;

      if (level === 'Strategy') {
        for (let i = 0; i < productLinesForCurrentArea.length; i++) {
          const pl = productLinesForCurrentArea[i];
          const strategyIndex = pl.strategies.findIndex(s => s.id === itemId);
          if (strategyIndex !== -1) {
            // Create a new strategy object with updated status
            const updatedStrategy = { 
              ...pl.strategies[strategyIndex], 
              status: newStatus,
              lastUpdated: new Date().toISOString()
            };
            // Create a new strategies array
            const newStrategies = [...pl.strategies];
            newStrategies[strategyIndex] = updatedStrategy;
            // Create a new product line object
            parentProductLine = { ...pl, strategies: newStrategies };
            parentProductLineIndex = i;
            break;
          }
        }
        if (parentProductLine && parentProductLineIndex !== -1) {
           // Determine the new status for the parent product line
           const newParentStatus = determineProductLineStatus(parentProductLine.strategies);
           parentProductLine = { ...parentProductLine, status: newParentStatus, lastUpdated: new Date().toISOString() };
           productLinesForCurrentArea[parentProductLineIndex] = parentProductLine;
        }
      } else if (level === 'ProductLine') {
        const productLineIndex = productLinesForCurrentArea.findIndex(pl => pl.id === itemId);
        if (productLineIndex !== -1) {
           const updatedProductLine = { 
               ...productLinesForCurrentArea[productLineIndex], 
               status: newStatus,
               lastUpdated: new Date().toISOString()
           };
           productLinesForCurrentArea[productLineIndex] = updatedProductLine;
        }
      }

      newAreaState[currentBusinessArea] = productLinesForCurrentArea;
      return newAreaState;
    });
  }, [currentBusinessArea]);
  
  /**
   * Saves or creates a commentary in the global state.
   * @param {Commentary} commentaryToSave - The commentary object to save.
   */
  const saveCommentary = useCallback((commentaryToSave: Commentary) => {
    setCommentaries(prev => {
      const index = prev.findIndex(c => c.id === commentaryToSave.id);
      if (index > -1) {
        const updated = [...prev];
        updated[index] = commentaryToSave;
        return updated;
      }
      return [...prev, commentaryToSave];
    });
  }, []);

  /**
   * Updates a single pre-sign-off task in the global state.
   * @param {PreSignOffTask} updatedTask - The task object with updated values.
   */
  const updatePreSignOffTask = useCallback((updatedTask: PreSignOffTask) => {
    setPreSignOffTasksByArea(prev => {
      const newAreaState = { ...prev };
      const tasksForCurrentArea = newAreaState[updatedTask.businessArea] ? [...newAreaState[updatedTask.businessArea]] : [];
      const taskIndex = tasksForCurrentArea.findIndex(t => t.id === updatedTask.id);
      if (taskIndex !== -1) {
        tasksForCurrentArea[taskIndex] = updatedTask;
        newAreaState[updatedTask.businessArea] = tasksForCurrentArea;
        return newAreaState;
      }
      return prev; // Return original state if task not found
    });
  }, []);

  const value = {
    currentBusinessArea,
    setCurrentBusinessArea,
    currentPageTitle,
    setCurrentPageTitle,
    exceptions,
    adjustments,
    productLinesByArea,
    commentaries,
    preSignOffTasksByArea,
    updateException,
    updateMultipleExceptions,
    saveAdjustment,
    updateSignOffStatus,
    saveCommentary,
    updatePreSignOffTask
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};