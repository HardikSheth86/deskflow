import React from 'react';
import { HashRouter, Routes, Route, Outlet } from 'react-router-dom';
import TopNav from './components/TopNav'; // Changed from Sidebar
import Header from './components/Header';
import DashboardPage from './pages/DashboardPage';
import PreSignOffPage from './pages/PreSignOffPage'; // New page
import ExceptionSummaryPage from './pages/ExceptionSummaryPage';
import AdjustmentsPage from './pages/AdjustmentsPage';
import SignOffPage from './pages/SignOffPage';
import CommentaryPage from './pages/CommentaryPage';
import AnalyticsPage from './pages/AnalyticsPage';
import CaseManagementPage from './pages/CaseManagementPage';
import InvestigationPage from './pages/InvestigationPage'; // New page for investigation workbench
import TraderReviewPage from './pages/TraderReviewPage'; // New page for trader review
import ManagementPage from './pages/ManagementPage'; // New page for management
import HelpWidget from './components/HelpWidget'; // New Help Widget
import DocumentationPage from './pages/DocumentationPage'; // New Docs Page
import TestingPage from './pages/TestingPage'; // New Testing Page

// Main layout component
const MainLayout: React.FC = () => {
  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <TopNav /> {/* Sidebar is now TopNav */}
      <Header /> {/* Simplified Header for page title */}
      <main className="flex-1 p-6 overflow-y-auto bg-slate-50">
        <Outlet />
      </main>
    </div>
  );
};


const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="relative">
        <Routes>
          <Route path="/" element={<MainLayout />}>
            <Route index element={<DashboardPage />} />
            <Route path="trader-review" element={<TraderReviewPage />} />
            <Route path="presignoff" element={<PreSignOffPage />} />
            <Route path="exceptions" element={<ExceptionSummaryPage />} />
            <Route path="adjustments" element={<AdjustmentsPage />} />
            <Route path="sign-off" element={<SignOffPage />} />
            <Route path="commentary" element={<CommentaryPage />} />
            <Route path="analytics" element={<AnalyticsPage />} />
            <Route path="investigation" element={<InvestigationPage />} />
            <Route path="management" element={<ManagementPage />} />
            <Route path="cases" element={<CaseManagementPage />} />
            <Route path="documentation" element={<DocumentationPage />} />
            <Route path="testing" element={<TestingPage />} />
            {/* Catch-all for undefined routes within the layout */}
            <Route path="*" element={<DashboardPage />} /> 
          </Route>
        </Routes>
        <HelpWidget />
      </div>
    </HashRouter>
  );
};

export default App;