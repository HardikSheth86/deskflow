import React, { ReactNode } from 'react';
import { CloseIcon } from './icons';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string; // Optional for fullscreen, as it might have its own header
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  fullScreen?: boolean; // New prop
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, size = 'md', fullScreen = false }) => {
  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
  };

  if (fullScreen) {
    return (
      <div 
        className="fixed inset-0 bg-slate-100 z-50 flex flex-col animate-modalShowFullScreen"
        role="dialog"
        aria-modal="true"
      >
        {/* Fullscreen content is directly children. Header might be part of children or specific to the fullscreen component. */}
        {children}
         <style>{`
          @keyframes modalShowFullScreen {
            from { opacity: 0.8; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-modalShowFullScreen {
            animation: modalShowFullScreen 0.3s ease-out forwards;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out"
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? 'modal-title' : undefined}
    >
      <div className={`bg-white rounded-lg shadow-xl w-full ${sizeClasses[size]} flex flex-col overflow-hidden transform transition-all duration-300 ease-in-out scale-95 opacity-0 animate-modalShow`}>
        {title && (
          <div className="flex justify-between items-center p-4 border-b border-slate-200 flex-shrink-0">
            <h2 id="modal-title" className="text-xl font-semibold text-slate-700">{title}</h2>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 transition-colors"
              aria-label="Close modal"
            >
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        )}
        <div className="p-6 max-h-[70vh] overflow-y-auto flex-grow">
          {children}
        </div>
      </div>
      <style>{`
        @keyframes modalShow {
          to {
            transform: scale(1);
            opacity: 1;
          }
        }
        .animate-modalShow {
          animation: modalShow 0.3s forwards;
        }
      `}</style>
    </div>
  );
};

export default Modal;
