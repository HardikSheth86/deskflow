import React, { ReactNode } from 'react';

/**
 * @interface DashboardCardProps
 * Defines the props for the DashboardCard component.
 * @property {ReactNode} title - The title of the card. Can be a string or a JSX element.
 * @property {ReactNode} children - The main content of the card.
 * @property {string} [className] - Optional additional CSS classes to apply to the card container.
 * @property {ReactNode} [actions] - Optional action elements (like buttons or links) to display in the card's header.
 */
interface DashboardCardProps {
  title: ReactNode;
  children: ReactNode;
  className?: string;
  actions?: ReactNode;
}

/**
 * A reusable card component for displaying content on the dashboard and other pages.
 * It provides a consistent layout with a title, content area, and an optional actions section.
 * @param {DashboardCardProps} props - The props for the component.
 * @returns {JSX.Element} The rendered card component.
 */
const DashboardCard: React.FC<DashboardCardProps> = ({ title, children, className = '', actions }) => {
  return (
    <div className={`bg-white shadow-lg rounded-xl p-6 ${className}`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-slate-700">{title}</h3>
        {actions && <div className="flex space-x-2">{actions}</div>}
      </div>
      <div>{children}</div>
    </div>
  );
};

export default DashboardCard;