import React, { useEffect, useRef } from 'react';
import { ContextMenuItemType } from '../types';

interface ContextMenuProps {
  isOpen: boolean;
  x: number;
  y: number;
  items: ContextMenuItemType[];
  onClose: () => void;
}

const ContextMenu: React.FC<ContextMenuProps> = ({ isOpen, x, y, items, onClose }) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscapeKey);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      ref={menuRef}
      className="fixed bg-white border border-slate-300 rounded-md shadow-lg py-1 z-50 min-w-[200px]"
      style={{ top: y, left: x }}
      role="menu"
      aria-orientation="vertical"
      aria-labelledby="options-menu"
    >
      {items.map((item, index) => {
        if (item.isSeparator) {
          return <div key={`separator-${index}`} className="border-t border-slate-200 my-1" />;
        }
        return (
          <button
            key={item.label}
            onClick={() => {
              item.onClick();
              onClose(); // Close menu after action
            }}
            disabled={item.disabled}
            className={`w-full flex items-center px-3 py-2 text-sm text-slate-700 hover:bg-sky-100 hover:text-sky-700 focus:outline-none focus:bg-sky-100 focus:text-sky-700 ${item.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
            role="menuitem"
          >
            {item.icon && <item.icon className="w-4 h-4 mr-2.5" />}
            <span>{item.label}</span>
          </button>
        );
      })}
    </div>
  );
};

export default ContextMenu;
