import React, { useState, useMemo } from 'react';
import { 
    QuestionMarkCircleIcon, CloseIcon, ChevronRightIcon, ChatBubbleLeftRightIcon, 
    BookOpenIcon, TicketIcon, LightbulbIcon, ArrowLeftIcon 
} from './icons';
import { FAQ } from '../types';
import { MOCK_FAQS } from '../constants';
import AIChatView from './AIChatView';

type HelpView = 'main' | 'faq' | 'chat';

const MainMenuItem: React.FC<{ icon: React.ElementType, title: string, subtitle: string, onClick: () => void }> = ({ icon: Icon, title, subtitle, onClick }) => (
    <button onClick={onClick} className="w-full flex items-center p-3 text-left rounded-lg hover:bg-slate-100 transition-colors">
        <div className="bg-sky-100 text-sky-600 p-2 rounded-lg mr-4">
            <Icon className="w-6 h-6" />
        </div>
        <div className="flex-grow">
            <p className="font-semibold text-slate-800">{title}</p>
            <p className="text-xs text-slate-500">{subtitle}</p>
        </div>
        <ChevronRightIcon className="w-5 h-5 text-slate-400" />
    </button>
);

const FaqView: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [openFaqId, setOpenFaqId] = useState<string | null>(null);

    const filteredFaqs = useMemo(() => {
        if (!searchTerm) return MOCK_FAQS;
        return MOCK_FAQS.filter(faq => 
            faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
            faq.answer.toLowerCase().includes(searchTerm.toLowerCase()) ||
            faq.keywords.some(k => k.toLowerCase().includes(searchTerm.toLowerCase()))
        );
    }, [searchTerm]);

    const toggleFaq = (id: string) => {
        setOpenFaqId(prevId => prevId === id ? null : id);
    };

    return (
        <div className="flex flex-col h-full">
            <input
                type="text"
                placeholder="Search for answers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-md mb-4 text-sm"
            />
            <div className="flex-grow overflow-y-auto pr-2">
                {filteredFaqs.length > 0 ? (
                    <div className="space-y-2">
                        {filteredFaqs.map(faq => (
                            <div key={faq.id} className="border-b border-slate-200">
                                <button onClick={() => toggleFaq(faq.id)} className="w-full flex justify-between items-center text-left py-2">
                                    <span className="font-medium text-slate-700 text-sm">{faq.question}</span>
                                    <ChevronRightIcon className={`w-4 h-4 text-slate-500 transition-transform ${openFaqId === faq.id ? 'rotate-90' : ''}`} />
                                </button>
                                {openFaqId === faq.id && (
                                    <div className="p-2 text-sm text-slate-600 bg-slate-50 rounded-b-md">
                                        {faq.answer}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-center text-slate-500 text-sm py-4">No results found for "{searchTerm}".</p>
                )}
            </div>
        </div>
    );
};


const HelpWidget: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [view, setView] = useState<HelpView>('main');

    const handleClose = () => setIsOpen(false);

    const renderView = () => {
        switch (view) {
            case 'faq':
                return <FaqView />;
            case 'chat':
                return <AIChatView />;
            case 'main':
            default:
                return (
                    <div className="space-y-2">
                        <MainMenuItem icon={ChatBubbleLeftRightIcon} title="Chat with AI Assistant" subtitle="Get instant answers from our AI" onClick={() => setView('chat')} />
                        <MainMenuItem icon={BookOpenIcon} title="Search the FAQ" subtitle="Find answers to common questions" onClick={() => setView('faq')} />
                        <MainMenuItem icon={TicketIcon} title="Create a Support Ticket" subtitle="Report an issue to our team" onClick={() => alert('Feature in development. This would open a support ticket form.')} />
                        <MainMenuItem icon={LightbulbIcon} title="Request a Feature" subtitle="Have an idea? Let us know!" onClick={() => alert('Feature in development. This would open a feature request form.')} />
                    </div>
                );
        }
    };

    const getTitle = () => {
        switch (view) {
            case 'faq': return 'Frequently Asked Questions';
            case 'chat': return 'AI Support Assistant';
            case 'main':
            default: return 'Help & Support';
        }
    };
    
    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-5 right-5 bg-sky-600 text-white rounded-full p-3 shadow-lg hover:bg-sky-700 transition-all duration-300 transform hover:scale-110 z-[1000]"
                aria-label="Open help and support widget"
            >
                <QuestionMarkCircleIcon className="w-8 h-8" />
            </button>
            {isOpen && (
                <div 
                    className="fixed inset-0 bg-black bg-opacity-30 z-[1001]"
                    onClick={handleClose}
                >
                    <div
                        onClick={(e) => e.stopPropagation()}
                        className="fixed bottom-5 right-5 w-[90vw] max-w-sm h-[70vh] max-h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-slideUp"
                    >
                         <style>{`
                            @keyframes slideUp {
                                from { transform: translateY(30px); opacity: 0; }
                                to { transform: translateY(0); opacity: 1; }
                            }
                            .animate-slideUp { animation: slideUp 0.3s ease-out forwards; }
                        `}</style>
                        <header className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0">
                            {view !== 'main' && (
                                <button onClick={() => setView('main')} className="text-slate-500 hover:text-slate-800 p-1 -ml-1">
                                    <ArrowLeftIcon className="w-5 h-5" />
                                </button>
                            )}
                            <h2 className={`text-lg font-semibold text-slate-800 ${view === 'main' ? 'w-full text-left' : ''}`}>{getTitle()}</h2>
                            <button onClick={handleClose} className="text-slate-500 hover:text-slate-800 p-1">
                                <CloseIcon className="w-5 h-5" />
                            </button>
                        </header>
                        <main className="p-4 flex-grow overflow-y-auto">
                           {renderView()}
                        </main>
                         <footer className="p-3 bg-slate-50 text-center text-xs text-slate-400 border-t border-slate-200">
                           Powered by FinValidator Pro Support
                        </footer>
                    </div>
                </div>
            )}
        </>
    );
};

export default HelpWidget;