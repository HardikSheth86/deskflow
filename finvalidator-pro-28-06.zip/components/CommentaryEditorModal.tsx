import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { Commentary, CommentaryTemplate, CommentarySection, CommentaryType, BusinessArea } from '../types';
import { LightbulbIcon, QuillPenIcon } from './icons';

interface CommentaryEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (commentary: Commentary) => void;
  businessArea: BusinessArea;
  existingCommentary?: Commentary | null;
  template?: CommentaryTemplate | null; // Used when creating new from template
}

const CommentaryEditorModal: React.FC<CommentaryEditorModalProps> = ({
  isOpen,
  onClose,
  onSave,
  businessArea,
  existingCommentary,
  template,
}) => {
  const [title, setTitle] = useState('');
  const [commentaryType, setCommentaryType] = useState<CommentaryType | ''>('');
  const [sections, setSections] = useState<CommentarySection[]>([]);
  const [linkedItems, setLinkedItems] = useState('');
  const [tags, setTags] = useState('');

  useEffect(() => {
    if (existingCommentary) {
      setTitle(existingCommentary.title);
      setCommentaryType(existingCommentary.type);
      setSections(existingCommentary.sections.map(s => ({ ...s }))); // Deep copy
      setLinkedItems(existingCommentary.linkedItems?.join(', ') || '');
      setTags(existingCommentary.tags?.join(', ') || '');
    } else if (template) {
      setTitle(`New ${template.name}`);
      setCommentaryType(template.type);
      const newSections: CommentarySection[] = template.defaultSections.map(sec => ({
        title: sec.title,
        userContent: '',
        aiSuggestion: sec.aiPlaceholder || 'AI suggestions for this section will appear here. For example...'
      }));
      setSections(newSections);
      setLinkedItems('');
      setTags('');
    } else {
      // Reset for a completely new, untemplated commentary (if ever needed)
      setTitle('');
      setCommentaryType('');
      setSections([{ title: 'General Commentary', userContent: '', aiSuggestion: 'AI suggestions...' }]);
      setLinkedItems('');
      setTags('');
    }
  }, [isOpen, existingCommentary, template]);

  const handleSectionChange = (index: number, userContent: string) => {
    const newSections = [...sections];
    newSections[index].userContent = userContent;
    setSections(newSections);
  };

  const handleSave = () => {
    if (!title.trim()) {
      alert('Commentary title cannot be empty.');
      return;
    }
    if (!commentaryType) {
        alert('Please select a commentary type.');
        return;
    }

    const finalCommentary: Commentary = {
      id: existingCommentary?.id || `COM-${Date.now()}`,
      type: commentaryType,
      title: title.trim(),
      author: 'Valerie User', // Mock user
      dateCreated: existingCommentary?.dateCreated || new Date().toISOString(),
      businessArea,
      sections,
      linkedItems: linkedItems.split(',').map(item => item.trim()).filter(Boolean),
      tags: tags.split(',').map(tag => tag.trim()).filter(Boolean),
    };
    onSave(finalCommentary);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={existingCommentary ? 'Edit Commentary' : 'Create New Commentary'} size="xl">
      <div className="space-y-6 text-sm">
        <div>
          <label htmlFor="commentary-title" className="block text-sm font-medium text-slate-700 mb-1">
            Commentary Title
          </label>
          <input
            type="text"
            id="commentary-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
            placeholder="Enter commentary title..."
          />
        </div>

        {template && !existingCommentary && (
             <div className="p-3 bg-sky-50 border border-sky-200 rounded-md">
                <p className="text-sm font-semibold text-sky-700">Using Template: {template.name}</p>
                <p className="text-xs text-sky-600">{template.description}</p>
             </div>
        )}
         {existingCommentary && (
             <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <p className="text-sm font-semibold text-slate-700">Type: {existingCommentary.type}</p>
             </div>
        )}


        {sections.map((section, index) => (
          <div key={index} className="space-y-2 p-3 border border-slate-200 rounded-md bg-white">
            <label htmlFor={`section-content-${index}`} className="block text-md font-semibold text-slate-700 flex items-center">
                <QuillPenIcon className="w-5 h-5 mr-2 text-sky-600"/> {section.title}
            </label>
            <textarea
              id={`section-content-${index}`}
              value={section.userContent}
              onChange={(e) => handleSectionChange(index, e.target.value)}
              rows={4}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
              placeholder={`Enter content for ${section.title}...`}
            />
            {section.aiSuggestion && (
              <div className="mt-1 p-2 bg-sky-50 border border-sky-100 rounded-md">
                <p className="text-xs font-medium text-sky-700 flex items-center">
                  <LightbulbIcon className="w-4 h-4 mr-1.5 text-yellow-500" />
                  AI Suggestion Placeholder:
                </p>
                <p className="text-xs text-slate-600 italic ml-5">{section.aiSuggestion}</p>
              </div>
            )}
          </div>
        ))}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="linked-items" className="block text-sm font-medium text-slate-700 mb-1">
              Link to Items (IDs, comma-separated)
            </label>
            <input
              type="text"
              id="linked-items"
              value={linkedItems}
              onChange={(e) => setLinkedItems(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
              placeholder="e.g., EXC001, POS456"
            />
          </div>
          <div>
            <label htmlFor="tags" className="block text-sm font-medium text-slate-700 mb-1">
              Tags (comma-separated)
            </label>
            <input
              type="text"
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
              placeholder="e.g., volatility, month-end"
            />
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 border-t pt-4">
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium"
          >
            {existingCommentary ? 'Save Changes' : 'Create Commentary'}
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium"
          >
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default CommentaryEditorModal;
