
import React from 'react';
import { useAppContext } from '../hooks/useAppContext';

const Header: React.FC = () => {
  const { currentPageTitle } = useAppContext();

  return (
    <header className="bg-white shadow-sm p-4">
      <div className="flex justify-start items-center"> {/* Changed justify-between to justify-start */}
        <h1 className="text-2xl font-semibold text-slate-700">{currentPageTitle}</h1>
      </div>
    </header>
  );
};

export default Header;
