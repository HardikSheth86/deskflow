import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { PreSignOffTask, PreSignOffTaskStatus } from '../types';
import { InformationCircleIcon, UsersIcon, CheckCircleIcon, XCircleIcon, ListBulletIcon, CloseIcon, SaveIcon } from './icons';
import StatusPill from './StatusPill';

interface PreSignOffTaskDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: PreSignOffTask | null;
  onUpdateTask: (updatedTask: PreSignOffTask) => void;
}

const PreSignOffTaskDetailModal: React.FC<PreSignOffTaskDetailModalProps> = ({ isOpen, onClose, task, onUpdateTask }) => {
  const [assignedTo, setAssignedTo] = useState('');

  useEffect(() => {
    if (task) {
        setAssignedTo(task.assignedToUser || '');
    }
  }, [task]);


  if (!isOpen || !task) return null;

  const handleSaveChanges = () => {
    onUpdateTask({ ...task, assignedToUser: assignedTo });
    onClose();
  };
  
  const getStatusIcon = (status: PreSignOffTaskStatus) => {
    switch (status) {
      case PreSignOffTaskStatus.COMPLETED_OK: return <CheckCircleIcon className="w-5 h-5 text-green-600" />;
      case PreSignOffTaskStatus.COMPLETED_BREAKS: return <InformationCircleIcon className="w-5 h-5 text-yellow-600" />;
      case PreSignOffTaskStatus.FAILED: 
      case PreSignOffTaskStatus.REQUIRES_ATTENTION: return <XCircleIcon className="w-5 h-5 text-red-600" />;
      default: return <InformationCircleIcon className="w-5 h-5 text-slate-500" />;
    }
  };
  
  const getSeverityPill = (severity: 'High' | 'Medium' | 'Low') => {
    switch (severity) {
        case 'High': return 'bg-red-100 text-red-700';
        case 'Medium': return 'bg-yellow-100 text-yellow-700';
        case 'Low': return 'bg-green-100 text-green-700';
        default: return 'bg-slate-100 text-slate-700';
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Task Details: ${task.title}`} size="xl">
      <div className="space-y-5 text-sm">
        {/* Task Info Section */}
        <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-2 flex items-center">
            {getStatusIcon(task.status)}
            <span className="ml-2">{task.title}</span>
          </h3>
          <p className="text-slate-600 mb-1">{task.description}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 text-xs">
            <div><strong>Status:</strong> <StatusPill status={task.status} /></div>
            <div><strong>Responsible Team:</strong> {task.responsibleTeam || 'N/A'}</div>
            {task.lastRun && <div><strong>Last Run:</strong> {new Date(task.lastRun).toLocaleString()}</div>}
            {task.breakCount !== undefined && <div><strong>Breaks Found:</strong> {task.breakCount}</div>}
          </div>
        </div>

        {/* Break Details Section */}
        {task.breakDetails && task.breakDetails.length > 0 && (
          <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm">
            <h4 className="text-md font-semibold text-slate-700 mb-2 flex items-center">
              <ListBulletIcon className="w-5 h-5 mr-2 text-red-600" />
              Identified Breaks ({task.breakCount})
            </h4>
            <div className="max-h-48 overflow-y-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase">Break ID</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase">Description</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase hidden sm:table-cell">Related Entity</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase">Severity</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100">
                  {task.breakDetails.map((detail) => (
                    <tr key={detail.id}>
                      <td className="px-3 py-2 whitespace-nowrap text-sky-600 font-medium">{detail.id}</td>
                      <td className="px-3 py-2">{detail.description}</td>
                      <td className="px-3 py-2 whitespace-nowrap hidden sm:table-cell">{detail.relatedEntity || 'N/A'}</td>
                      <td className="px-3 py-2 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${getSeverityPill(detail.severity)}`}>
                            {detail.severity}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* Assignment Section */}
        <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm">
          <h4 className="text-md font-semibold text-slate-700 mb-2 flex items-center">
            <UsersIcon className="w-5 h-5 mr-2 text-sky-600" />
            Assignment
          </h4>
           <label htmlFor="assign-to" className="block text-sm font-medium text-slate-600 mb-1">Assigned To User/Sub-team:</label>
           <input 
              id="assign-to"
              type="text"
              value={assignedTo}
              onChange={(e) => setAssignedTo(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
              placeholder="e.g., Alice Analyst, Equity Ops Team"
            />
          <p className="text-xs text-slate-500 mt-2">Update the assignment for this specific task. The responsible team is '{task.responsibleTeam}'.</p>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 border-t pt-4">
           <button
            onClick={handleSaveChanges}
            className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center"
          >
            <SaveIcon className="w-5 h-5 mr-1.5"/> Save Changes
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium flex items-center"
          >
            <CloseIcon className="w-5 h-5 mr-1.5"/> Close
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default PreSignOffTaskDetailModal;