import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from '../types';
import { PaperAirplaneIcon, UserCircleIcon, CpuChipIcon } from './icons';

// IMPORTANT: In a real-world application, the API key should never be stored in the frontend.
// It should be handled via a secure backend proxy. This is for demonstration purposes only.
const API_KEY = process.env.API_KEY;

const AIChatView: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages, isLoading]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = {
            id: `msg-${Date.now()}`,
            text: input,
            sender: 'user',
            timestamp: new Date().toISOString()
        };

        setMessages(prev => [...prev, userMessage]);
        const currentInput = input;
        setInput('');
        setIsLoading(true);
        setError(null);
        
        if (!API_KEY) {
            setError("API key is not configured. This is a mock response.");
            const mockResponse: ChatMessage = {
                id: `msg-${Date.now() + 1}`,
                text: "This is a mock response because the API key is missing. In a real scenario, I would answer your question about the application based on your input.",
                sender: 'ai',
                timestamp: new Date().toISOString(),
            };
            setTimeout(() => {
                 setMessages(prev => [...prev, mockResponse]);
                 setIsLoading(false);
            }, 1000);
            return;
        }

        try {
            const ai = new GoogleGenAI({ apiKey: API_KEY });
            
            // Constructing history for the chat context
            const contents = messages.map(msg => ({
                role: msg.sender === 'user' ? 'user' : 'model',
                parts: [{ text: msg.text }]
            }));
            contents.push({ role: 'user', parts: [{ text: currentInput }] });

            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: contents,
                config: {
                    systemInstruction: `You are an expert AI assistant for a financial application called "FinValidator Pro". 
                    Your purpose is to help users understand and use the application. Be concise and clear.
                    The application has the following features: Dashboard, Exception Summary, Adjustments, Pre-Sign Off, Sign-Off, Commentary, Analytics, Investigation, Trader Review, and Management.
                    A user might ask about how to perform a task, like "how do I sign off?" or "what is an exception?". Answer based on the application's features.
                    Keep responses helpful and focused on the FinValidator Pro application. Do not go off-topic.`
                }
            });

            const text = response.text;

            const aiMessage: ChatMessage = {
                id: `msg-${Date.now() + 1}`,
                text: text,
                sender: 'ai',
                timestamp: new Date().toISOString(),
            };
            setMessages(prev => [...prev, aiMessage]);
        } catch (e) {
            console.error("Gemini API error:", e);
            setError("Sorry, I couldn't connect to the AI assistant. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-white text-sm">
            <div className="flex-grow p-1 space-y-4 overflow-y-auto">
                {messages.map((msg, index) => (
                    <div key={msg.id} className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                        {msg.sender === 'ai' && (
                            <div className="flex-shrink-0 bg-slate-200 text-slate-600 p-1.5 rounded-full">
                                <CpuChipIcon className="w-5 h-5" />
                            </div>
                        )}
                        <div className={`flex flex-col w-full max-w-[320px] leading-1.5 p-3 border-slate-200 ${
                            msg.sender === 'user' 
                                ? 'rounded-s-xl rounded-ee-xl bg-sky-500 text-white' 
                                : 'rounded-e-xl rounded-es-xl bg-slate-100 text-slate-800'
                        }`}>
                            <p className="font-normal">{msg.text}</p>
                        </div>
                        {msg.sender === 'user' && (
                           <div className="flex-shrink-0 bg-sky-500 text-white p-1.5 rounded-full">
                                <UserCircleIcon className="w-5 h-5" />
                            </div>
                        )}
                    </div>
                ))}
                {isLoading && (
                     <div className="flex items-start gap-2.5">
                         <div className="flex-shrink-0 bg-slate-200 text-slate-600 p-1.5 rounded-full">
                             <CpuChipIcon className="w-5 h-5" />
                         </div>
                         <div className="flex flex-col w-full max-w-[320px] leading-1.5 p-3 border-slate-200 rounded-e-xl rounded-es-xl bg-slate-100 text-slate-800">
                           <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse"></div>
                                <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse" style={{animationDelay: '0.2s'}}></div>
                                <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse" style={{animationDelay: '0.4s'}}></div>
                           </div>
                         </div>
                     </div>
                )}
                {error && <p className="text-red-500 text-xs text-center">{error}</p>}
                <div ref={messagesEndRef} />
            </div>
            <div className="p-2 border-t border-slate-200 flex items-center">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask a question..."
                    className="flex-grow w-full p-2 border border-slate-300 rounded-lg focus:ring-sky-500 focus:border-sky-500 text-sm"
                    disabled={isLoading}
                />
                <button
                    onClick={handleSend}
                    disabled={isLoading || !input.trim()}
                    className="ml-2 p-2 bg-sky-600 text-white rounded-lg disabled:bg-sky-300 disabled:cursor-not-allowed hover:bg-sky-700 transition-colors"
                    aria-label="Send message"
                >
                    <PaperAirplaneIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
};

export default AIChatView;