import React from 'react';

/**
 * Enumeration of the primary business areas within the firm.
 * @enum {string}
 */
export enum BusinessArea {
  EQUITIES = 'Equities',
  FIXED_INCOME = 'Fixed Income',
  PRIME_BROKERAGE = 'Prime Brokerage',
  COMMODITIES = 'Commodities',
}

/**
 * Represents the high-level status of a sign-off entity.
 * @enum {string}
 */
export enum ProcessStatus {
  IN_PROGRESS = 'In Progress',
  AWAITING_SIGN_OFF = 'Awaiting Sign-off',
  SIGNED_OFF = 'Signed Off',
  REJECTED = 'Rejected',
}

/**
 * Defines a single stage in the daily validation process timeline.
 * @interface ProcessStage
 */
export interface ProcessStage {
  id: string;
  name: string;
  completedAt: string | null;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
}

/**
 * Represents a Key Performance Indicator (KPI) displayed on the dashboard.
 * @interface KPI
 */
export interface KPI {
  label: string;
  value: string;
  variance: string;
  varianceType: 'positive' | 'negative' | 'neutral';
}

/**
 * Enumeration of the categories for financial exceptions.
 * @enum {string}
 */
export enum ExceptionCategory {
  FOBO = 'FOBO',
  VRS = 'VRS',
  DOD = 'DOD',
  ATTRIBUTION = 'Attribution',
  CUSTOM_RULES = 'Custom Rules',
}

/**
 * Represents the lifecycle status of a single exception.
 * @enum {string}
 */
export enum ExceptionStatus {
  OPEN = 'Open',
  IN_REVIEW = 'In Review',
  PENDING_ADJUSTMENT = 'Pending Adjustment',
  RESOLVED = 'Resolved',
  CLOSED = 'Closed',
}

/**
 * Defines the structure for a financial exception.
 * An exception represents a quantifiable break or discrepancy that needs investigation.
 * @interface Exception
 * @property {string} id - The unique identifier for the exception.
 * @property {ExceptionCategory} category - The category of the exception.
 * @property {string} positionId - The identifier of the associated position or instrument.
 * @property {number} financialImpact - The monetary value of the exception's impact.
 * @property {string} currency - The currency of the financial impact.
 * @property {string} description - A human-readable description of the exception.
 * @property {ExceptionStatus} status - The current status in the resolution workflow.
 * @property {string} [assignedTo] - The user or team the exception is assigned to.
 * @property {string} [rcaCommentary] - The root cause analysis commentary provided by a user.
 * @property {string} [aiRcaCommentary] - The root cause analysis commentary suggested by the AI.
 * @property {string} dateIdentified - The date the exception was first identified.
 * @property {BusinessArea} businessArea - The business area the exception belongs to.
 * @property {Record<string, string | number>} [details] - A key-value map of underlying data points.
 * @property {{ timestamp: string; action: string; user: string }[]} [history] - An audit trail of actions taken on the exception.
 */
export interface Exception {
  id: string;
  category: ExceptionCategory;
  positionId: string;
  financialImpact: number;
  currency: string;
  description: string;
  status: ExceptionStatus;
  assignedTo?: string;
  rcaCommentary?: string;
  aiRcaCommentary?: string;
  dateIdentified: string;
  businessArea: BusinessArea;
  details?: Record<string, string | number>;
  history?: { timestamp: string; action: string; user: string }[];
}

/**
 * Represents a single entry in an activity log.
 * @interface ActivityLogItem
 */
export interface ActivityLogItem {
  id: string;
  timestamp: string;
  type: 'Trade' | 'Adjustment' | 'FX Reval' | 'Fee' | 'System' | 'Commentary';
  description: string;
  financialImpact?: { 
    amount: number; 
    currency: string; 
    pnlEffect?: number; 
    assetEffect?: number; 
    liabilityEffect?: number 
  };
  user?: string;
}

/**
 * Represents a detailed trading strategy, which is a sub-component of a SignOffProductLine.
 * This is the lowest level of sign-off granularity.
 * @interface SignOffStrategy
 */
export interface SignOffStrategy {
  id: string;
  name: string;
  parentId: string;
  status: ProcessStatus;
  lastUpdated: string;
  currency: string;
  businessArea: BusinessArea;
  currentNetPnL: number;
  previousNetPnL: number;
  currentTotalAssets: number;
  previousTotalAssets: number;
  currentTotalLiabilities: number;
  previousTotalLiabilities: number;
  pnlTrading: number;
  pnlFxReval: number;
  pnlAdjustments: number;
  assetChangeTrading: number;
  assetChangeFxReval: number;
  assetChangeAdjustments: number;
  liabilityChangeTrading: number;
  liabilityChangeFxReval: number;
  liabilityChangeAdjustments: number;
  activityLog: ActivityLogItem[];
}

/**
 * Represents a major product line that requires sign-off.
 * It is composed of one or more `SignOffStrategy` items.
 * @interface SignOffProductLine
 * @property {string} id - The unique identifier for the product line.
 * @property {string} name - The human-readable name of the product line.
 * @property {BusinessArea} businessArea - The business area it belongs to.
 * @property {ProcessStatus} status - The current sign-off status of the product line.
 * @property {number} currentNetPnL - The aggregated current day Net P&L.
 * @property {SignOffStrategy[]} strategies - The list of underlying strategies that roll up into this product line.
 */
export interface SignOffProductLine {
  id: string;
  name: string;
  businessArea: BusinessArea;
  status: ProcessStatus;
  lastUpdated: string;
  currency: string;
  currentNetPnL: number;
  previousNetPnL: number;
  currentTotalAssets: number;
  previousTotalAssets: number;
  currentTotalLiabilities: number;
  previousTotalLiabilities: number;
  strategies: SignOffStrategy[];
}

/**
 * Represents a navigation item in the application's main navigation.
 * @interface NavItemType
 */
export interface NavItemType {
  path: string;
  name: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
}

/**
 * Enumeration of the types of financial adjustments that can be made.
 * @enum {string}
 */
export enum AdjustmentType {
  PNL_CORRECTION = 'P&L Correction',
  BS_REALIGNMENT = 'Balance Sheet Realignment',
  FEE_POSTING = 'Fee Posting',
  WASH_ACCOUNT_CLEARING = 'Wash Account Clearing',
  TRADE_AMENDMENT = 'Trade Amendment',
  FINANCING_PNL_FLATTENING = 'Financing PNL Flattening',
  OVER_UNDER_ACCRUAL = 'Over/Under Accrual',
  ATTRIBUTION_ADJUSTMENT = 'Attribution Adjustment',
  OTHER = 'Other',
}

/**
 * Represents the status of an adjustment in its approval workflow.
 * @type {string}
 */
export type AdjustmentStatus = 'DRAFT' | 'PENDING_REVIEW' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'CANCELLED';

/**
 * Defines the structure for a financial adjustment.
 * Adjustments are formal accounting entries to correct or align financial records.
 * @interface Adjustment
 * @property {string} id - The unique identifier for the adjustment.
 * @property {string} [relatedExceptionId] - Optional ID of an exception this adjustment resolves.
 * @property {AdjustmentType} type - The category of the adjustment.
 * @property {number} amount - The monetary value of the adjustment.
 * @property {string} debitAccount - The account to be debited.
 * @property {string} creditAccount - The account to be credited.
 * @property {string} justification - The reason for the adjustment.
 * @property {AdjustmentStatus} status - The current status in the approval workflow.
 * @property {string} [suggestedJustification] - AI-suggested justification text.
 */
export interface Adjustment {
  id: string;
  relatedExceptionId?: string;
  type: AdjustmentType;
  amount: number;
  currency: string;
  debitAccount: string;
  creditAccount: string;
  justification: string;
  status: AdjustmentStatus;
  createdBy: string;
  createdAt: string;
  businessArea: BusinessArea;
  lastModifiedAt?: string;
  submittedBy?: string;
  submittedAt?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  suggestedAmount?: number;
  suggestedCurrency?: string;
  suggestedDebitAccount?: string;
  suggestedCreditAccount?: string;
  suggestedJustification?: string;
}

/**
 * Defines the shape of the global application context.
 * This context provides access to centralized state and updater functions.
 * @interface AppContextType
 */
export interface AppContextType {
  currentBusinessArea: BusinessArea;
  setCurrentBusinessArea: (area: BusinessArea) => void;
  currentPageTitle: string;
  setCurrentPageTitle: (title: string) => void;
  
  // Centralized State
  exceptions: Exception[];
  adjustments: Adjustment[];
  productLinesByArea: Record<BusinessArea, SignOffProductLine[]>;
  commentaries: Commentary[];
  preSignOffTasksByArea: Record<BusinessArea, PreSignOffTask[]>;

  // Updater Functions
  updateException: (updatedException: Exception) => void;
  updateMultipleExceptions: (updatedExceptions: Exception[]) => void;
  saveAdjustment: (adjustmentToSave: Adjustment) => void;
  updateSignOffStatus: (itemId: string, level: 'ProductLine' | 'Strategy', newStatus: ProcessStatus, approved: boolean) => void;
  saveCommentary: (commentaryToSave: Commentary) => void;
  updatePreSignOffTask: (updatedTask: PreSignOffTask) => void;
}

/**
 * Defines an item within a context menu.
 * @interface ContextMenuItemType
 */
export interface ContextMenuItemType {
  label?: string;
  icon?: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  onClick?: () => void;
  disabled?: boolean;
  isSeparator?: boolean;
}

export interface PositionDrillDownInfo {
  positionId: string;
  marketValue: string;
  quantity: number;
  costBasis: string;
  lastPrice: string;
  unrealizedPnL: string;
  relatedBook: string;
  assetClass: string;
}

export interface TradeDrillDownInfo {
  tradeId: string;
  timestamp: string;
  quantity: number;
  price: number;
  currency: string;
  direction: 'Buy' | 'Sell';
  counterparty: string;
  relatedExceptionId: string;
}

export type DrillDownContentType = 
  | { type: 'position'; data: PositionDrillDownInfo }
  | { type: 'trades'; data: TradeDrillDownInfo[] };

/**
 * Enumeration of the types of commentaries that can be created.
 * @enum {string}
 */
export enum CommentaryType {
  MARKET = 'Market Commentary',
  OPERATIONAL_RISK = 'Operational Risk Commentary',
  BALANCE_SHEET_FLUCTUATION = 'Balance Sheet Fluctuation Commentary',
  T0_T1_COMMENTARY = 'T0/T1 Commentary',
  DAILY_TRADER_PACK = 'Daily Trader Pack',
}

/**
 * Represents a single section within a commentary, which includes user content and an optional AI suggestion.
 * @interface CommentarySection
 */
export interface CommentarySection {
  title: string;
  userContent: string;
  aiSuggestion?: string;
}

/**
 * Defines the structure for a commentary document.
 * @interface Commentary
 */
export interface Commentary {
  id: string;
  type: CommentaryType;
  title: string;
  author: string;
  dateCreated: string;
  businessArea: BusinessArea;
  sections: CommentarySection[];
  linkedItems?: string[];
  tags?: string[];
}

/**
 * Defines the structure for a commentary template, used to bootstrap new commentaries.
 * @interface CommentaryTemplate
 */
export interface CommentaryTemplate {
  type: CommentaryType;
  name: string;
  description: string;
  defaultSections: Array<{ title: string; aiPlaceholder?: string }>;
}

/**
 * Represents a distribution list for sending reports or notifications.
 * @interface DistributionList
 */
export interface DistributionList {
  id: string;
  name: string;
  description?: string;
}

/**
 * Represents the status of a pre-sign-off automated task.
 * @enum {string}
 */
export enum PreSignOffTaskStatus {
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  COMPLETED_OK = 'Completed - OK',
  COMPLETED_BREAKS = 'Completed - Breaks Found',
  FAILED = 'Failed',
  REQUIRES_ATTENTION = 'Requires Attention',
  ACKNOWLEDGED = 'Acknowledged',
}

/**
 * Represents a single break found during a pre-sign-off task.
 * @interface PreSignOffBreakDetail
 */
export interface PreSignOffBreakDetail {
  id: string;
  description: string;
  severity: 'High' | 'Medium' | 'Low';
  relatedEntity?: string;
}

/**
 * Represents a task in the pre-sign-off checklist.
 * @interface PreSignOffTask
 */
export interface PreSignOffTask {
  id: string;
  title: string;
  description: string;
  status: PreSignOffTaskStatus;
  businessArea: BusinessArea;
  lastRun?: string;
  lastUpdated?: string;
  breakCount?: number;
  detailsLink?: string;
  responsibleTeam?: string;
  assignedToUser?: string;
  breakDetails?: PreSignOffBreakDetail[];
}

/**
 * Represents a manual action that can be triggered from the pre-sign-off screen.
 * @interface PreSignOffAction
 */
export interface PreSignOffAction {
  id: string;
  title: string;
  description: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
  businessArea: BusinessArea;
  adjustmentType: AdjustmentType;
}

/**
 * Represents the P&L summary for a trader's personal dashboard.
 * @interface TraderPnlSummary
 */
export interface TraderPnlSummary {
  mtd: number;
  ytd: number;
  dod: number;
  currency: string;
}

/**
 * Represents the status of a deployment stage in a release train.
 * @enum {string}
 */
export enum DeploymentStatus {
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  SUCCESS = 'Success',
  FAILED = 'Failed',
}

/**
 * Represents a single stage in a deployment pipeline.
 * @interface DeploymentStage
 */
export interface DeploymentStage {
  name: string;
  status: DeploymentStatus;
  startedAt?: string;
  completedAt?: string;
}

/**
 * Represents a release train for software deployment tracking.
 * @interface ReleaseTrain
 */
export interface ReleaseTrain {
  id: string;
  name: string;
  version: string;
  status: 'Active' | 'Completed' | 'Rolled Back';
  stages: DeploymentStage[];
  deployedAt?: string;
}

/**
 * Represents a technology stack item for documentation.
 * @interface StackItem
 */
export interface StackItem {
  name: string;
  category: 'Frontend' | 'API' | 'Tooling' | 'Platform';
  description: string;
}

/**
 * Represents pre-trade approval details for a trade in the Investigation Workbench.
 * @interface PreTradeApprovalDetails
 */
export interface PreTradeApprovalDetails {
  approvalId: string;
  limitCheckStatus: 'Approved' | 'Breached';
  timestamp: string;
  checkedBy: string;
}

/**
 * Represents trade capture system details for a trade in the Investigation Workbench.
 * @interface TradeCaptureDetails
 */
export interface TradeCaptureDetails {
  bookingSystem: 'TradeMaster' | 'BookItAll';
  tradeTime: string;
  traderId: string;
  salesperson: string;
}

/**
 * Represents risk metrics for a trade in the Investigation Workbench.
 * @interface RiskDetails
 */
export interface RiskDetails {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  var99: number;
}

/**
 * Represents operations details for a trade in the Investigation Workbench.
 * @interface OpsDetails
 */
export interface OpsDetails {
  confirmationStatus: 'Confirmed' | 'Unconfirmed' | 'Mismatch';
  settlementStatus: 'Settled' | 'Unsettled' | 'Failed';
  settlementDate: string;
}

/**
 * Represents ledger details for a trade in the Investigation Workbench.
 * @interface LedgerDetails
 */
export interface LedgerDetails {
  journalId: string;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  currency: string;
  postingDate: string;
}

/**
 * Represents a comprehensive trade object for the Investigation Workbench.
 * @interface InvestigativeTrade
 */
export interface InvestigativeTrade {
  id: string;
  businessArea: BusinessArea;
  product: string;
  quantity: number;
  price: number;
  currency: string;
  status: 'Booked' | 'Amended' | 'Cancelled';
  tradeDate: string;
  preTrade: PreTradeApprovalDetails;
  tradeCapture: TradeCaptureDetails;
  risk: RiskDetails;
  ops: OpsDetails;
  ledger: LedgerDetails;
}

/**
 * Represents a single message in the AI chat widget.
 * @interface ChatMessage
 */
export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

/**
 * Represents a single FAQ item for the help widget.
 * @interface FAQ
 */
export interface FAQ {
  id: string;
  question: string;
  answer: string;
  keywords: string[];
}