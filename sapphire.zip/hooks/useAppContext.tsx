import { useContext } from 'react';
import { AppContext } from '../contexts/AppContext';
import { AppContextType } from '../types';

/**
 * A custom hook to consume the AppContext.
 * This is the standard way to access global state and updater functions.
 * Using this hook ensures that the context is consumed within a component
 * that is a descendant of `AppProvider`, throwing an error otherwise.
 * @returns {AppContextType} The value of the application context.
 * @throws {Error} If the hook is used outside of an `AppProvider`.
 */
export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
