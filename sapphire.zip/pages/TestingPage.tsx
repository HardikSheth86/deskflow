import React, { useEffect, useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { BeakerIcon, CheckCircleIcon, XCircleIcon } from '../components/icons';
import { formatCurrency, calculateDoDChange, determineProductLineStatus, formatDateDistance } from '../utils/helpers';
import { ExceptionStatus, ProcessStatus, SignOffStrategy, BusinessArea, Region, Adjustment, AdjustmentType, ExceptionCategory } from '../types';
import StatusPill from '../components/StatusPill';

interface TestResult {
    description: string;
    pass: boolean;
    error?: string;
}

const TestResultItem: React.FC<{ result: TestResult }> = ({ result }) => {
    return (
        <div className={`p-3 flex justify-between items-center border-l-4 ${result.pass ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
            <div>
                <p className={`font-semibold ${result.pass ? 'text-green-800' : 'text-red-800'}`}>{result.description}</p>
                {!result.pass && <p className="text-xs text-red-700 mt-1"><strong>Error:</strong> {result.error || 'Test failed without a specific error message.'}</p>}
            </div>
            {result.pass ? 
                <div className="flex items-center text-green-600">
                    <CheckCircleIcon className="w-5 h-5 mr-1" />
                    <span>PASS</span>
                </div>
                : 
                <div className="flex items-center text-red-600">
                    <XCircleIcon className="w-5 h-5 mr-1" />
                    <span>FAIL</span>
                </div>
            }
        </div>
    );
}

const TestingPage: React.FC = () => {
    const { setCurrentPageTitle, exceptions, updateException, saveAdjustment } = useAppContext();
    const [testResults, setTestResults] = useState<TestResult[]>([]);
    const [isRunning, setIsRunning] = useState(true);

    useEffect(() => {
        setCurrentPageTitle('Application Test Suite');
    }, [setCurrentPageTitle]);

    const runTests = () => {
        setIsRunning(true);
        const results: TestResult[] = [];

        // --- Utility Function Tests ---
        try {
            const formatted = formatCurrency(12345.67, 'USD');
            if (formatted === '$12,346') {
                results.push({ description: '`formatCurrency` should format and round correctly.', pass: true });
            } else {
                results.push({ description: '`formatCurrency` should format and round correctly.', pass: false, error: `Expected $12,346, got ${formatted}` });
            }
        } catch (e: any) {
            results.push({ description: '`formatCurrency` should format and round correctly.', pass: false, error: e.message });
        }

        try {
            const dod = calculateDoDChange(110, 100);
            if (dod.amount === 10 && dod.percentage === 10 && dod.isPositive) {
                results.push({ description: '`calculateDoDChange` should calculate positive change.', pass: true });
            } else {
                results.push({ description: '`calculateDoDChange` should calculate positive change.', pass: false, error: `Got amount: ${dod.amount}, percentage: ${dod.percentage}` });
            }
        } catch (e: any) {
            results.push({ description: '`calculateDoDChange` should calculate positive change.', pass: false, error: e.message });
        }

        try {
            const dateNow = new Date();
            const date5MinAgo = new Date(dateNow.getTime() - 5 * 60 * 1000).toISOString();
            const formatted = formatDateDistance(date5MinAgo);
            if (formatted.includes('minute')) {
                results.push({ description: '`formatDateDistance` should calculate relative time.', pass: true });
            } else {
                results.push({ description: '`formatDateDistance` should calculate relative time.', pass: false, error: `Expected minutes, got ${formatted}` });
            }
        } catch (e: any) {
             results.push({ description: '`formatDateDistance` should calculate relative time.', pass: false, error: e.message });
        }

        try {
            const statusAllSignedOff = determineProductLineStatus([ { status: ProcessStatus.SIGNED_OFF } ] as SignOffStrategy[]);
            const statusOneRejected = determineProductLineStatus([ { status: ProcessStatus.SIGNED_OFF }, { status: ProcessStatus.REJECTED } ] as SignOffStrategy[]);
            const statusInProgress = determineProductLineStatus([ { status: ProcessStatus.SIGNED_OFF }, { status: ProcessStatus.AWAITING_SIGN_OFF } ] as SignOffStrategy[]);

            if (statusAllSignedOff === ProcessStatus.AWAITING_SIGN_OFF && statusOneRejected === ProcessStatus.REJECTED && statusInProgress === ProcessStatus.IN_PROGRESS) {
                 results.push({ description: '`determineProductLineStatus` should correctly roll up status.', pass: true });
            } else {
                 results.push({ description: '`determineProductLineStatus` should correctly roll up status.', pass: false, error: `Expected Awaiting/Rejected/In Progress, got ${statusAllSignedOff}/${statusOneRejected}/${statusInProgress}` });
            }
        } catch (e: any) {
            results.push({ description: '`determineProductLineStatus` should correctly roll up status.', pass: false, error: e.message });
        }
        
        // --- Component Rendering Smoke Tests ---
        try {
            const Card = () => <DashboardCard title="Test">Child</DashboardCard>;
            Card(); // "Render"
            results.push({ description: 'Component Smoke Test: `DashboardCard` should render without crashing.', pass: true });
        } catch(e: any) {
            results.push({ description: 'Component Smoke Test: `DashboardCard` should render without crashing.', pass: false, error: e.message });
        }
        
        try {
            const Pill = () => <StatusPill status={ProcessStatus.SIGNED_OFF} />;
            Pill(); // "Render"
            results.push({ description: 'Component Smoke Test: `StatusPill` should render without crashing.', pass: true });
        } catch(e: any) {
             results.push({ description: 'Component Smoke Test: `StatusPill` should render without crashing.', pass: false, error: e.message });
        }

        // --- Context State Management Tests ---
        try {
            const testExceptionId = 'EXC001';
            const originalException = exceptions.find(ex => ex.id === testExceptionId);
            
            if (originalException) {
                const updatedException = { ...originalException, status: ExceptionStatus.RESOLVED };
                updateException(updatedException);
                results.push({ description: '`updateException` context function should be callable.', pass: true });
            } else {
                results.push({ description: '`updateException` context function should be callable.', pass: false, error: `Test exception with ID ${testExceptionId} not found.`});
            }
        } catch (e: any) {
            results.push({ description: '`updateException` context function should be callable.', pass: false, error: e.message });
        }
        
        try {
            const newAdjustment: Adjustment = {
                id: 'ADJ-TEST-123', type: AdjustmentType.OTHER, amount: 100, currency: 'USD', debitAccount: 'TEST_DR',
                creditAccount: 'TEST_CR', justification: 'Test adjustment', status: 'DRAFT', createdBy: 'Test Suite',
                createdAt: new Date().toISOString(), businessArea: BusinessArea.EQUITIES, productLineId: 'PL_EQ_US',
                strategyId: 'EQ_US_ALPHA', region: Region.NORTH_AMERICA
            };
            saveAdjustment(newAdjustment); // Calling the function
            results.push({ description: '`saveAdjustment` context function should be callable without error.', pass: true });
        } catch (e: any) {
             results.push({ description: '`saveAdjustment` context function should be callable without error.', pass: false, error: e.message });
        }
        
        // --- Filtering Logic Tests ---
        try {
            const foboExceptionsCount = exceptions.filter(ex => ex.category === ExceptionCategory.FOBO).length;
            if (foboExceptionsCount > 0) {
                 results.push({ description: 'Core Logic: Exception filtering by category.', pass: true, error: `Found ${foboExceptionsCount} items.` });
            } else {
                 results.push({ description: 'Core Logic: Exception filtering by category.', pass: false, error: 'No FOBO exceptions found to test filtering.' });
            }
        } catch (e: any) {
             results.push({ description: 'Core Logic: Exception filtering by category.', pass: false, error: e.message });
        }
        
        setTestResults(results);
        setIsRunning(false);
    };

    useEffect(() => {
        runTests();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // Run tests once on mount

    const passedCount = testResults.filter(r => r.pass).length;
    const failedCount = testResults.length - passedCount;

    return (
        <div className="space-y-6">
            <DashboardCard title={<div className="flex items-center"><BeakerIcon className="w-6 h-6 mr-2" /> Application Test Suite</div>}>
                <div className="flex justify-between items-center">
                    <p className="text-slate-600">
                        This page runs a series of automated unit and integration tests to verify core application functionality.
                    </p>
                    <button 
                        onClick={runTests} 
                        disabled={isRunning}
                        className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50"
                    >
                        {isRunning ? 'Running...' : 'Re-run Tests'}
                    </button>
                </div>
            </DashboardCard>

            <DashboardCard title="Test Results">
                <div className="flex justify-between items-center mb-4 p-3 bg-slate-50 rounded-lg">
                    <div className="text-lg font-semibold text-slate-700">
                        Summary: {testResults.length} tests run
                    </div>
                    <div className="flex space-x-4">
                        <span className="font-semibold text-green-600">Passed: {passedCount}</span>
                        <span className="font-semibold text-red-600">Failed: {failedCount}</span>
                    </div>
                </div>
                <div className="space-y-2">
                    {testResults.map((result, index) => (
                        <TestResultItem key={index} result={result} />
                    ))}
                </div>
                 {isRunning && <p className="text-center p-4 text-slate-500">Tests are running...</p>}
            </DashboardCard>
        </div>
    );
};

export default TestingPage;