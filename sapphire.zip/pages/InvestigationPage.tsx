import React, { useState, useMemo, useEffect, ReactNode } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { MOCK_INVESTIGATIVE_TRADES } from '../constants';
import { InvestigativeTrade, PreTradeApprovalDetails, TradeCaptureDetails, RiskDetails, OpsDetails, LedgerDetails } from '../types';
import DashboardCard from '../components/DashboardCard';
import { 
    MagnifyingGlassIcon, ShieldCheckIcon, 
    ArchiveBoxIcon, BeakerIcon, BriefcaseIcon, ReceiptPercentIcon,
    TableCellsIcon, UserCircleIcon
} from '../components/icons';
import StatusPill from '../components/StatusPill';

const DetailListItem: React.FC<{ label: string; value: React.ReactNode; }> = ({ label, value }) => (
    <div className="flex justify-between items-center py-2 px-2 border-b border-slate-100 text-sm">
        <span className="font-medium text-slate-600">{label}:</span>
        <div className="text-slate-800 text-right">{value}</div>
    </div>
);

const PreTradeView: React.FC<{ data: PreTradeApprovalDetails }> = ({ data }) => (
    <div className="space-y-1">
        <DetailListItem label="Approval ID" value={data.approvalId} />
        <DetailListItem label="Limit Check Status" value={<StatusPill status={data.limitCheckStatus} />} />
        <DetailListItem label="Timestamp" value={data.timestamp} />
        <DetailListItem label="Checked By" value={data.checkedBy} />
    </div>
);

const TradeCaptureView: React.FC<{ data: TradeCaptureDetails }> = ({ data }) => (
    <div className="space-y-1">
        <DetailListItem label="Booking System" value={data.bookingSystem} />
        <DetailListItem label="Trade Time" value={data.tradeTime} />
        <DetailListItem label="Trader ID" value={data.traderId} />
        <DetailListItem label="Salesperson" value={data.salesperson} />
    </div>
);

const RiskView: React.FC<{ data: RiskDetails }> = ({ data }) => (
     <div className="space-y-1">
        <DetailListItem label="Delta" value={data.delta.toLocaleString()} />
        <DetailListItem label="Gamma" value={data.gamma.toLocaleString()} />
        <DetailListItem label="Vega" value={data.vega.toLocaleString()} />
        <DetailListItem label="Theta" value={data.theta.toLocaleString()} />
        <DetailListItem label="99% VaR" value={data.var99.toLocaleString('en-US', { style: 'currency', currency: 'USD' })} />
    </div>
);

const OpsView: React.FC<{ data: OpsDetails }> = ({ data }) => (
    <div className="space-y-1">
        <DetailListItem label="Confirmation Status" value={<StatusPill status={data.confirmationStatus} />} />
        <DetailListItem label="Settlement Status" value={<StatusPill status={data.settlementStatus} />} />
        <DetailListItem label="Settlement Date" value={data.settlementDate} />
    </div>
);

const LedgerView: React.FC<{ data: LedgerDetails }> = ({ data }) => (
     <div className="space-y-1">
        <DetailListItem label="Journal ID" value={data.journalId} />
        <DetailListItem label="Debit Account" value={data.debitAccount} />
        <DetailListItem label="Credit Account" value={data.creditAccount} />
        <DetailListItem label="Amount" value={data.amount.toLocaleString('en-US', { style: 'currency', currency: data.currency })} />
        <DetailListItem label="Posting Date" value={data.postingDate} />
    </div>
);

const FullTradeDetailView: React.FC<{ trade: InvestigativeTrade }> = ({ trade }) => (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mt-6">
        <DashboardCard title={<div className="flex items-center"><ShieldCheckIcon className="w-5 h-5 mr-2" />Pre-Trade</div>}><PreTradeView data={trade.preTrade} /></DashboardCard>
        <DashboardCard title={<div className="flex items-center"><ArchiveBoxIcon className="w-5 h-5 mr-2" />Trade Capture</div>}><TradeCaptureView data={trade.tradeCapture} /></DashboardCard>
        <DashboardCard title={<div className="flex items-center"><BeakerIcon className="w-5 h-5 mr-2" />Risk</div>}><RiskView data={trade.risk} /></DashboardCard>
        <DashboardCard title={<div className="flex items-center"><BriefcaseIcon className="w-5 h-5 mr-2" />Ops</div>}><OpsView data={trade.ops} /></DashboardCard>
        <DashboardCard title={<div className="flex items-center"><ReceiptPercentIcon className="w-5 h-5 mr-2" />Ledger</div>}><LedgerView data={trade.ledger} /></DashboardCard>
    </div>
);

const systemViewConfig = {
    Risk: { icon: BeakerIcon, columns: [ { header: 'Delta', accessor: (t: InvestigativeTrade) => t.risk.delta.toLocaleString() }, { header: 'Gamma', accessor: (t: InvestigativeTrade) => t.risk.gamma.toLocaleString() }, { header: 'Vega', accessor: (t: InvestigativeTrade) => t.risk.vega.toLocaleString() }, { header: 'Theta', accessor: (t: InvestigativeTrade) => t.risk.theta.toLocaleString() }, { header: '99% VaR', accessor: (t: InvestigativeTrade) => t.risk.var99.toLocaleString('en-US', { style: 'currency', currency: 'USD' }) }, ] },
    PreTrade: { icon: ShieldCheckIcon, columns: [ { header: 'Approval ID', accessor: (t: InvestigativeTrade) => t.preTrade.approvalId }, { header: 'Limit Status', accessor: (t: InvestigativeTrade) => <StatusPill status={t.preTrade.limitCheckStatus} /> }, { header: 'Timestamp', accessor: (t: InvestigativeTrade) => t.preTrade.timestamp }, { header: 'Checked By', accessor: (t: InvestigativeTrade) => t.preTrade.checkedBy }, ] },
    TradeCapture: { icon: ArchiveBoxIcon, columns: [ { header: 'Booking System', accessor: (t: InvestigativeTrade) => t.tradeCapture.bookingSystem }, { header: 'Trade Time', accessor: (t: InvestigativeTrade) => t.tradeCapture.tradeTime }, { header: 'Trader ID', accessor: (t: InvestigativeTrade) => t.tradeCapture.traderId }, { header: 'Salesperson', accessor: (t: InvestigativeTrade) => t.tradeCapture.salesperson }, ] },
    Ops: { icon: BriefcaseIcon, columns: [ { header: 'Confirmation', accessor: (t: InvestigativeTrade) => <StatusPill status={t.ops.confirmationStatus} /> }, { header: 'Settlement', accessor: (t: InvestigativeTrade) => <StatusPill status={t.ops.settlementStatus} /> }, { header: 'Settlement Date', accessor: (t: InvestigativeTrade) => t.ops.settlementDate }, ] },
    Ledger: { icon: ReceiptPercentIcon, columns: [ { header: 'Journal ID', accessor: (t: InvestigativeTrade) => t.ledger.journalId }, { header: 'Debit Acc', accessor: (t: InvestigativeTrade) => t.ledger.debitAccount }, { header: 'Credit Acc', accessor: (t: InvestigativeTrade) => t.ledger.creditAccount }, { header: 'Amount', accessor: (t: InvestigativeTrade) => t.ledger.amount.toLocaleString('en-US', { style: 'currency', currency: t.ledger.currency }) }, { header: 'Posting Date', accessor: (t: InvestigativeTrade) => t.ledger.postingDate }, ] }
};
type SystemViewType = keyof typeof systemViewConfig;

const SystemViewDisplay: React.FC<{ trades: InvestigativeTrade[] }> = ({ trades }) => {
    const [systemViewType, setSystemViewType] = useState<SystemViewType>('Risk');
    const [filterTradeId, setFilterTradeId] = useState('');
    const [filterProduct, setFilterProduct] = useState('');

    const systemFilteredTrades = useMemo(() => {
        return trades.filter(trade =>
            (filterTradeId ? trade.id.toLowerCase().includes(filterTradeId.toLowerCase()) : true) &&
            (filterProduct ? trade.product.toLowerCase().includes(filterProduct.toLowerCase()) : true)
        );
    }, [trades, filterTradeId, filterProduct]);

    const currentSystemConfig = systemViewConfig[systemViewType];
    const inputStyles = "w-full p-2 border border-slate-300 rounded-md text-sm bg-slate-50 placeholder:text-slate-500 text-slate-800 focus:bg-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors";

    return (
        <div className="space-y-6">
            <DashboardCard title="System-wide Filter">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">System View</label>
                        <select value={systemViewType} onChange={(e) => setSystemViewType(e.target.value as SystemViewType)} className={inputStyles}>
                            {(Object.keys(systemViewConfig) as SystemViewType[]).map(key => <option key={key} value={key}>{key}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Filter by Trade ID</label>
                        <input type="text" placeholder="Contains..." value={filterTradeId} onChange={(e) => setFilterTradeId(e.target.value)} className={inputStyles} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Filter by Product</label>
                        <input type="text" placeholder="Contains..." value={filterProduct} onChange={(e) => setFilterProduct(e.target.value)} className={inputStyles} />
                    </div>
                </div>
            </DashboardCard>
            <DashboardCard title={<div className="flex items-center"><currentSystemConfig.icon className="w-5 h-5 mr-2" />{`${systemViewType} View (${systemFilteredTrades.length} trades)`}</div>}>
                <div className="overflow-x-auto rounded-lg border border-slate-200 max-h-[60vh]">
                    <table className="min-w-full divide-y divide-slate-200 text-sm">
                        <thead className="bg-slate-100 sticky top-0">
                            <tr>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Trade ID</th>
                                <th className="px-3 py-2 text-left font-semibold text-slate-600">Product</th>
                                {currentSystemConfig.columns.map(col => <th key={col.header} className="px-3 py-2 text-left font-semibold text-slate-600">{col.header}</th>)}
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-100">
                            {systemFilteredTrades.map(trade => (
                                <tr key={trade.id}>
                                    <td className="px-3 py-2 whitespace-nowrap font-medium text-sky-700">{trade.id}</td>
                                    <td className="px-3 py-2 whitespace-nowrap">{trade.product}</td>
                                    {currentSystemConfig.columns.map(col => <td key={col.header} className="px-3 py-2 whitespace-nowrap">{col.accessor(trade)}</td>)}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {systemFilteredTrades.length === 0 && <div className="text-center p-8 text-slate-500">No trades match the current filters.</div>}
                </div>
            </DashboardCard>
        </div>
    );
};

const TradeViewDisplay: React.FC<{ trades: InvestigativeTrade[] }> = ({ trades }) => {
    const [searchId, setSearchId] = useState('');
    const [searchedTrade, setSearchedTrade] = useState<InvestigativeTrade | null>(null);
    const { currentBusinessArea } = useAppContext(); // Get BA for default example

    useEffect(() => {
        const defaultTradeForArea = trades.find(t => t.businessArea === currentBusinessArea);
        if (defaultTradeForArea) {
            setSearchId(defaultTradeForArea.id);
            setSearchedTrade(defaultTradeForArea);
        } else {
            setSearchId('');
            setSearchedTrade(null);
        }
    }, [currentBusinessArea, trades]);

    const handleSearch = () => {
        if (!searchId) {
            setSearchedTrade(null);
            return;
        }
        const found = trades.find(t => t.id.toLowerCase() === searchId.toLowerCase());
        setSearchedTrade(found || null);
    };

    const inputStyles = "w-full p-2 border border-slate-300 rounded-md text-sm bg-slate-50 placeholder:text-slate-500 text-slate-800 focus:bg-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors";

    return (
        <div className="space-y-6">
            <DashboardCard title="Search by Trade ID">
                <p className="text-sm text-slate-500 mb-2">Enter a full Trade ID to see its lifecycle data. An example is shown below.</p>
                <div className="flex space-x-2">
                    <input type="text" placeholder="Enter Trade ID..." value={searchId} onChange={(e) => setSearchId(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()} className={inputStyles} />
                    <button onClick={handleSearch} className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 flex items-center">
                       <MagnifyingGlassIcon className="w-5 h-5 mr-2" /> Search
                    </button>
                </div>
            </DashboardCard>
            {searchedTrade ? (
                <FullTradeDetailView trade={searchedTrade} />
            ) : (
                searchId && <p className="text-center text-red-600 mt-4">No trade found with ID "{searchId}". Please try another ID.</p>
            )}
        </div>
    );
};

const InvestigationPage: React.FC = () => {
    const { 
        setCurrentPageTitle, 
        currentBusinessArea, 
        currentRegion, 
        currentProductLineId, 
        currentStrategyId 
    } = useAppContext();
    const [allTrades] = useState<InvestigativeTrade[]>(MOCK_INVESTIGATIVE_TRADES);
    const [viewMode, setViewMode] = useState<'system' | 'trade'>('trade');
    
    useEffect(() => {
        setCurrentPageTitle('Investigation Workbench');
    }, [setCurrentPageTitle]);

    const filteredTrades = useMemo(() => {
        return allTrades.filter(trade => 
            trade.businessArea === currentBusinessArea &&
            (currentRegion === 'ALL' || trade.region === currentRegion) &&
            (currentProductLineId === 'ALL' || trade.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || trade.strategyId === currentStrategyId)
        );
    }, [allTrades, currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId]);

    return (
        <div className="space-y-6">
            <DashboardCard title="Investigation Workbench">
                 <p className="text-slate-600 mb-4">
                    Select a view mode below to investigate trades either by system or by individual trade ID. Data is refined by the global filters.
                </p>
                <div className="flex space-x-2">
                    <button onClick={() => setViewMode('system')} className={`flex items-center px-4 py-2 rounded-md font-medium text-sm transition-colors ${viewMode === 'system' ? 'bg-sky-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}>
                       <TableCellsIcon className="w-5 h-5 mr-2" /> System View
                    </button>
                    <button onClick={() => setViewMode('trade')} className={`flex items-center px-4 py-2 rounded-md font-medium text-sm transition-colors ${viewMode === 'trade' ? 'bg-sky-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}>
                       <UserCircleIcon className="w-5 h-5 mr-2" /> Trade/Position View
                    </button>
                </div>
            </DashboardCard>

            {viewMode === 'system' && <SystemViewDisplay trades={filteredTrades} />}
            {viewMode === 'trade' && <TradeViewDisplay trades={filteredTrades} />}
        </div>
    );
};

export default InvestigationPage;
