import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Exception, ExceptionCategory, ExceptionStatus, ContextMenuItemType, Adjustment } from '../types';
import DashboardCard from '../components/DashboardCard';
import { EyeIcon, AdjustmentIcon, CheckCircleIcon, ShareIcon } from '../components/icons';
import ExceptionDetailModal from '../components/ExceptionDetailModal';
import ContextMenu from '../components/ContextMenu'; 
import AdjustmentModal from '../components/AdjustmentModal';
import StatusPill from '../components/StatusPill';

/**
 * Returns the Tailwind CSS classes for an exception row based on its category.
 * @param {ExceptionCategory} category - The category of the exception.
 * @returns {string} The corresponding CSS classes for border and background color.
 */
const getCategoryStyle = (category: ExceptionCategory) => {
    switch (category) {
        case ExceptionCategory.FOBO: return "border-red-500 bg-red-50";
        case ExceptionCategory.VRS: return "border-yellow-500 bg-yellow-50";
        case ExceptionCategory.DOD: return "border-purple-500 bg-purple-50";
        case ExceptionCategory.ATTRIBUTION: return "border-indigo-500 bg-indigo-50";
        case ExceptionCategory.CUSTOM_RULES: return "border-teal-500 bg-teal-50";
        default: return "border-gray-300 bg-gray-50";
    }
};

/**
 * @interface ExceptionRowProps
 * Defines the props for the ExceptionRow component.
 * @property {Exception} exception - The exception data for the row.
 * @property {boolean} isSelected - Whether the row is currently selected.
 * @property {(id: string, checked: boolean) => void} onToggleSelect - Callback for when the selection checkbox is changed.
 * @property {(event: React.MouseEvent, exception: Exception) => void} onContextMenu - Callback for when the row is right-clicked.
 * @property {(exception: Exception) => void} onViewDetails - Callback to view the full details of the exception.
 * @property {(exception: Exception) => void} onOpenAdjustmentModal - Callback to open the adjustment modal for the exception.
 */
interface ExceptionRowProps {
    exception: Exception;
    isSelected: boolean;
    onToggleSelect: (id: string, checked: boolean) => void;
    onContextMenu: (event: React.MouseEvent, exception: Exception) => void;
    onViewDetails: (exception: Exception) => void;
    onOpenAdjustmentModal: (exception: Exception) => void;
}

/**
 * A memoized component for rendering a single row in the exceptions table.
 * This prevents re-rendering of rows that haven't changed, improving performance on large lists.
 * @param {ExceptionRowProps} props - The props for the component.
 * @returns {JSX.Element} The rendered table row.
 */
const ExceptionRow = React.memo(({
    exception,
    isSelected,
    onToggleSelect,
    onContextMenu,
    onViewDetails,
    onOpenAdjustmentModal,
}: ExceptionRowProps) => {
    return (
        <tr 
            className={`hover:bg-sky-50 transition-colors cursor-context-menu ${getCategoryStyle(exception.category)} border-l-4 ${isSelected ? 'bg-sky-100' : ''}`}
            onContextMenu={(e) => onContextMenu(e, exception)}
        >
            <td className="px-4 py-3 whitespace-nowrap">
                <input 
                    type="checkbox"
                    className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                    checked={isSelected}
                    onChange={(e) => onToggleSelect(exception.id, e.target.checked)}
                    aria-label={`Select exception ${exception.id}`}
                />
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-sky-700">{exception.id}</td>
            <td className="px-4 py-3 whitespace-normal text-sm text-slate-600 max-w-sm truncate">{exception.description}</td>
            <td className={`px-4 py-3 whitespace-nowrap text-sm text-right font-semibold ${exception.financialImpact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {exception.financialImpact.toLocaleString(undefined, {style:'currency', currency: exception.currency})}
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm">
                <StatusPill status={exception.status} />
            </td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 hidden sm:table-cell">{exception.assignedTo || 'Unassigned'}</td>
            <td className="px-4 py-3 whitespace-nowrap text-sm text-center">
                <button onClick={() => onViewDetails(exception)} className="text-sky-600 hover:text-sky-800 p-1 rounded-full hover:bg-sky-100" title="View Details">
                    <EyeIcon className="w-5 h-5"/>
                </button>
                <button onClick={() => onOpenAdjustmentModal(exception)} className="text-yellow-500 hover:text-yellow-700 p-1 rounded-full hover:bg-yellow-100" title="Create Adjustment">
                    <AdjustmentIcon className="w-5 h-5"/>
                </button>
            </td>
        </tr>
    );
});


/**
 * The Exception Summary page displays a filterable and sortable list of financial exceptions.
 * It allows users to view exception details, initiate adjustments, and perform bulk actions.
 */
const ExceptionSummaryPage: React.FC = () => {
    const { 
        setCurrentPageTitle, 
        exceptions, 
        updateException, 
        saveAdjustment,
        currentBusinessArea,
        currentRegion,
        currentProductLineId,
        currentStrategyId
    } = useAppContext();

    // Page-specific filters
    const [statusFilter, setStatusFilter] = useState<ExceptionStatus | 'ALL'>('ALL');
    const [categoryFilter, setCategoryFilter] = useState<ExceptionCategory | 'ALL'>('ALL');

    // State for modals and context menus
    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
    const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);
    const [selectedException, setSelectedException] = useState<Exception | null>(null);
    const [contextMenu, setContextMenu] = useState<{ visible: boolean; x: number; y: number; exception: Exception | null }>({ visible: false, x: 0, y: 0, exception: null });
    
    // State for selection
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    
    useEffect(() => {
        setCurrentPageTitle('Exception Summary');
    }, [setCurrentPageTitle]);
    
    // Reset selections when filters change
    useEffect(() => {
        setSelectedIds([]);
    }, [currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId, statusFilter, categoryFilter]);
    
    const filteredExceptions = useMemo(() => {
        return exceptions.filter(ex => 
            ex.businessArea === currentBusinessArea &&
            (currentRegion === 'ALL' || ex.region === currentRegion) &&
            (currentProductLineId === 'ALL' || ex.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || ex.strategyId === currentStrategyId) &&
            (statusFilter === 'ALL' || ex.status === statusFilter) &&
            (categoryFilter === 'ALL' || ex.category === categoryFilter)
        );
    }, [exceptions, currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId, statusFilter, categoryFilter]);

    const handleOpenDetailModal = useCallback((exception: Exception) => {
        setSelectedException(exception);
        setIsDetailModalOpen(true);
        closeContextMenu();
    }, []);

    const handleOpenAdjustmentModal = useCallback((exception: Exception) => {
        setSelectedException(exception);
        setIsAdjustmentModalOpen(true);
        closeContextMenu();
    }, []);

    const handleSaveAdjustment = (adjustment: Adjustment) => {
        saveAdjustment(adjustment);
        // Also update exception status
        if (adjustment.relatedExceptionId) {
            const exceptionToUpdate = exceptions.find(ex => ex.id === adjustment.relatedExceptionId);
            if (exceptionToUpdate) {
                updateException({ ...exceptionToUpdate, status: ExceptionStatus.PENDING_ADJUSTMENT });
            }
        }
        setIsAdjustmentModalOpen(false);
        setSelectedException(null);
    };

    const handleToggleSelectOne = useCallback((id: string, checked: boolean) => {
        setSelectedIds(prev => checked ? [...prev, id] : prev.filter(selId => selId !== id));
    }, []);

    const handleToggleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            setSelectedIds(filteredExceptions.map(ex => ex.id));
        } else {
            setSelectedIds([]);
        }
    };

    const isAllSelected = selectedIds.length > 0 && selectedIds.length === filteredExceptions.length;

    const closeContextMenu = () => {
        setContextMenu({ visible: false, x: 0, y: 0, exception: null });
    };

    const handleContextMenu = (event: React.MouseEvent, exception: Exception) => {
        event.preventDefault();
        setContextMenu({ visible: true, x: event.clientX, y: event.clientY, exception });
    };

    const getContextMenuItems = (exception: Exception): ContextMenuItemType[] => {
        return [
            { label: 'View Details', icon: EyeIcon, onClick: () => handleOpenDetailModal(exception) },
            { label: 'Create Adjustment', icon: AdjustmentIcon, onClick: () => handleOpenAdjustmentModal(exception), disabled: exception.status === 'Resolved' || exception.status === 'Closed' },
            { label: 'Assign To...', icon: ShareIcon, onClick: () => alert(`Assigning ${exception.id}`), disabled: exception.status === 'Resolved' || exception.status === 'Closed' },
            { isSeparator: true },
            { label: 'Mark as Resolved', icon: CheckCircleIcon, onClick: () => updateException({...exception, status: ExceptionStatus.RESOLVED}), disabled: exception.status === 'Resolved' },
        ];
    };
    
    return (
        <div className="space-y-6">
            <DashboardCard title="Exceptions Workbench" actions={
                <div className="flex space-x-2">
                    <select
                        value={categoryFilter}
                        onChange={e => setCategoryFilter(e.target.value as ExceptionCategory | 'ALL')}
                        className="p-2 border border-slate-300 rounded-md text-sm bg-slate-50"
                    >
                        <option value="ALL">All Categories</option>
                        {Object.values(ExceptionCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                     <select
                        value={statusFilter}
                        onChange={e => setStatusFilter(e.target.value as ExceptionStatus | 'ALL')}
                        className="p-2 border border-slate-300 rounded-md text-sm bg-slate-50"
                    >
                        <option value="ALL">All Statuses</option>
                         {Object.values(ExceptionStatus).map(stat => <option key={stat} value={stat}>{stat}</option>)}
                    </select>
                </div>
            }>
                <div className="overflow-x-auto rounded-lg border border-slate-200">
                    <table className="min-w-full divide-y divide-slate-200">
                        <thead className="bg-slate-100">
                            <tr>
                                <th className="px-4 py-3 w-12">
                                    <input type="checkbox" onChange={handleToggleSelectAll} checked={isAllSelected} className="form-checkbox h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500" />
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">ID</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Description</th>
                                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">Impact</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</th>
                                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider hidden sm:table-cell">Assigned</th>
                                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-200">
                            {filteredExceptions.map(exception => (
                                <ExceptionRow
                                    key={exception.id}
                                    exception={exception}
                                    isSelected={selectedIds.includes(exception.id)}
                                    onToggleSelect={handleToggleSelectOne}
                                    onContextMenu={handleContextMenu}
                                    onViewDetails={handleOpenDetailModal}
                                    onOpenAdjustmentModal={handleOpenAdjustmentModal}
                                />
                            ))}
                        </tbody>
                    </table>
                     {filteredExceptions.length === 0 && <p className="text-center p-8 text-slate-500">No exceptions match the current filters.</p>}
                </div>
            </DashboardCard>

            {isDetailModalOpen && selectedException && (
                <ExceptionDetailModal
                    isOpen={isDetailModalOpen}
                    onClose={() => setIsDetailModalOpen(false)}
                    exception={selectedException}
                    onUpdateException={updateException}
                    onInitiateAdjustment={handleOpenAdjustmentModal}
                />
            )}

            {isAdjustmentModalOpen && (
                <AdjustmentModal
                    isOpen={isAdjustmentModalOpen}
                    onClose={() => setIsAdjustmentModalOpen(false)}
                    onSave={handleSaveAdjustment}
                    exception={selectedException}
                    businessArea={currentBusinessArea}
                />
            )}
            
            {contextMenu.visible && contextMenu.exception && (
                <ContextMenu
                    isOpen={contextMenu.visible}
                    x={contextMenu.x}
                    y={contextMenu.y}
                    items={getContextMenuItems(contextMenu.exception)}
                    onClose={closeContextMenu}
                />
            )}
        </div>
    );
};

export default ExceptionSummaryPage;
