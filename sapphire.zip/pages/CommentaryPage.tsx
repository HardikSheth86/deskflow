import React, { useEffect, useState, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import DashboardCard from '../components/DashboardCard';
import { MOCK_COMMENTARY_TEMPLATES } from '../constants';
import { Commentary, CommentaryTemplate } from '../types';
import CommentaryEditorModal from '../components/CommentaryEditorModal';
import { QuillPenIcon, EyeIcon, PencilIcon, LightbulbIcon } from '../components/icons';

const CommentaryPage: React.FC = () => {
  const { 
    currentBusinessArea, 
    setCurrentPageTitle, 
    commentaries, 
    saveCommentary,
    currentRegion,
    currentProductLineId,
    currentStrategyId
  } = useAppContext();
  
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingCommentary, setEditingCommentary] = useState<Commentary | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<CommentaryTemplate | null>(null);

  useEffect(() => {
    setCurrentPageTitle('Commentary Management');
  }, [setCurrentPageTitle]);

  const filteredCommentaries = useMemo(() => {
    return commentaries.filter(c => 
      c.businessArea === currentBusinessArea &&
      (currentRegion === 'ALL' || c.region === currentRegion) &&
      (currentProductLineId === 'ALL' || c.productLineId === currentProductLineId || c.productLineId === 'ALL') &&
      (currentStrategyId === 'ALL' || c.strategyId === currentStrategyId || c.strategyId === 'ALL')
    );
  }, [commentaries, currentBusinessArea, currentRegion, currentProductLineId, currentStrategyId]);

  const handleOpenNewCommentaryModal = (template: CommentaryTemplate) => {
    setSelectedTemplate(template);
    setEditingCommentary(null);
    setIsEditorOpen(true);
  };

  const handleOpenEditCommentaryModal = (commentary: Commentary) => {
    setSelectedTemplate(null);
    setEditingCommentary(commentary);
    setIsEditorOpen(true);
  };

  const handleCloseModal = () => {
    setIsEditorOpen(false);
    setEditingCommentary(null);
    setSelectedTemplate(null);
  };
  
  const handleSave = (commentaryToSave: Commentary) => {
    saveCommentary(commentaryToSave);
    handleCloseModal();
  }

  return (
    <div className="space-y-6">
      <DashboardCard title="Create New Commentary from Template">
        <p className="text-slate-600 mb-4">
          Select a template to start a new commentary. Each template provides predefined sections and AI suggestion placeholders.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {MOCK_COMMENTARY_TEMPLATES.map(template => (
            <div key={template.type} className="p-4 border border-slate-200 rounded-lg bg-white hover:shadow-lg transition-shadow flex flex-col justify-between">
              <div>
                <h3 className="text-md font-semibold text-sky-700 mb-1 flex items-center">
                  <QuillPenIcon className="w-5 h-5 mr-2" />
                  {template.name}
                </h3>
                <p className="text-xs text-slate-500 mb-3">{template.description}</p>
                <div className="mb-3">
                  <p className="text-xs font-medium text-slate-600">Sections:</p>
                  <ul className="list-disc list-inside text-xs text-slate-500">
                    {template.defaultSections.map(s => <li key={s.title}>{s.title}</li>)}
                  </ul>
                </div>
              </div>
              <button
                onClick={() => handleOpenNewCommentaryModal(template)}
                className="w-full mt-2 px-3 py-1.5 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium"
              >
                Create New
              </button>
            </div>
          ))}
        </div>
      </DashboardCard>

      <DashboardCard title={`Existing Commentaries`}>
        {filteredCommentaries.length > 0 ? (
          <div className="space-y-4">
            {filteredCommentaries.map(commentary => (
              <div key={commentary.id} className="p-4 border border-slate-200 rounded-lg bg-white shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-md font-semibold text-slate-800">{commentary.title}</h4>
                    <p className="text-xs text-slate-500">
                      Type: {commentary.type} | Author: {commentary.author} | Date: {new Date(commentary.dateCreated).toLocaleDateString()}
                    </p>
                    {commentary.tags && commentary.tags.length > 0 && (
                      <p className="text-xs text-slate-500 mt-1">
                        Tags: {commentary.tags.map(tag => (
                          <span key={tag} className="mr-1.5 px-1.5 py-0.5 bg-slate-200 text-slate-700 rounded-full text-xs">{tag}</span>
                        ))}
                      </p>
                    )}
                  </div>
                  <div className="flex space-x-2 flex-shrink-0 mt-1">
                    <button 
                      onClick={() => handleOpenEditCommentaryModal(commentary)} 
                      className="text-yellow-500 hover:text-yellow-700 p-1 rounded-full hover:bg-yellow-100" 
                      title="Edit Commentary"
                    >
                      <PencilIcon className="w-5 h-5"/>
                    </button>
                    <button 
                      onClick={() => alert(`Viewing details for: ${commentary.title}\n(Full view not implemented, sections: ${commentary.sections.map(s => s.title).join(', ')})`)}
                      className="text-sky-600 hover:text-sky-800 p-1 rounded-full hover:bg-sky-100" 
                      title="View Details"
                    >
                      <EyeIcon className="w-5 h-5"/>
                    </button>
                  </div>
                </div>
                <div className="mt-2 text-xs text-slate-600">
                  <p className="font-medium">Summary of first section ({commentary.sections[0]?.title || 'Content'}):</p>
                  <p className="italic truncate">{commentary.sections[0]?.userContent || 'No content.'}</p>
                   {commentary.sections[0]?.aiSuggestion && (
                    <p className="text-xs text-sky-600 mt-1 flex items-center">
                        <LightbulbIcon className="w-3 h-3 mr-1 text-yellow-500" />
                        <span className="font-medium">AI Placeholder:</span>&nbsp;
                        <span className="italic truncate">{commentary.sections[0].aiSuggestion.substring(0,100)}...</span>
                    </p>
                   )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 text-center py-4">No commentaries found for the current filter criteria.</p>
        )}
      </DashboardCard>

      {isEditorOpen && (
        <CommentaryEditorModal
          isOpen={isEditorOpen}
          onClose={handleCloseModal}
          onSave={handleSave}
          businessArea={currentBusinessArea}
          existingCommentary={editingCommentary}
          template={selectedTemplate}
        />
      )}
    </div>
  );
};

export default CommentaryPage;
