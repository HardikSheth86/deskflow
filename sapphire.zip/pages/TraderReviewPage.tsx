import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../hooks/useAppContext';
import { MOCK_TRADER_PNL_SUMMARY, MOCK_COMMENTARY_TEMPLATES } from '../constants';
import { Commentary, PreSignOffTaskStatus, CommentaryType, CommentaryTemplate } from '../types';
import DashboardCard from '../components/DashboardCard';
import { formatCurrency } from '../utils/helpers';
import { BellAlertIcon, CheckCircleIcon, CommentaryIcon, CurrencyDollarIcon, QuillPenIcon, UserCircleIcon } from '../components/icons';
import CommentaryEditorModal from '../components/CommentaryEditorModal';

const PnlMetric: React.FC<{ label: string; value: number; currency: string; isPositive: boolean }> = ({ label, value, currency, isPositive }) => (
    <div className="bg-slate-50 p-3 rounded-lg text-center">
        <p className="text-sm text-slate-500">{label}</p>
        <p className={`text-xl font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {formatCurrency(value, currency, true)}
        </p>
    </div>
);


const TraderReviewPage: React.FC = () => {
    const { 
        setCurrentPageTitle, 
        preSignOffTasksByArea, 
        commentaries, 
        currentBusinessArea,
        saveCommentary,
        currentRegion,
        currentProductLineId,
        currentStrategyId
    } = useAppContext();

    const [acknowledged, setAcknowledged] = useState(false);
    const [isPackModalOpen, setIsPackModalOpen] = useState(false);
    const [editingPack, setEditingPack] = useState<Commentary | null>(null);
    
    const currentUser = 'Valerie User';

    useEffect(() => {
        setCurrentPageTitle(`Trader Review: ${currentUser}`);
        setAcknowledged(false);
    }, [setCurrentPageTitle, currentBusinessArea]);

    const pnlSummary = MOCK_TRADER_PNL_SUMMARY;

    const t0DiffsAndBreaks = useMemo(() => {
        const allTasks = preSignOffTasksByArea[currentBusinessArea] || [];
        return allTasks.filter(task => 
            task.assignedToUser === currentUser && 
            task.status === PreSignOffTaskStatus.COMPLETED_BREAKS &&
            (currentRegion === 'ALL' || task.region === currentRegion) &&
            (currentProductLineId === 'ALL' || task.productLineId === currentProductLineId) &&
            (currentStrategyId === 'ALL' || task.strategyId === currentStrategyId)
        );
    }, [preSignOffTasksByArea, currentBusinessArea, currentUser, currentRegion, currentProductLineId, currentStrategyId]);
    
    const recentCommentaries = useMemo(() => {
        return commentaries
            .filter(c => 
                c.author === currentUser && 
                c.businessArea === currentBusinessArea && 
                c.type !== CommentaryType.DAILY_TRADER_PACK &&
                (currentRegion === 'ALL' || c.region === currentRegion) &&
                (currentProductLineId === 'ALL' || c.productLineId === currentProductLineId) &&
                (currentStrategyId === 'ALL' || c.strategyId === currentStrategyId)
            )
            .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())
            .slice(0, 5);
    }, [commentaries, currentBusinessArea, currentUser, currentRegion, currentProductLineId, currentStrategyId]);

    const dailyTraderPack = useMemo(() => {
        return commentaries
            .filter(c => c.author === currentUser && c.businessArea === currentBusinessArea && c.type === CommentaryType.DAILY_TRADER_PACK)
            .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())[0] || null;
    }, [commentaries, currentUser, currentBusinessArea]);

    const handleOpenPackModal = () => {
        setEditingPack(dailyTraderPack);
        setIsPackModalOpen(true);
    };

    const handleSavePack = (pack: Commentary) => {
        saveCommentary(pack);
        setIsPackModalOpen(false);
    };

    return (
        <div className="space-y-6">
            <DashboardCard 
                title={<div className="flex items-center"><UserCircleIcon className="w-6 h-6 mr-2" /> Daily Review & Acknowledgement</div>}
            >
                <div className="flex flex-col md:flex-row justify-between items-center">
                    <p className="text-slate-600 mb-4 md:mb-0">
                        Review your P&L, outstanding breaks, and commentaries for the day, then acknowledge completion.
                    </p>
                    <button 
                        onClick={() => setAcknowledged(true)}
                        disabled={acknowledged}
                        className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-base font-semibold flex items-center disabled:bg-green-400 disabled:cursor-not-allowed"
                    >
                        <CheckCircleIcon className="w-6 h-6 mr-2"/> 
                        {acknowledged ? 'Daily Review Acknowledged' : 'Acknowledge Daily Review'}
                    </button>
                </div>
                {acknowledged && (
                    <p className="text-center mt-4 text-green-700 font-medium bg-green-50 p-2 rounded-md">
                        Thank you! Your review for {new Date().toLocaleDateString()} has been recorded.
                    </p>
                )}
            </DashboardCard>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <DashboardCard title={<div className="flex items-center"><CurrencyDollarIcon className="w-5 h-5 mr-2" />My P&L Summary</div>}>
                     <div className="grid grid-cols-3 gap-4">
                        <PnlMetric label="DoD P&L" value={pnlSummary.dod} currency={pnlSummary.currency} isPositive={pnlSummary.dod >= 0} />
                        <PnlMetric label="MTD P&L" value={pnlSummary.mtd} currency={pnlSummary.currency} isPositive={pnlSummary.mtd >= 0} />
                        <PnlMetric label="YTD P&L" value={pnlSummary.ytd} currency={pnlSummary.currency} isPositive={pnlSummary.ytd >= 0} />
                    </div>
                </DashboardCard>
                
                <DashboardCard title={<div className="flex items-center"><QuillPenIcon className="w-5 h-5 mr-2" />Daily Trader Pack</div>}>
                    {dailyTraderPack ? (
                        <div className="flex flex-col h-full">
                            <div className="flex-grow">
                                <p className="text-sm text-slate-600 mb-2">
                                    Latest pack from <span className="font-semibold">{new Date(dailyTraderPack.dateCreated).toLocaleString()}</span>
                                </p>
                                <p className="text-xs italic text-slate-500 bg-slate-100 p-2 rounded-md">
                                    "{dailyTraderPack.sections[0]?.userContent.substring(0, 150)}..."
                                </p>
                            </div>
                            <button
                                onClick={handleOpenPackModal}
                                className="mt-4 w-full px-3 py-1.5 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium"
                            >
                                View / Edit Pack
                            </button>
                        </div>
                    ) : (
                        <div className="text-center py-4 flex flex-col justify-center items-center h-full">
                            <p className="text-slate-500 mb-3">No trader pack created for today.</p>
                            <button
                                onClick={handleOpenPackModal}
                                className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors text-sm font-medium"
                            >
                                Create New Pack
                            </button>
                        </div>
                    )}
                </DashboardCard>

                <DashboardCard title={<div className="flex items-center"><BellAlertIcon className="w-5 h-5 mr-2" />My T0 Diffs & Breaks ({t0DiffsAndBreaks.length})</div>}>
                    {t0DiffsAndBreaks.length > 0 ? (
                        <ul className="space-y-2">
                           {t0DiffsAndBreaks.map(task => (
                               <li key={task.id} className="flex justify-between items-center p-2 bg-red-50 border border-red-200 rounded-md">
                                   <div>
                                        <p className="font-medium text-red-800">{task.title}</p>
                                        <p className="text-xs text-red-600">{task.breakCount} breaks found. Last run: {task.lastRun ? new Date(task.lastRun).toLocaleTimeString() : 'N/A'}</p>
                                   </div>
                                   <Link to="/presignoff" className="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs font-medium">
                                       View
                                   </Link>
                               </li>
                           ))}
                        </ul>
                    ) : (
                        <div className="flex items-center justify-center h-full">
                           <p className="text-slate-500 text-center py-4">No outstanding T0 breaks assigned to you for the selected filters.</p>
                        </div>
                    )}
                </DashboardCard>
            </div>
            
            <DashboardCard title={<div className="flex items-center"><CommentaryIcon className="w-5 h-5 mr-2" />My Recent Commentaries</div>}>
                {recentCommentaries.length > 0 ? (
                    <div className="space-y-3">
                        {recentCommentaries.map(comment => (
                            <div key={comment.id} className="p-3 border-l-4 border-sky-500 bg-slate-50 rounded-r-md">
                                <div className="flex justify-between items-center">
                                    <p className="font-semibold text-slate-700">{comment.title}</p>
                                    <p className="text-xs text-slate-500">{new Date(comment.dateCreated).toLocaleString()}</p>
                                </div>
                                <p className="text-xs text-slate-600 italic truncate mt-1">
                                    "{comment.sections[0]?.userContent || 'No content.'}"
                                </p>
                            </div>
                        ))}
                    </div>
                ) : (
                     <p className="text-slate-500 text-center py-4">You have no recent commentaries matching the current filters.</p>
                )}
            </DashboardCard>

             {isPackModalOpen && (
                <CommentaryEditorModal
                    isOpen={isPackModalOpen}
                    onClose={() => setIsPackModalOpen(false)}
                    onSave={handleSavePack}
                    businessArea={currentBusinessArea}
                    existingCommentary={editingPack}
                    template={!editingPack ? MOCK_COMMENTARY_TEMPLATES.find(t => t.type === CommentaryType.DAILY_TRADER_PACK) : null}
                />
            )}
        </div>
    );
};

export default TraderReviewPage;
