/**
 * This file contains mock data used throughout the application for development and demonstration purposes.
 * In a real-world scenario, this data would be fetched from APIs.
 */
import {
  BusinessArea, ProcessStage, KPI, ExceptionCategory, Exception, ExceptionStatus,
  Adjustment, ActivityLogItem,
  CommentaryType, CommentaryTemplate, Commentary, CommentarySection,
  DistributionList, AdjustmentType, AdjustmentStatus,
  SignOffProductLine, SignOffStrategy, ProcessStatus,
  PreSignOffTask, PreSignOffTaskStatus, PreSignOffBreakDetail, PreSignOffAction,
  StackItem, ReleaseTrain, DeploymentStatus, InvestigativeTrade, TraderPnlSummary, FAQ,
  Case, CaseStatus, Region
} from './types';
import { AnalyticsIcon, CalculatorIcon, AdjustmentIcon } from './components/icons';
import { calculateProductLineAggregates, determineProductLineStatus } from './utils/helpers';

/**
 * An array of all available business areas in the application.
 * @type {BusinessArea[]}
 */
export const ALL_BUSINESS_AREAS: BusinessArea[] = [
  BusinessArea.EQUITIES,
  BusinessArea.FIXED_INCOME,
  BusinessArea.PRIME_BROKERAGE,
  BusinessArea.COMMODITIES,
  BusinessArea.TREASURY_CAPITAL_MARKETS,
];

/**
 * An array of all available regions in the application.
 * @type {Region[]}
 */
export const ALL_REGIONS: Region[] = [
  Region.NORTH_AMERICA,
  Region.EMEA,
  Region.TOKYO,
  Region.NON_JAPAN_ASIA
];

/**
 * Mock data representing the stages of the daily financial validation process.
 * Used for the progress bar on the dashboard.
 * @type {ProcessStage[]}
 */
export const MOCK_PROCESS_STAGES: ProcessStage[] = [
  { id: 'data_loading', name: 'Data Loading', completedAt: '2024-07-28 08:00 AM', status: 'completed' },
  { id: 'initial_validation', name: 'Initial Validation', completedAt: '2024-07-28 09:30 AM', status: 'completed' },
  { id: 'exception_generation', name: 'Exception Generation', completedAt: '2024-07-28 10:15 AM', status: 'completed' },
  { id: 'ready_for_review', name: 'Ready for Review', completedAt: null, status: 'in-progress' },
  { id: 'final_sign_off', name: 'Final Sign-off', completedAt: null, status: 'pending' },
];

/**
 * Mock Key Performance Indicator (KPI) data, categorized by business area.
 * Used for the main summary cards on the dashboard.
 * @type {Record<BusinessArea, KPI[]>}
 */
export const MOCK_KPIS: Record<BusinessArea, KPI[]> = {
  [BusinessArea.EQUITIES]: [
    { label: 'Total Assets', value: '$1.2B', variance: '+$10M (0.83%)', varianceType: 'positive' },
    { label: 'Total Liabilities', value: '$800M', variance: '+$5M (0.63%)', varianceType: 'neutral' },
    { label: 'Net P&L', value: '$1.5M', variance: '-$50K (3.23%)', varianceType: 'negative' },
    { label: 'Gross P&L', value: '$2.2M', variance: '+$100K (4.76%)', varianceType: 'positive' },
  ],
  [BusinessArea.FIXED_INCOME]: [
    { label: 'Total Assets', value: '$5.5B', variance: '+$50M (0.91%)', varianceType: 'positive' },
    { label: 'Total Liabilities', value: '$4.2B', variance: '+$20M (0.48%)', varianceType: 'neutral' },
    { label: 'Net P&L', value: '$800K', variance: '+$25K (3.23%)', varianceType: 'positive' },
    { label: 'Gross P&L', value: '$1.1M', variance: '+$15K (1.38%)', varianceType: 'positive' },
  ],
  [BusinessArea.PRIME_BROKERAGE]: [
    { label: 'Total Assets', value: '$10.1B', variance: '-$100M (0.98%)', varianceType: 'negative' },
    { label: 'Total Liabilities', value: '$9.0B', variance: '-$80M (0.88%)', varianceType: 'neutral' },
    { label: 'Net P&L', value: '$500K', variance: '-$10K (1.96%)', varianceType: 'negative' },
    { label: 'Gross P&L', value: '$750K', variance: '+$5K (0.67%)', varianceType: 'positive' },
  ],
  [BusinessArea.COMMODITIES]: [
     { label: 'Total Assets', value: '$2.0B', variance: '+$20M (1.00%)', varianceType: 'positive' },
    { label: 'Total Liabilities', value: '$1.5B', variance: '+$10M (0.67%)', varianceType: 'neutral' },
    { label: 'Net P&L', value: '$300K', variance: '+$30K (11.11%)', varianceType: 'positive' },
    { label: 'Gross P&L', value: '$450K', variance: '+$40K (9.76%)', varianceType: 'positive' },
  ],
  [BusinessArea.TREASURY_CAPITAL_MARKETS]: [
    { label: 'Total Assets', value: '$3.2B', variance: '+$15M (0.47%)', varianceType: 'positive' },
    { label: 'Total Liabilities', value: '$2.8B', variance: '+$10M (0.36%)', varianceType: 'neutral' },
    { label: 'Net P&L', value: '$450K', variance: '+$12K (2.74%)', varianceType: 'positive' },
    { label: 'Gross P&L', value: '$600K', variance: '+$20K (3.45%)', varianceType: 'positive' },
  ]
};

/**
 * Mock data representing financial exceptions. This is a core dataset for the application.
 * Used on the Exception Summary page and for various dashboard widgets.
 * @type {Exception[]}
 */
export const MOCK_EXCEPTIONS: Exception[] = [
  {
    id: 'EXC001', category: ExceptionCategory.FOBO, positionId: 'AAPL.OQ-123', financialImpact: 15000.75, currency: 'USD',
    description: 'P&L mismatch on AAPL trade vs Front Office estimate.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-28', businessArea: BusinessArea.EQUITIES,
    productLineId: 'PL_EQ_US', strategyId: 'EQ_US_ALPHA', region: Region.NORTH_AMERICA,
    details: { 'FO System': 'TradeMaster', 'BO System': 'GL Pro', 'FO P&L': 120500.00, 'BO P&L': 105499.25, 'Trade ID': 'T-A98765', 'Booking Time': '2024-07-27 15:30 EST' },
    history: [{ timestamp: '2024-07-28 10:00', action: 'Created', user: 'System'}],
    aiRcaCommentary: "AI Analysis: P&L discrepancy of $15,000.75 on AAPL.OQ-123 likely due to a late booking of a corporate action adjustment (e.g., dividend reinvestment) not reflected in the initial FO estimate from TradeMaster. Variance exceeds typical threshold for this trading volume. FO P&L: $120,500.00, BO P&L: $105,499.25. Recommend verifying corporate action processing for AAPL around 2024-07-27."
  },
  {
    id: 'EXC002', category: ExceptionCategory.VRS, positionId: 'GOOG.OQ-456', financialImpact: -5250.00, currency: 'USD',
    description: 'Valuation difference for GOOG position with external vendor.', status: ExceptionStatus.IN_REVIEW, assignedTo: 'Jane Smith',
    dateIdentified: '2024-07-28', businessArea: BusinessArea.EQUITIES,
    productLineId: 'PL_EQ_US', strategyId: 'EQ_US_QUANT', region: Region.NORTH_AMERICA,
    details: { 'Internal Model Price': 150.50, 'Vendor Price': 151.00, 'Quantity': 10500, 'Valuation Source Internal': 'InternalModelXYZ', 'Valuation Source External': 'VendorABC' },
    history: [
      { timestamp: '2024-07-28 10:05', action: 'Created', user: 'System'},
      { timestamp: '2024-07-28 11:00', action: 'Assigned to Jane Smith', user: 'AutoRouter'}
    ],
    aiRcaCommentary: "AI Analysis: Valuation difference of -$5,250.00 for GOOG.OQ-456. Internal model priced at $150.50, external vendor (VendorABC) at $151.00. This $0.50 difference per share on 10,500 shares suggests a potential stale price on one feed or differing model assumptions (e.g., volatility smiles). Check last update times for both price feeds."
  },
  {
    id: 'EXC003', category: ExceptionCategory.DOD, positionId: 'USD/EUR-789', financialImpact: 250000.00, currency: 'USD',
    description: 'Significant Day-over-Day P&L change for USD/EUR spot.', status: ExceptionStatus.PENDING_ADJUSTMENT,
    dateIdentified: '2024-07-28', businessArea: BusinessArea.FIXED_INCOME,
    productLineId: 'PL_FI_GLOBAL', strategyId: 'FI_GBL_RATES', region: Region.EMEA,
    rcaCommentary: 'Market volatility due to central bank announcement.',
    details: { 'Previous Day P&L': 50000.00, 'Current Day P&L': 300000.00, 'Position Size': '50M EUR', 'Relevant News Event': 'ECB Rate Decision 08:00 UTC' },
    history: [
      { timestamp: '2024-07-28 10:10', action: 'Created', user: 'System'},
      { timestamp: '2024-07-28 12:00', action: 'RCA Added', user: 'Mark Johnson'}
    ],
    aiRcaCommentary: "AI Analysis: The $250,000.00 Day-over-Day P&L increase for USD/EUR-789 is strongly correlated with the European Central Bank's unscheduled policy rate announcement at 08:00 UTC. Volatility indices for FX pairs involving EUR jumped by approximately 150% around this time. The P&L change is consistent with a long EUR position of roughly 50M."
  },
  {
    id: 'EXC004', category: ExceptionCategory.ATTRIBUTION, positionId: 'PRIME-CLIENT-A', financialImpact: 1200.00, currency: 'USD',
    description: 'P&L attribution break for Prime Client A book.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-28', businessArea: BusinessArea.PRIME_BROKERAGE,
    productLineId: 'PL_PB_GLOBAL', strategyId: 'PB_CLIENT_SRV', region: Region.NORTH_AMERICA,
    details: { 'Total P&L': 5000.00, 'Sum of Attributed Factors': 3800.00, 'Unexplained Difference': 1200.00, 'Primary Strategy': 'Equity Long/Short' },
    history: [{ timestamp: '2024-07-28 10:15', action: 'Created', user: 'System'}]
  },
  {
    id: 'EXC005', category: ExceptionCategory.CUSTOM_RULES, positionId: 'GL-ACC-CASH-001', financialImpact: 0, currency: 'USD',
    description: 'Cash account balance stale for more than 2 hours.', status: ExceptionStatus.RESOLVED,
    dateIdentified: '2024-07-27', businessArea: BusinessArea.EQUITIES, rcaCommentary: 'Data feed delay, resolved by manual refresh.',
    productLineId: 'PL_EQ_US', strategyId: 'EQ_US_QUANT', region: Region.NORTH_AMERICA,
    details: { 'Last Update Time': '2024-07-27 11:30 AM', 'Expected Update Frequency': '15 minutes' },
    history: [
      { timestamp: '2024-07-27 14:00', action: 'Created', user: 'System'},
      { timestamp: '2024-07-27 15:30', action: 'Resolved', user: 'System Admin'}
    ]
  },
  {
    id: 'EXC006', category: ExceptionCategory.FOBO, positionId: 'OIL.WTI-CL1', financialImpact: 1250000.50, currency: 'USD',
    description: 'Large P&L discrepancy on WTI Crude Oil futures vs FO estimate.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-29', businessArea: BusinessArea.COMMODITIES,
    productLineId: 'PL_COM_GLOBAL', strategyId: 'COM_ENERGY', region: Region.NORTH_AMERICA,
    details: { 'FO P&L': 2500000.00, 'BO P&L': 1249999.50, 'Contract': 'CLZ24', 'Volume': 1000 },
    history: [{ timestamp: '2024-07-29 09:00', action: 'Created', user: 'System'}],
    aiRcaCommentary: "AI Analysis: Significant FOBO break of $1,250,000.50 on WTI Crude Oil futures. Discrepancy may be related to incorrect contract roll adjustment in one system or a large trade captured post FO cut-off. Verify trade blotters and roll schedules."
  },
  {
    id: 'EXC007', category: ExceptionCategory.VRS, positionId: 'MSFT.OQ-789', financialImpact: -750.00, currency: 'USD',
    description: 'Minor valuation difference for MSFT, no AI RCA generated.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-29', businessArea: BusinessArea.EQUITIES,
    productLineId: 'PL_EQ_EU', strategyId: 'EQ_EU_ALPHA', region: Region.EMEA,
    details: { 'Internal Price': 450.25, 'External Price': 450.30, 'Quantity': 1500 },
  },
  {
    id: 'EXC008', category: ExceptionCategory.DOD, positionId: 'PB-MARGIN-ACCT-B', financialImpact: 0, currency: 'USD',
    description: 'Prime Brokerage margin account shows no change DoD but expected activity.', status: ExceptionStatus.IN_REVIEW,
    dateIdentified: '2024-07-29', businessArea: BusinessArea.PRIME_BROKERAGE,
    productLineId: 'PL_PB_GLOBAL', strategyId: 'PB_EQ_FIN', region: Region.EMEA,
    rcaCommentary: 'Investigating potential feed issue for client B activity.',
    details: {'Account ID': 'PBCLI-B-MARGIN-002', 'Previous Balance': 1250345.67, 'Current Balance': 1250345.67}
  },
   {
    id: 'EXC009', category: ExceptionCategory.CUSTOM_RULES, positionId: 'FX-SETTLE-GBP', financialImpact: 0, currency: 'GBP',
    description: 'GBP settlement account has a negative balance.', status: ExceptionStatus.CLOSED,
    dateIdentified: '2024-07-26', businessArea: BusinessArea.FIXED_INCOME, rcaCommentary: 'Timing difference due to holiday, resolved.',
    productLineId: 'PL_FI_GLOBAL', strategyId: 'FI_GBL_CREDIT', region: Region.EMEA,
    details: { 'Balance': -50210.00, 'Currency': 'GBP' },
    history: [
      { timestamp: '2024-07-26 10:00', action: 'Created', user: 'System'},
      { timestamp: '2024-07-26 15:30', action: 'Closed', user: 'Finance Ops'}
    ]
  },
  {
    id: 'EXC010', category: ExceptionCategory.VRS, positionId: 'SN-FID-XYZ-001', financialImpact: 22000.00, currency: 'USD',
    description: 'Valuation discrepancy on Structured Note linked to S&P 500.', status: ExceptionStatus.OPEN,
    dateIdentified: '2024-07-29', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    productLineId: 'PL_TCM_SN', strategyId: 'SN_FID', region: Region.NORTH_AMERICA,
    details: { 'Internal Model Price': 102.50, 'Counterparty Mark': 102.30, 'Notional': 11000000 },
    history: [{ timestamp: '2024-07-29 10:00', action: 'Created', user: 'System'}],
    aiRcaCommentary: "AI Analysis: Valuation difference of $22,000 on Structured Note SN-FID-XYZ-001. Discrepancy likely stems from different volatility surface inputs between internal model and counterparty mark. Recommend comparing vol grids for the underlying SPX options."
  },
];

const mockEquityActivityLog: ActivityLogItem[] = [
  { id: 'ACT001', timestamp: '2024-07-28 09:15 AM', type: 'Trade', description: 'Bought 1000 AAPL.OQ @ $175.20', financialImpact: { amount: -175200, currency: 'USD', assetEffect: 175200 }, user: 'TraderX' },
  { id: 'ACT002', timestamp: '2024-07-28 10:30 AM', type: 'Trade', description: 'Sold 500 MSFT.OQ @ $350.10', financialImpact: { amount: 175050, currency: 'USD', assetEffect: -175050, pnlEffect: 8000 }, user: 'TraderX' },
  { id: 'ACT003', timestamp: '2024-07-28 11:00 AM', type: 'FX Reval', description: 'USD/EUR FX revaluation on cash balances', financialImpact: { amount: 0, currency: 'USD', pnlEffect: 20000 }, user: 'System' },
  { id: 'ACT004', timestamp: '2024-07-28 12:00 PM', type: 'Fee', description: 'Brokerage fees applied', financialImpact: { amount: -1500, currency: 'USD', pnlEffect: -1500 }, user: 'System' },
  { id: 'ACT005', timestamp: '2024-07-28 02:00 PM', type: 'Adjustment', description: 'Manual P&L Adjustment for EXC001', financialImpact: { amount: -15000.75, currency: 'USD', pnlEffect: -15000.75 }, user: 'Valerie User' },
  { id: 'ACT006', timestamp: '2024-07-28 02:30 PM', type: 'Commentary', description: 'Market commentary added for Equities US', user: 'John Analyst' },
];

const mockFixedIncomeActivityLog: ActivityLogItem[] = [
  { id: 'ACTF01', timestamp: '2024-07-28 09:00 AM', type: 'Trade', description: 'Bought 10M US10YT=RR @ 98.50', financialImpact: { amount: -9850000, currency: 'USD', assetEffect: 9850000 }, user: 'TraderY' },
  { id: 'ACTF02', timestamp: '2024-07-28 10:00 AM', type: 'FX Reval', description: 'GBP/USD FX revaluation for UK Gilt holdings', financialImpact: {amount: 0, currency:'GBP', pnlEffect: -50000 /* in GBP, this would be converted for USD books */ }, user: 'System'},
  { id: 'ACTF03', timestamp: '2024-07-28 01:00 PM', type: 'Adjustment', description: 'Accrued Interest Calculation Adjustment', financialImpact: { amount: 5000, currency: 'USD', pnlEffect: 5000 }, user: 'System'},
];

const mockCommoditiesActivityLog: ActivityLogItem[] = [
    { id: 'ACTC01', timestamp: '2024-07-29 09:30 AM', type: 'Trade', description: 'Sold 500 CLZ24 (WTI Crude) @ $75.50', financialImpact: { amount: 37750, currency: 'USD', pnlEffect: 2500 }, user: 'TraderZ' },
    { id: 'ACTC02', timestamp: '2024-07-29 11:00 AM', type: 'FX Reval', description: 'CAD/USD FX revaluation on CAD denominated contracts', financialImpact: { amount: 0, currency: 'CAD', pnlEffect: -15000 }, user: 'System' },
];


const STRATEGIES_EQ_US: SignOffStrategy[] = [
  { 
    id: 'EQ_US_ALPHA', name: 'US Alpha Strategy', parentId: 'PL_EQ_US', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 10:00 AM', currency: 'USD', businessArea: BusinessArea.EQUITIES,
    region: Region.NORTH_AMERICA,
    previousNetPnL: 800000, currentNetPnL: 820000, pnlTrading: 25000, pnlFxReval: -2000, pnlAdjustments: -3000,
    previousTotalAssets: 600000000, currentTotalAssets: 605000000, assetChangeTrading: 4000000, assetChangeFxReval: 800000, assetChangeAdjustments: 200000,
    previousTotalLiabilities: 400000000, currentTotalLiabilities: 402000000, liabilityChangeTrading: 1000000, liabilityChangeFxReval: 500000, liabilityChangeAdjustments: 500000,
    activityLog: mockEquityActivityLog.slice(0, 2).map(a => ({...a, id: a.id + '_EQUS_A'}))
  },
  { 
    id: 'EQ_US_QUANT', name: 'US Quant Strategy', parentId: 'PL_EQ_US', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 10:30 AM', currency: 'USD', businessArea: BusinessArea.EQUITIES,
    region: Region.NORTH_AMERICA,
    previousNetPnL: 700000, currentNetPnL: 730000, pnlTrading: 15000, pnlFxReval: 22000, pnlAdjustments: -7000,
    previousTotalAssets: 600000000, currentTotalAssets: 605000000, assetChangeTrading: 4000000, assetChangeFxReval: 700000, assetChangeAdjustments: 300000,
    previousTotalLiabilities: 400000000, currentTotalLiabilities: 403000000, liabilityChangeTrading: 1000000, liabilityChangeFxReval: 500000, liabilityChangeAdjustments: 1500000,
    activityLog: mockEquityActivityLog.slice(2, 4).map(a => ({...a, id: a.id + '_EQUS_Q'}))
  },
];

const STRATEGIES_EQ_EU: SignOffStrategy[] = [
  {
    id: 'EQ_EU_ALPHA', name: 'EU Alpha Strategy', parentId: 'PL_EQ_EU', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 10:00 AM', currency: 'EUR', businessArea: BusinessArea.EQUITIES,
    region: Region.EMEA,
    previousNetPnL: 400000, currentNetPnL: 415000, pnlTrading: 20000, pnlFxReval: -5000, pnlAdjustments: 0,
    previousTotalAssets: 300000000, currentTotalAssets: 302000000, assetChangeTrading: 2000000, assetChangeFxReval: 0, assetChangeAdjustments: 0,
    previousTotalLiabilities: 200000000, currentTotalLiabilities: 201000000, liabilityChangeTrading: 1000000, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: [],
  }
];

const STRATEGIES_FI_GLOBAL: SignOffStrategy[] = [
  {
    id: 'FI_GBL_RATES', name: 'Global Rates Strategy', parentId: 'PL_FI_GLOBAL', status: ProcessStatus.AWAITING_SIGN_OFF, lastUpdated: '2024-07-29 11:00 AM', currency: 'USD', businessArea: BusinessArea.FIXED_INCOME,
    region: Region.EMEA,
    previousNetPnL: 500000, currentNetPnL: 510000, pnlTrading: 12000, pnlFxReval: -1000, pnlAdjustments: -1000,
    previousTotalAssets: 3000000000, currentTotalAssets: 3020000000, assetChangeTrading: 25000000, assetChangeFxReval: -3000000, assetChangeAdjustments: -2000000,
    previousTotalLiabilities: 2000000000, currentTotalLiabilities: 2010000000, liabilityChangeTrading: 10000000, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: mockFixedIncomeActivityLog.slice(0, 1).map(a => ({...a, id: a.id + '_FIGL_R'}))
  },
  {
    id: 'FI_GBL_CREDIT', name: 'Global Credit Strategy', parentId: 'PL_FI_GLOBAL', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 09:30 AM', currency: 'USD', businessArea: BusinessArea.FIXED_INCOME,
    region: Region.EMEA,
    previousNetPnL: 300000, currentNetPnL: 315000, pnlTrading: 3000, pnlFxReval: 6000, pnlAdjustments: 6000,
    previousTotalAssets: 2500000000, currentTotalAssets: 2530000000, assetChangeTrading: 15000000, assetChangeFxReval: 8000000, assetChangeAdjustments: 7000000,
    previousTotalLiabilities: 2200000000, currentTotalLiabilities: 2210000000, liabilityChangeTrading: 0, liabilityChangeFxReval: 5000000, liabilityChangeAdjustments: 5000000,
    activityLog: mockFixedIncomeActivityLog.slice(1, 2).map(a => ({...a, id: a.id + '_FIGL_C'}))
  },
  {
    id: 'FI_GBL_EMERGING', name: 'Emerging Markets Debt Strategy', parentId: 'PL_FI_GLOBAL', status: ProcessStatus.REJECTED, lastUpdated: '2024-07-29 14:00 PM', currency: 'USD', businessArea: BusinessArea.FIXED_INCOME,
    region: Region.NON_JAPAN_ASIA,
    previousNetPnL: 100000, currentNetPnL: -50000, pnlTrading: -140000, pnlFxReval: 20000, pnlAdjustments: -30000,
    previousTotalAssets: 500000000, currentTotalAssets: 480000000, assetChangeTrading: -25000000, assetChangeFxReval: 5000000, assetChangeAdjustments: 0,
    previousTotalLiabilities: 300000000, currentTotalLiabilities: 300000000, liabilityChangeTrading: 0, liabilityChangeFxReval: 0, liabilityChangeAdjustments: 0,
    activityLog: []
  }
];

const STRATEGIES_PB_GLOBAL: SignOffStrategy[] = [
    { id: 'PB_EQ_FIN', name: 'PB Equity Finance', parentId: 'PL_PB_GLOBAL', status: ProcessStatus.REJECTED, lastUpdated: '2024-07-29 10:00 AM', currency: 'USD', businessArea: BusinessArea.PRIME_BROKERAGE,
      region: Region.EMEA,
      previousNetPnL: 250000, currentNetPnL: 240000, pnlTrading: -12000, pnlFxReval: 1000, pnlAdjustments: 1000,
      previousTotalAssets: 5050000000, currentTotalAssets: 5000000000, assetChangeTrading: -40000000, assetChangeFxReval: -5000000, assetChangeAdjustments: -5000000,
      previousTotalLiabilities: 4500000000, currentTotalLiabilities: 4460000000, liabilityChangeTrading: -35000000, liabilityChangeFxReval: -2500000, liabilityChangeAdjustments: -2500000,
      activityLog: mockEquityActivityLog.slice(1,2).map(a => ({...a, id: a.id + '_PB1'}))
    },
    { id: 'PB_CLIENT_SRV', name: 'PB Client Servicing', parentId: 'PL_PB_GLOBAL', status: ProcessStatus.REJECTED, lastUpdated: '2024-07-29 11:00 AM', currency: 'USD', businessArea: BusinessArea.PRIME_BROKERAGE,
      region: Region.NORTH_AMERICA,
      previousNetPnL: 250000, currentNetPnL: 250000, pnlTrading: 3000, pnlFxReval: -1000, pnlAdjustments: -2000,
      previousTotalAssets: 5050000000, currentTotalAssets: 5000000000, assetChangeTrading: -40000000, assetChangeFxReval: -5000000, assetChangeAdjustments: -5000000,
      previousTotalLiabilities: 4500000000, currentTotalLiabilities: 4460000000, liabilityChangeTrading: -35000000, liabilityChangeFxReval: -2500000, liabilityChangeAdjustments: -2500000,
      activityLog: mockEquityActivityLog.slice(2,3).map(a => ({...a, id: a.id + '_PB2'}))
    },
];

const STRATEGIES_COMMODITIES_GLOBAL: SignOffStrategy[] = [
    { id: 'COM_ENERGY', name: 'Energy Trading Strategy', parentId: 'PL_COM_GLOBAL', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 09:00 AM', currency: 'USD', businessArea: BusinessArea.COMMODITIES,
      region: Region.NORTH_AMERICA,
      previousNetPnL: 150000, currentNetPnL: 165000, pnlTrading: 18000, pnlFxReval: 0, pnlAdjustments: -3000,
      previousTotalAssets: 1000000000, currentTotalAssets: 1010000000, assetChangeTrading: 7500000, assetChangeFxReval: 1000000, assetChangeAdjustments: 1500000,
      previousTotalLiabilities: 750000000, currentTotalLiabilities: 755000000, liabilityChangeTrading: 4000000, liabilityChangeFxReval: 500000, liabilityChangeAdjustments: 500000,
      activityLog: mockCommoditiesActivityLog.slice(0,1).map(a => ({...a, id: a.id + '_COM1'}))
    },
     { id: 'COM_METALS', name: 'Metals Trading Strategy', parentId: 'PL_COM_GLOBAL', status: ProcessStatus.IN_PROGRESS, lastUpdated: '2024-07-29 09:15 AM', currency: 'USD', businessArea: BusinessArea.COMMODITIES,
      region: Region.NON_JAPAN_ASIA,
      previousNetPnL: 150000, currentNetPnL: 165000, pnlTrading: 2000, pnlFxReval: 5000, pnlAdjustments: 8000,
      previousTotalAssets: 1000000000, currentTotalAssets: 1010000000, assetChangeTrading: 7500000, assetChangeFxReval: 1000000, assetChangeAdjustments: 1500000,
      previousTotalLiabilities: 750000000, currentTotalLiabilities: 755000000, liabilityChangeTrading: 4000000, liabilityChangeFxReval: 500000, liabilityChangeAdjustments: 500000,
      activityLog: mockCommoditiesActivityLog.slice(1,2).map(a => ({...a, id: a.id + '_COM2'}))
    }
];

const STRATEGIES_TCM_SN: SignOffStrategy[] = [
  { 
    id: 'SN_FID', name: 'SN FID', parentId: 'PL_TCM_SN', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 11:00 AM', currency: 'USD', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.NORTH_AMERICA,
    previousNetPnL: 200000, currentNetPnL: 210000, pnlTrading: 15000, pnlFxReval: -2000, pnlAdjustments: -3000,
    previousTotalAssets: 1500000000, currentTotalAssets: 1510000000, assetChangeTrading: 8000000, assetChangeFxReval: 1000000, assetChangeAdjustments: 1000000,
    previousTotalLiabilities: 1300000000, currentTotalLiabilities: 1305000000, liabilityChangeTrading: 3000000, liabilityChangeFxReval: 1000000, liabilityChangeAdjustments: 1000000,
    activityLog: []
  },
  { 
    id: 'SN_IED', name: 'SN IED', parentId: 'PL_TCM_SN', status: ProcessStatus.SIGNED_OFF, lastUpdated: '2024-07-29 11:05 AM', currency: 'USD', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    region: Region.NORTH_AMERICA,
    previousNetPnL: 250000, currentNetPnL: 240000, pnlTrading: -5000, pnlFxReval: -8000, pnlAdjustments: 3000,
    previousTotalAssets: 1700000000, currentTotalAssets: 1690000000, assetChangeTrading: -12000000, assetChangeFxReval: 1000000, assetChangeAdjustments: 1000000,
    previousTotalLiabilities: 1500000000, currentTotalLiabilities: 1495000000, liabilityChangeTrading: -6000000, liabilityChangeFxReval: 500000, liabilityChangeAdjustments: 500000,
    activityLog: []
  },
];

const PL_EQ_US_AGG = calculateProductLineAggregates(STRATEGIES_EQ_US);
const PL_EQ_EU_AGG = calculateProductLineAggregates(STRATEGIES_EQ_EU);
const PL_FI_GLOBAL_AGG = calculateProductLineAggregates(STRATEGIES_FI_GLOBAL);
const PL_PB_GLOBAL_AGG = calculateProductLineAggregates(STRATEGIES_PB_GLOBAL);
const PL_COM_GLOBAL_AGG = calculateProductLineAggregates(STRATEGIES_COMMODITIES_GLOBAL);
const PL_TCM_SN_AGG = calculateProductLineAggregates(STRATEGIES_TCM_SN);


/**
 * Mock data for sign-off product lines, categorized by business area.
 * This structure drives the Sign-Off page and includes nested strategies.
 * It's pre-aggregated using helper functions.
 * @type {Record<BusinessArea, SignOffProductLine[]>}
 */
export const MOCK_PRODUCT_LINES_BY_AREA: Record<BusinessArea, SignOffProductLine[]> = {
  [BusinessArea.EQUITIES]: [
    { 
      id: 'PL_EQ_US', name: 'Equities US Product Line', businessArea: BusinessArea.EQUITIES, 
      region: Region.NORTH_AMERICA,
      status: determineProductLineStatus(STRATEGIES_EQ_US), lastUpdated: '2024-07-29 11:00 AM', currency: 'USD',
      currentNetPnL: PL_EQ_US_AGG.currentNetPnL || 0, previousNetPnL: PL_EQ_US_AGG.previousNetPnL || 0,
      currentTotalAssets: PL_EQ_US_AGG.currentTotalAssets || 0, previousTotalAssets: PL_EQ_US_AGG.previousTotalAssets || 0,
      currentTotalLiabilities: PL_EQ_US_AGG.currentTotalLiabilities || 0, previousTotalLiabilities: PL_EQ_US_AGG.previousTotalLiabilities || 0,
      strategies: STRATEGIES_EQ_US,
    },
    { 
      id: 'PL_EQ_EU', name: 'Equities EU Product Line', businessArea: BusinessArea.EQUITIES, 
      region: Region.EMEA,
      status: determineProductLineStatus(STRATEGIES_EQ_EU), lastUpdated: '2024-07-29 12:00 PM', currency: 'EUR',
      currentNetPnL: PL_EQ_EU_AGG.currentNetPnL || 0, previousNetPnL: PL_EQ_EU_AGG.previousNetPnL || 0,
      currentTotalAssets: PL_EQ_EU_AGG.currentTotalAssets || 0, previousTotalAssets: PL_EQ_EU_AGG.previousTotalAssets || 0,
      currentTotalLiabilities: PL_EQ_EU_AGG.currentTotalLiabilities || 0, previousTotalLiabilities: PL_EQ_EU_AGG.previousTotalLiabilities || 0,
      strategies: STRATEGIES_EQ_EU,
    },
  ],
  [BusinessArea.FIXED_INCOME]: [
    {
      id: 'PL_FI_GLOBAL', name: 'Fixed Income Global Product Line', businessArea: BusinessArea.FIXED_INCOME,
      region: Region.EMEA,
      status: determineProductLineStatus(STRATEGIES_FI_GLOBAL), lastUpdated: '2024-07-29 11:30 AM', currency: 'USD',
      currentNetPnL: PL_FI_GLOBAL_AGG.currentNetPnL || 0, previousNetPnL: PL_FI_GLOBAL_AGG.previousNetPnL || 0,
      currentTotalAssets: PL_FI_GLOBAL_AGG.currentTotalAssets || 0, previousTotalAssets: PL_FI_GLOBAL_AGG.previousTotalAssets || 0,
      currentTotalLiabilities: PL_FI_GLOBAL_AGG.currentTotalLiabilities || 0, previousTotalLiabilities: PL_FI_GLOBAL_AGG.previousTotalLiabilities || 0,
      strategies: STRATEGIES_FI_GLOBAL,
    }
  ],
  [BusinessArea.PRIME_BROKERAGE]: [
     {
        id: 'PL_PB_GLOBAL', name: 'Prime Brokerage Global Product Line', businessArea: BusinessArea.PRIME_BROKERAGE,
        region: Region.NORTH_AMERICA,
        status: determineProductLineStatus(STRATEGIES_PB_GLOBAL), // Should be REJECTED
        lastUpdated: '2024-07-29 11:30 AM', currency: 'USD',
        currentNetPnL: PL_PB_GLOBAL_AGG.currentNetPnL || 0, previousNetPnL: PL_PB_GLOBAL_AGG.previousNetPnL || 0,
        currentTotalAssets: PL_PB_GLOBAL_AGG.currentTotalAssets || 0, previousTotalAssets: PL_PB_GLOBAL_AGG.previousTotalAssets || 0,
        currentTotalLiabilities: PL_PB_GLOBAL_AGG.currentTotalLiabilities || 0, previousTotalLiabilities: PL_PB_GLOBAL_AGG.previousTotalLiabilities || 0,
        strategies: STRATEGIES_PB_GLOBAL
    }
  ],
  [BusinessArea.COMMODITIES]: [
     {
        id: 'PL_COM_GLOBAL', name: 'Commodities Global Product Line', businessArea: BusinessArea.COMMODITIES,
        region: Region.NORTH_AMERICA,
        status: determineProductLineStatus(STRATEGIES_COMMODITIES_GLOBAL), // Should be IN_PROGRESS
        lastUpdated: '2024-07-29 09:30 AM', currency: 'USD',
        currentNetPnL: PL_COM_GLOBAL_AGG.currentNetPnL || 0, previousNetPnL: PL_COM_GLOBAL_AGG.previousNetPnL || 0,
        currentTotalAssets: PL_COM_GLOBAL_AGG.currentTotalAssets || 0, previousTotalAssets: PL_COM_GLOBAL_AGG.previousTotalAssets || 0,
        currentTotalLiabilities: PL_COM_GLOBAL_AGG.currentTotalLiabilities || 0, previousTotalLiabilities: PL_COM_GLOBAL_AGG.previousTotalLiabilities || 0,
        strategies: STRATEGIES_COMMODITIES_GLOBAL
    }
  ],
  [BusinessArea.TREASURY_CAPITAL_MARKETS]: [
    { 
      id: 'PL_TCM_SN', name: 'Structured Notes', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS, 
      region: Region.NORTH_AMERICA,
      status: determineProductLineStatus(STRATEGIES_TCM_SN), lastUpdated: '2024-07-29 11:10 AM', currency: 'USD',
      currentNetPnL: PL_TCM_SN_AGG.currentNetPnL || 0, previousNetPnL: PL_TCM_SN_AGG.previousNetPnL || 0,
      currentTotalAssets: PL_TCM_SN_AGG.currentTotalAssets || 0, previousTotalAssets: PL_TCM_SN_AGG.previousTotalAssets || 0,
      currentTotalLiabilities: PL_TCM_SN_AGG.currentTotalLiabilities || 0, previousTotalLiabilities: PL_TCM_SN_AGG.previousTotalLiabilities || 0,
      strategies: STRATEGIES_TCM_SN,
    },
  ]
};


/**
 * Mock data representing financial adjustments.
 * Used on the Adjustments page.
 * @type {Adjustment[]}
 */
export const MOCK_ADJUSTMENTS: Adjustment[] = [
    {
        id: 'ADJ001',
        relatedExceptionId: 'EXC001',
        type: AdjustmentType.PNL_CORRECTION,
        amount: -15000.75,
        currency: 'USD',
        debitAccount: 'SUSPENSE_PNL_ADJ',
        creditAccount: 'EQUITIES_TRADING_PNL_REC',
        justification: 'Correction for FOBO break on AAPL trade EXC001.',
        status: 'APPROVED',
        createdBy: 'Alice Wonderland',
        createdAt: '2024-07-28 11:00 AM',
        businessArea: BusinessArea.EQUITIES,
        productLineId: 'PL_EQ_US', strategyId: 'EQ_US_ALPHA', region: Region.NORTH_AMERICA,
        lastModifiedAt: '2024-07-28 11:30 AM',
        approvedBy: 'Bob The Builder',
        approvedAt: '2024-07-28 11:30 AM',
        suggestedAmount: -15000.75,
        suggestedCurrency: 'USD',
        suggestedDebitAccount: 'SUSPENSE_PNL',
        suggestedCreditAccount: 'EQUITIES_TRADING_PNL',
        suggestedJustification: 'AI Suggestion: Based on FOBO break for AAPL (EXC001), a P&L correction of -15000.75 USD to align with BO figures. Debit Suspense, Credit Trading P&L.'
    },
    {
        id: 'ADJ002',
        type: AdjustmentType.FEE_POSTING,
        amount: -250.00,
        currency: 'USD',
        debitAccount: 'BROKERAGE_FEES_EXPENSE',
        creditAccount: 'CASH_OPERATING',
        justification: 'Monthly brokerage fees for Prime Client A.',
        status: 'SUBMITTED',
        createdBy: 'Charlie Controller',
        createdAt: '2024-07-29 09:15 AM',
        businessArea: BusinessArea.PRIME_BROKERAGE,
        productLineId: 'PL_PB_GLOBAL', strategyId: 'PB_CLIENT_SRV', region: Region.NORTH_AMERICA,
        lastModifiedAt: '2024-07-29 09:15 AM',
        submittedBy: 'Charlie Controller',
        submittedAt: '2024-07-29 09:18 AM',
    },
    {
        id: 'ADJ003',
        relatedExceptionId: 'EXC003',
        type: AdjustmentType.BS_REALIGNMENT,
        amount: 50000.00,
        currency: 'EUR',
        debitAccount: 'FX_UNREALIZED_GAIN_EUR',
        creditAccount: 'FX_REVAL_RESERVE_EUR',
        justification: 'Balance sheet realignment post FX revaluation for USD/EUR spot for EXC003.',
        status: 'DRAFT',
        createdBy: 'David Draftsmon',
        createdAt: '2024-07-29 10:00 AM',
        businessArea: BusinessArea.FIXED_INCOME,
        productLineId: 'PL_FI_GLOBAL', strategyId: 'FI_GBL_RATES', region: Region.EMEA,
        lastModifiedAt: '2024-07-29 10:00 AM',
        suggestedAmount: 48500.00,
        suggestedCurrency: 'EUR',
        suggestedJustification: 'AI Suggestion: Realign EUR FX gain based on intraday volatility. Actual amount may differ from overall position P&L.'
    },
    {
        id: 'ADJ004',
        type: AdjustmentType.TRADE_AMENDMENT,
        amount: 0,
        currency: 'USD',
        debitAccount: 'N/A',
        creditAccount: 'N/A',
        justification: 'Amend trade T-B12345: incorrect counterparty entered.',
        status: 'PENDING_REVIEW',
        createdBy: 'Valerie User',
        createdAt: '2024-07-29 14:00 PM',
        businessArea: BusinessArea.EQUITIES,
        productLineId: 'PL_EQ_EU', strategyId: 'EQ_EU_ALPHA', region: Region.EMEA,
        lastModifiedAt: '2024-07-29 14:00 PM',
    },
    {
        id: 'ADJ005',
        relatedExceptionId: 'EXC010',
        type: AdjustmentType.PNL_CORRECTION,
        amount: -11000.00,
        currency: 'USD',
        debitAccount: 'TCM_PNL_ADJ',
        creditAccount: 'TCM_VALUATION_RESERVE',
        justification: 'Partial P&L correction for valuation break on SN-FID-XYZ-001, pending full review.',
        status: 'PENDING_REVIEW',
        createdBy: 'Valerie User',
        createdAt: '2024-07-29 15:00 PM',
        businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
        productLineId: 'PL_TCM_SN', strategyId: 'SN_FID', region: Region.NORTH_AMERICA,
    },
];

/**
 * Mock data for commentary templates.
 * Used on the Commentary page to allow users to create new commentaries from a predefined structure.
 * @type {CommentaryTemplate[]}
 */
export const MOCK_COMMENTARY_TEMPLATES: CommentaryTemplate[] = [
  {
    type: CommentaryType.MARKET,
    name: 'Market Event Impact',
    description: 'Explain P&L movements due to market events.',
    defaultSections: [
      { title: 'Market Overview', aiPlaceholder: 'e.g., Summary of key indices performance, volatility changes...' },
      { title: 'Impact on Portfolio', aiPlaceholder: 'e.g., Specific assets affected, P&L attribution to market factors...' },
      { title: 'Outlook & Actions', aiPlaceholder: 'e.g., Expected future impact, planned hedging strategies...' },
    ],
  },
  {
    type: CommentaryType.OPERATIONAL_RISK,
    name: 'Operational Risk Event',
    description: 'Highlight operational issues that impacted financials.',
    defaultSections: [
      { title: 'Incident Description', aiPlaceholder: 'e.g., System outage, data feed error, manual error type...' },
      { title: 'Financial Impact Assessment', aiPlaceholder: 'e.g., Quantify losses or gains due to the incident, affected accounts...' },
      { title: 'Remediation Steps', aiPlaceholder: 'e.g., Actions taken to resolve, preventative measures implemented...' },
    ],
  },
  {
    type: CommentaryType.BALANCE_SHEET_FLUCTUATION,
    name: 'Balance Sheet Fluctuation Analysis',
    description: 'Provide reasons for significant changes in balance sheet accounts.',
    defaultSections: [
      { title: 'Account(s) Analyzed', aiPlaceholder: 'e.g., Specify GL accounts or balance sheet line items...' },
      { title: 'Key Drivers of Change', aiPlaceholder: 'e.g., New major trades, funding changes, FX revaluations...' },
      { title: 'Period-over-Period Comparison', aiPlaceholder: 'e.g., DoD, WoW, MoM variance analysis...' },
    ],
  },
  {
    type: CommentaryType.T0_T1_COMMENTARY,
    name: 'T0/T1 P&L Commentary',
    description: 'Daily commentary on P&L drivers and significant movements observed on Trade Date (T0) or T+1.',
    defaultSections: [
      { title: 'Overall P&L Summary (T0/T1)', aiPlaceholder: 'e.g., Net P&L for the desk/strategy, comparison to budget/prior day...' },
      { title: 'Top P&L Drivers (Positive)', aiPlaceholder: 'e.g., List top 3-5 positions/trades contributing to gains, with reasons...' },
      { title: 'Top P&L Drivers (Negative)', aiPlaceholder: 'e.g., List top 3-5 positions/trades contributing to losses, with reasons...' },
      { title: 'Significant Events/Breaks', aiPlaceholder: 'e.g., Any notable market events, operational issues, or large breaks affecting P&L...' },
      { title: 'Trader Outlook/Focus for Next Day', aiPlaceholder: 'e.g., Key positions to monitor, expected market catalysts...' }
    ],
  },
  {
    type: CommentaryType.DAILY_TRADER_PACK,
    name: 'Daily Trader Pack Summary',
    description: 'Consolidated notes and observations for the daily trader information pack.',
    defaultSections: [
      { title: 'Morning Briefing Highlights', aiPlaceholder: 'e.g., Key takeaways from economic releases, overnight market moves...' },
      { title: 'Portfolio Positioning Review', aiPlaceholder: 'e.g., Current risk exposures, concentration analysis...' },
      { title: 'Key Client Activity/Flows', aiPlaceholder: 'e.g., Notable client trades, changes in client sentiment...' },
      { title: 'Upcoming Market Catalysts', aiPlaceholder: 'e.g., Economic data releases, earnings reports, geopolitical events to watch...' },
      { title: 'Internal Risk/Limit Alerts', aiPlaceholder: 'e.g., Any breaches or near-breaches of trading limits or risk parameters...' }
    ],
  },
];

const generateMockSections = (template: CommentaryTemplate | undefined, commentaryTitle: string): CommentarySection[] => {
  if (!template) {
    return [
      { title: "General Summary", userContent: `User content for General Summary in ${commentaryTitle}.`, aiSuggestion: "AI could provide a general overview here related to the title." },
      { title: "Key Observations", userContent: `User input for Key Observations in ${commentaryTitle}.`, aiSuggestion: "AI could list potential key talking points based on the commentary type." }
    ];
  }
  return template.defaultSections.map(sectionDef => ({
    title: sectionDef.title,
    userContent: `User input for ${sectionDef.title} in ${commentaryTitle}. Lorem ipsum dolor sit amet, consectetur adipiscing elit.`,
    aiSuggestion: sectionDef.aiPlaceholder ? `AI Suggestion for ${sectionDef.title}: ${sectionDef.aiPlaceholder} Specific example: AI could note that recent volatility in tech stocks might be a key market event to discuss for market commentary.` : `Generic AI suggestion for ${sectionDef.title}.`,
  }));
};

/**
 * Mock data for existing commentary documents.
 * Used on the Commentary page.
 * @type {Commentary[]}
 */
export const MOCK_COMMENTARIES: Commentary[] = [
  {
    id: 'COM001',
    type: CommentaryType.MARKET,
    title: 'Market Volatility Impact - July 29',
    author: 'John Analyst',
    dateCreated: '2024-07-29T10:00:00Z',
    businessArea: BusinessArea.EQUITIES,
    productLineId: 'PL_EQ_US', strategyId: 'EQ_US_ALPHA', region: Region.NORTH_AMERICA,
    sections: generateMockSections(MOCK_COMMENTARY_TEMPLATES.find(t => t.type === CommentaryType.MARKET), 'Market Volatility Impact - July 29'),
    linkedItems: ['EXC001', 'AAPL.OQ'],
    tags: ['volatility', 'equities', 'nasdaq'],
  },
  {
    id: 'COM002',
    type: CommentaryType.T0_T1_COMMENTARY,
    title: 'Equities Desk T0 P&L - July 28',
    author: 'Valerie User',
    dateCreated: '2024-07-28T17:30:00Z',
    businessArea: BusinessArea.EQUITIES,
    productLineId: 'PL_EQ_US', strategyId: 'ALL', region: Region.NORTH_AMERICA,
    sections: generateMockSections(MOCK_COMMENTARY_TEMPLATES.find(t => t.type === CommentaryType.T0_T1_COMMENTARY), 'Equities Desk T0 P&L - July 28'),
    linkedItems: ['PL_EQ_US'],
    tags: ['t0', 'p&l', 'equities', 'daily'],
  },
  {
    id: 'COM003',
    type: CommentaryType.DAILY_TRADER_PACK,
    title: 'Fixed Income Trader Pack - July 29',
    author: 'Mike Trader',
    dateCreated: '2024-07-29T08:15:00Z',
    businessArea: BusinessArea.FIXED_INCOME,
    productLineId: 'PL_FI_GLOBAL', strategyId: 'ALL', region: Region.EMEA,
    sections: generateMockSections(MOCK_COMMENTARY_TEMPLATES.find(t => t.type === CommentaryType.DAILY_TRADER_PACK), 'Fixed Income Trader Pack - July 29'),
    linkedItems: ['PL_FI_GLOBAL', 'USD_RATES_CURVE'],
    tags: ['fixed income', 'rates', 'daily pack', 'trading notes'],
  },
  {
    id: 'COM004',
    type: CommentaryType.MARKET,
    title: 'Structured Notes Market Update - July 29',
    author: 'John Analyst',
    dateCreated: '2024-07-29T14:00:00Z',
    businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
    productLineId: 'PL_TCM_SN', strategyId: 'ALL', region: Region.NORTH_AMERICA,
    sections: generateMockSections(MOCK_COMMENTARY_TEMPLATES.find(t => t.type === CommentaryType.MARKET), 'Structured Notes Market Update - July 29'),
    tags: ['structured notes', 'tcm', 'volatility'],
  },
];

/**
 * Mock data for distribution lists for sending reports.
 * Used in the Send Report modal on the Analytics page.
 * @type {DistributionList[]}
 */
export const MOCK_DISTRIBUTION_LISTS: DistributionList[] = [
  { id: 'dl_seniormgmt', name: 'Senior Management', description: 'C-suite and Head of Departments' },
  { id: 'dl_equitydesk', name: 'Equities Desk', description: 'All traders and analysts on the Equities team' },
  { id: 'dl_fixedincomedesk', name: 'Fixed Income Desk', description: 'All traders and analysts on the Fixed Income team' },
  { id: 'dl_compliance', name: 'Compliance Team', description: 'Global compliance officers' },
  { id: 'dl_risk', name: 'Risk Management', description: 'Market Risk and Operational Risk teams' },
  { id: 'dl_financecontrollers', name: 'Finance Controllers', description: 'Product control and financial reporting teams' },
  { id: 'dl_traders', name: 'Trading Team (All Areas)', description: 'Generic trading team list' },
  { id: 'dl_ops', name: 'Operations Team (All Areas)', description: 'Generic operations team list' },
];

const mockEqT0T1BreakDetails: PreSignOffBreakDetail[] = [
    { id: 'BRK_T0T1_001', description: 'P&L Mismatch for AAPL.OQ', severity: 'High', relatedEntity: 'AAPL.OQ' },
    { id: 'BRK_T0T1_002', description: 'Trade booking error for MSFT.OQ', severity: 'Medium', relatedEntity: 'MSFT.OQ T-12345' },
];

const mockFiCurveBreakDetails: PreSignOffBreakDetail[] = [
    { id: 'BRK_CURVE_001', description: 'EUR curve stale point at 5Y tenor', severity: 'Medium', relatedEntity: 'EURIBOR 5Y' },
    { id: 'BRK_CURVE_002', description: 'USD SOFR curve missing short-end data', severity: 'High', relatedEntity: 'USD SOFR O/N' },
];


/**
 * Mock data for pre-sign-off automated tasks, categorized by business area.
 * Used on the Pre-Sign Off page.
 * @type {Record<BusinessArea, PreSignOffTask[]>}
 */
export const MOCK_PRE_SIGN_OFF_TASKS_BY_AREA: Record<BusinessArea, PreSignOffTask[]> = {
  [BusinessArea.EQUITIES]: [
    {
      id: 'eq_t0t1', title: 'T0 vs T+1 Data Validation', businessArea: BusinessArea.EQUITIES,
      productLineId: 'PL_EQ_US', strategyId: 'ALL', region: Region.NORTH_AMERICA,
      description: 'Compare Trade Date (T0) records with settlement day (T+1) records for discrepancies in trade details, valuations, and P&L.',
      status: PreSignOffTaskStatus.COMPLETED_BREAKS, responsibleTeam: 'Trade Support',
      lastRun: '2024-07-30 08:00 AM', breakCount: 2,
      assignedToUser: 'Valerie User',
      breakDetails: mockEqT0T1BreakDetails,
    },
    {
      id: 'eq_eve', title: 'End of Value (EVE) Data Check', businessArea: BusinessArea.EQUITIES,
      productLineId: 'PL_EQ_EU', strategyId: 'ALL', region: Region.EMEA,
      description: 'Verify all positions and cash balances are correctly valued as of the end of the value date, including corporate actions.',
      status: PreSignOffTaskStatus.PENDING, responsibleTeam: 'Valuation Control',
    },
    {
      id: 'eq_feed_health', title: 'Critical Feed Health Check', businessArea: BusinessArea.EQUITIES,
      productLineId: 'ALL', strategyId: 'ALL', region: Region.NORTH_AMERICA,
      description: 'Ensure all primary market data and internal feeds for equities are stable and up-to-date.',
      status: PreSignOffTaskStatus.COMPLETED_OK, lastRun: '2024-07-30 07:00 AM', responsibleTeam: 'Data Ops',
      assignedToUser: 'Bob Ops',
    },
  ],
  [BusinessArea.FIXED_INCOME]: [
    {
      id: 'fi_curve', title: 'Yield Curve Integrity Check', businessArea: BusinessArea.FIXED_INCOME,
      productLineId: 'PL_FI_GLOBAL', strategyId: 'ALL', region: Region.EMEA,
      description: 'Verify the integrity and consistency of yield curves used for valuation.',
      status: PreSignOffTaskStatus.COMPLETED_BREAKS, lastRun: '2024-07-30 08:15 AM', breakCount: 2, responsibleTeam: 'Market Risk',
      assignedToUser: 'Charles Controller',
      breakDetails: mockFiCurveBreakDetails,
    },
  ],
  [BusinessArea.TREASURY_CAPITAL_MARKETS]: [
    {
      id: 'tcm_model_val', title: 'SN Model Validation Check', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS,
      productLineId: 'PL_TCM_SN', strategyId: 'ALL', region: Region.NORTH_AMERICA,
      description: 'Verify that all structured note models are using the latest certified market data inputs.',
      status: PreSignOffTaskStatus.COMPLETED_OK, responsibleTeam: 'Quant Team',
      lastRun: '2024-07-30 07:30 AM',
      assignedToUser: 'Bob Ops',
    },
  ],
  [BusinessArea.PRIME_BROKERAGE]: [],
  [BusinessArea.COMMODITIES]: [],
};

/**
 * Mock data for manual actions available on the Pre-Sign Off page, categorized by business area.
 * @type {Record<BusinessArea, PreSignOffAction[]>}
 */
export const MOCK_PRE_SIGN_OFF_ACTIONS_BY_AREA: Record<BusinessArea, PreSignOffAction[]> = {
    [BusinessArea.EQUITIES]: [
        {
            id: 'eq_financing_pnl',
            title: 'Financing PNL Flattening',
            description: 'Create an adjustment to sweep PNL from financing activities (stock loan, repos) to the central financing book.',
            icon: CalculatorIcon,
            businessArea: BusinessArea.EQUITIES,
            adjustmentType: AdjustmentType.FINANCING_PNL_FLATTENING,
        },
    ],
    [BusinessArea.FIXED_INCOME]: [],
    [BusinessArea.PRIME_BROKERAGE]: [],
    [BusinessArea.COMMODITIES]: [],
    [BusinessArea.TREASURY_CAPITAL_MARKETS]: [],
};

/**
 * Mock data representing the application's technology stack.
 * Used on the Documentation page.
 * @type {StackItem[]}
 */
export const MOCK_STACK_ITEMS: StackItem[] = [
    { name: 'React 18', category: 'Frontend', description: 'Core UI library for building the user interface components.' },
    { name: 'TypeScript', category: 'Frontend', description: 'Provides static typing for more robust and maintainable code.' },
    { name: 'Tailwind CSS', category: 'Frontend', description: 'A utility-first CSS framework for rapid UI development.' },
    { name: 'Recharts', category: 'Frontend', description: 'A composable charting library built on React components.' },
    { name: 'Google Gemini API', category: 'API', description: 'Used for AI-powered features like RCA suggestions and commentary assistance.' },
    { name: 'Vite', category: 'Tooling', description: 'Next-generation frontend tooling for a faster development experience.' },
    { name: 'ESM.sh', category: 'Tooling', description: 'A fast, global content delivery network for ES modules.' },
    { name: 'Internal Cloud', category: 'Platform', description: 'Proprietary cloud platform for application hosting and services.' },
];

/**
 * Mock data for comprehensive trade objects.
 * Used on the Investigation Workbench page.
 * @type {InvestigativeTrade[]}
 */
export const MOCK_INVESTIGATIVE_TRADES: InvestigativeTrade[] = [
  {
    id: 'T-EQ-98765', businessArea: BusinessArea.EQUITIES, product: 'AAPL.OQ', quantity: 10000, price: 175.50, currency: 'USD',
    status: 'Booked', tradeDate: '2024-07-29', productLineId: 'PL_EQ_US', strategyId: 'EQ_US_ALPHA', region: Region.NORTH_AMERICA,
    preTrade: { approvalId: 'PTA-123', limitCheckStatus: 'Approved', timestamp: '2024-07-29 09:14:00 EST', checkedBy: 'AutoLimitSys' },
    tradeCapture: { bookingSystem: 'TradeMaster', tradeTime: '2024-07-29 09:15:30 EST', traderId: 'TraderX', salesperson: 'SalesY' },
    risk: { delta: 10000, gamma: 500, vega: 2500, theta: -1500, var99: 120000 },
    ops: { confirmationStatus: 'Confirmed', settlementStatus: 'Unsettled', settlementDate: '2024-07-31' },
    ledger: { journalId: 'JRN-54321', debitAccount: 'ASSET_EQUITY_AAPL', creditAccount: 'CASH_CLEARING', amount: 1755000, currency: 'USD', postingDate: '2024-07-29' }
  },
  {
    id: 'T-FI-12345', businessArea: BusinessArea.FIXED_INCOME, product: 'US10YT=RR', quantity: 5000000, price: 98.75, currency: 'USD',
    status: 'Booked', tradeDate: '2024-07-29', productLineId: 'PL_FI_GLOBAL', strategyId: 'FI_GBL_RATES', region: Region.EMEA,
    preTrade: { approvalId: 'PTA-124', limitCheckStatus: 'Approved', timestamp: '2024-07-29 10:01:00 EST', checkedBy: 'AutoLimitSys' },
    tradeCapture: { bookingSystem: 'BookItAll', tradeTime: '2024-07-29 10:02:15 EST', traderId: 'TraderY', salesperson: 'N/A' },
    risk: { delta: 45000, gamma: 200, vega: 12000, theta: -800, var99: 75000 },
    ops: { confirmationStatus: 'Unconfirmed', settlementStatus: 'Unsettled', settlementDate: '2024-07-30' },
    ledger: { journalId: 'JRN-54322', debitAccount: 'ASSET_BOND_US10Y', creditAccount: 'CASH_CLEARING', amount: 4937500, currency: 'USD', postingDate: '2024-07-29' }
  },
  {
    id: 'T-TCM-55555', businessArea: BusinessArea.TREASURY_CAPITAL_MARKETS, product: 'SN-FID-XYZ-001', quantity: 11000000, price: 102.50, currency: 'USD',
    status: 'Booked', tradeDate: '2024-07-29', productLineId: 'PL_TCM_SN', strategyId: 'SN_FID', region: Region.NORTH_AMERICA,
    preTrade: { approvalId: 'PTA-125', limitCheckStatus: 'Approved', timestamp: '2024-07-29 11:00:00 EST', checkedBy: 'AutoLimitSys' },
    tradeCapture: { bookingSystem: 'TradeMaster', tradeTime: '2024-07-29 11:01:10 EST', traderId: 'TraderTCM', salesperson: 'SalesTCM' },
    risk: { delta: 35000, gamma: 120, vega: 8000, theta: -400, var99: 95000 },
    ops: { confirmationStatus: 'Confirmed', settlementStatus: 'Unsettled', settlementDate: '2024-08-05' },
    ledger: { journalId: 'JRN-54323', debitAccount: 'ASSET_SN_XYZ', creditAccount: 'CASH_CLEARING', amount: 11275000, currency: 'USD', postingDate: '2024-07-29' }
  },
];

/**
 * Mock data for software release trains.
 * Used on the Documentation page to show deployment status.
 * @type {ReleaseTrain[]}
 */
export const MOCK_RELEASE_TRAINS: ReleaseTrain[] = [
    {
        id: 'train_24_w31', name: 'Feature Train - Week 31', version: '2.3.0', status: 'Active',
        stages: [
            { name: 'Build', status: DeploymentStatus.SUCCESS, completedAt: '2024-07-30 10:00 AM' },
            { name: 'Unit Tests', status: DeploymentStatus.SUCCESS, completedAt: '2024-07-30 10:05 AM' },
            { name: 'Integration Tests', status: DeploymentStatus.IN_PROGRESS, startedAt: '2024-07-30 10:05 AM' },
            { name: 'Deploy to Staging', status: DeploymentStatus.PENDING },
            { name: 'UAT', status: DeploymentStatus.PENDING },
            { name: 'Deploy to Production', status: DeploymentStatus.PENDING },
        ]
    },
];

/**
 * Mock data for the P&L summary on the Trader Review page.
 * @type {TraderPnlSummary}
 */
export const MOCK_TRADER_PNL_SUMMARY: TraderPnlSummary = {
  dod: 150000,
  mtd: 1250000,
  ytd: 15750000,
  currency: 'USD',
};

/**
 * Mock data for Frequently Asked Questions.
 * Used in the Help Widget.
 * @type {FAQ[]}
 */
export const MOCK_FAQS: FAQ[] = [
  { id: 'faq-1', question: 'How do I create an adjustment for an exception?', answer: "From the Exception Summary page, right-click on an exception and select 'Create Adjustment'. This will open the adjustment modal with the exception details pre-filled.", keywords: ['adjustment', 'exception', 'create'] },
];


/**
 * Mock data representing cases for the Case Management page.
 * Cases are formal follow-ups on exceptions.
 * @type {Case[]}
 */
export const MOCK_CASES: Case[] = [
  {
    id: 'CASE-001', title: 'P&L Mismatch on AAPL (EXC001)', exceptionId: 'EXC001',
    assignedTo: 'Valerie User', status: CaseStatus.AWAITING_RESPONSE, dateOpened: '2024-07-28T10:30:00Z',
    region: Region.NORTH_AMERICA,
    comments: [
      { user: 'Charles Controller', timestamp: '2024-07-28T11:00:00Z', comment: 'There is a P&L mismatch of $15,000.75. Please investigate the booking for trade T-A98765.' },
      { user: 'Valerie User', timestamp: '2024-07-28T14:00:00Z', comment: 'Looking into it. It seems a dividend was not booked correctly.' },
      { user: 'Charles Controller', timestamp: '2024-07-29T09:00:00Z', comment: 'Thanks. Let me know when you have responded with the adjustment details.' },
    ]
  },
  {
    id: 'CASE-002', title: 'DoD P&L change investigation (EXC003)', exceptionId: 'EXC003',
    assignedTo: 'Charles Controller', status: CaseStatus.OPEN, dateOpened: '2024-07-29T09:15:00Z',
    region: Region.EMEA,
    comments: [ { user: 'System', timestamp: '2024-07-29T09:15:00Z', comment: 'Case automatically opened for large DoD P&L change on USD/EUR.' },]
  },
  {
    id: 'CASE-003', title: 'Vendor valuation difference on GOOG (EXC002)', exceptionId: 'EXC002',
    assignedTo: 'Valerie User', status: CaseStatus.IN_PROGRESS, dateOpened: '2024-07-28T11:05:00Z',
    region: Region.NORTH_AMERICA,
    comments: [
      { user: 'Charles Controller', timestamp: '2024-07-28T11:10:00Z', comment: 'Valerie, can you please check the vendor price feed for GOOG? There appears to be a discrepancy.' },
      { user: 'Valerie User', timestamp: '2024-07-28T15:00:00Z', comment: 'Confirmed with vendor, they had a stale price. They are correcting it. I will monitor and close this case once the price is updated in our system.' },
    ]
  },
  {
    id: 'CASE-004', title: 'Valuation discrepancy on SN (EXC010)', exceptionId: 'EXC010',
    assignedTo: 'Charles Controller', status: CaseStatus.OPEN, dateOpened: '2024-07-29T10:30:00Z',
    region: Region.NORTH_AMERICA,
    comments: [
      { user: 'System', timestamp: '2024-07-29T10:30:00Z', comment: 'Case automatically opened for new high-value VRS break in Treasury Capital Markets.' },
    ]
  },
];
