import React, { useState, useEffect } from 'react';
import { Exception, ExceptionStatus, ExceptionCategory } from '../types';
import Modal from './Modal';
import { LightbulbIcon } from './icons';

/**
 * @interface ExceptionDetailModalProps
 * Defines the props for the ExceptionDetailModal component.
 * @property {boolean} isOpen - Controls whether the modal is visible.
 * @property {() => void} onClose - Function to call when the modal should be closed.
 * @property {Exception | null} exception - The exception object to display details for.
 * @property {(updatedException: Exception) => void} onUpdateException - Callback to update the exception in the global state.
 * @property {(exception: Exception) => void} onInitiateAdjustment - Callback to trigger the opening of an adjustment modal for this exception.
 */
interface ExceptionDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  exception: Exception | null;
  onUpdateException: (updatedException: Exception) => void;
  onInitiateAdjustment: (exception: Exception) => void;
}

/**
 * A modal component for displaying the detailed information of a single financial exception.
 * It allows users to view all data points, add Root Cause Analysis (RCA) commentary,
 * and initiate an adjustment to resolve the exception.
 * @param {ExceptionDetailModalProps} props - The props for the component.
 * @returns {JSX.Element | null} The rendered modal or null if not open or no exception is provided.
 */
const ExceptionDetailModal: React.FC<ExceptionDetailModalProps> = ({ 
    isOpen, 
    onClose, 
    exception, 
    onUpdateException,
    onInitiateAdjustment 
}) => {
  /** State to manage the user-entered Root Cause Analysis commentary. */
  const [rcaComment, setRcaComment] = useState('');

  // Effect to sync the local RCA comment state with the exception prop when it changes.
  useEffect(() => {
    if (exception) {
      setRcaComment(exception.rcaCommentary || '');
    }
  }, [exception]);

  if (!exception) return null;

  /**
   * Handles saving the user's RCA commentary.
   * Updates the exception's status to 'In Review'.
   */
  const handleSaveRca = () => {
    // Basic validation for high-value exceptions
    if (Math.abs(exception.financialImpact) > 10000 && rcaComment.trim() === '') {
        alert("User RCA Commentary cannot be empty for high-value exceptions.");
        return;
    }
    onUpdateException({ ...exception, rcaCommentary: rcaComment, status: ExceptionStatus.IN_REVIEW });
  };
  
  /**
   * Triggers the adjustment creation process for the current exception.
   */
  const handleTriggerAdjustment = () => {
    onInitiateAdjustment(exception);
  };
  
  /**
   * Simulates a drill-down action for a specific data point.
   * In a real application, this would navigate to a different page or open another modal.
   * @param {string} detailKey - The key of the detail being drilled into.
   * @param {string | number} detailValue - The value of the detail.
   */
  const handleSimulateFurtherDrilldown = (detailKey: string, detailValue: string | number) => {
    alert(`Simulating drill-down for ${detailKey}: ${detailValue}\n(In a real app, this would navigate or show more data)`);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Exception Details: ${exception.id}`} size="xl">
      <div className="space-y-4 text-sm">
        {/* Basic Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div><strong>ID:</strong> <span className="text-sky-700 font-medium">{exception.id}</span></div>
            <div><strong>Category:</strong> <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                exception.category === ExceptionCategory.FOBO ? 'bg-red-100 text-red-700' :
                exception.category === ExceptionCategory.VRS ? 'bg-yellow-100 text-yellow-700' :
                exception.category === ExceptionCategory.DOD ? 'bg-purple-100 text-purple-700' :
                exception.category === ExceptionCategory.ATTRIBUTION ? 'bg-indigo-100 text-indigo-700' :
                exception.category === ExceptionCategory.CUSTOM_RULES ? 'bg-teal-100 text-teal-700' :
                'bg-gray-100 text-gray-700'
            }`}>{exception.category}</span></div>
            <div><strong>Position ID:</strong> {exception.positionId}</div>
            <div><strong>Financial Impact:</strong> <span className={`${exception.financialImpact >= 0 ? 'text-green-700' : 'text-red-700'} font-semibold`}>{exception.financialImpact.toLocaleString(undefined, {style:'currency', currency: exception.currency})}</span></div>
            <div><strong>Status:</strong> <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                exception.status === ExceptionStatus.OPEN ? 'bg-orange-100 text-orange-700' :
                exception.status === ExceptionStatus.IN_REVIEW ? 'bg-blue-100 text-blue-700' :
                exception.status === ExceptionStatus.PENDING_ADJUSTMENT ? 'bg-yellow-100 text-yellow-700' :
                exception.status === ExceptionStatus.RESOLVED || exception.status === ExceptionStatus.CLOSED ? 'bg-green-100 text-green-700' :
                'bg-gray-100 text-gray-700'
            }`}>{exception.status}</span></div>
            <div><strong>Date Identified:</strong> {new Date(exception.dateIdentified).toLocaleDateString()}</div>
            <div><strong>Business Area:</strong> {exception.businessArea}</div>
            {exception.assignedTo && <div><strong>Assigned To:</strong> {exception.assignedTo}</div>}
        </div>
        
        <p><strong>Description:</strong> {exception.description}</p>

        {/* Details Section */}
        {exception.details && Object.keys(exception.details).length > 0 && (
          <div>
            <h4 className="font-semibold text-slate-700 mb-1">Underlying Data & Attributes:</h4>
            <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
                {Object.entries(exception.details).map(([key, value]) => (
                  <li key={key} className="flex justify-between items-center">
                    <span><strong>{key}:</strong> {typeof value === 'number' ? value.toLocaleString() : value}</span>
                    {(key.toLowerCase().includes('trade id') || key.toLowerCase().includes('position id') || key.toLowerCase().includes('gl account')) && (
                       <button 
                         onClick={() => handleSimulateFurtherDrilldown(key, value)}
                         className="ml-2 text-xs text-sky-600 hover:text-sky-800 underline"
                       >
                         (details)
                       </button>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
        
        {/* AI RCA Commentary Section */}
        {exception.aiRcaCommentary && (
          <div>
            <h4 className="font-semibold text-slate-700 mb-1 flex items-center">
              <LightbulbIcon className="w-5 h-5 mr-2 text-yellow-500" />
              AI Suggested Root Cause Analysis:
            </h4>
            <div className="bg-sky-50 p-3 rounded-md border border-sky-200 text-slate-700 text-xs italic">
              <p style={{whiteSpace: "pre-wrap"}}>{exception.aiRcaCommentary}</p>
            </div>
          </div>
        )}

        {/* User RCA Commentary Section */}
        <div>
          <h4 className="font-semibold text-slate-700 mb-1">User RCA Commentary:</h4>
          <textarea
            value={rcaComment}
            onChange={(e) => setRcaComment(e.target.value)}
            rows={3}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
            placeholder="Enter your Root Cause Analysis commentary here..."
          />
           {Math.abs(exception.financialImpact) > 10000 && <p className="text-xs text-red-600 mt-1">User RCA commentary is mandatory for high-value exceptions before marking as 'In Review' or 'Pending Adjustment'.</p>}
        </div>
        
        {/* History Section */}
        {exception.history && exception.history.length > 0 && (
          <div>
            <h4 className="font-semibold text-slate-700 mb-1">Historical Context:</h4>
            <div className="bg-slate-50 p-3 rounded-md border border-slate-200 max-h-32 overflow-y-auto">
              <ul className="space-y-1 text-xs">
                {exception.history.map((entry, index) => (
                  <li key={index}><strong>{new Date(entry.timestamp).toLocaleString()}:</strong> {entry.action} (by {entry.user})</li>
                ))}
              </ul>
            </div>
          </div>
        )}

        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 border-t pt-4">
          <button 
            onClick={handleTriggerAdjustment}
            className="px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition-colors text-sm font-medium disabled:opacity-50"
            disabled={exception.status === ExceptionStatus.RESOLVED || exception.status === ExceptionStatus.CLOSED}
          >
            Initiate Adjustment
          </button>
          <button 
            onClick={handleSaveRca}
            className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium disabled:opacity-50"
            disabled={exception.status === ExceptionStatus.RESOLVED || exception.status === ExceptionStatus.CLOSED}
          >
            Save RCA & Mark In Review
          </button>
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium"
          >
            Close Details
          </button>
        </div>
         { Math.abs(exception.financialImpact) > 1000 && !exception.aiRcaCommentary && ( // Show only if no specific AI RCA is present
            <p className="text-xs text-slate-500 mt-2 text-center">
                System Suggests Adjustment (example): Approx. { (exception.financialImpact * 0.8).toLocaleString(undefined, {style:'currency', currency: exception.currency}) } (based on historical patterns for similar exceptions)
            </p>
        )}
      </div>
    </Modal>
  );
};

export default ExceptionDetailModal;
