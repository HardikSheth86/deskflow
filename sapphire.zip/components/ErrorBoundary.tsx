import React, { Component, ReactNode } from 'react';
import DashboardCard from './DashboardCard';
import { XCircleIcon } from './icons';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(_: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // You can also log the error to an error reporting service
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <div className="flex items-center justify-center h-screen bg-slate-100 p-8">
            <DashboardCard title={<div className="flex items-center text-red-600"><XCircleIcon className="w-6 h-6 mr-2" /> Application Error</div>}>
                <div className="text-center">
                    <p className="text-slate-700">Sorry, something went wrong.</p>
                    <p className="text-slate-500 text-sm mt-2">We've been notified of the issue. Please refresh the page to try again.</p>
                    <button 
                        onClick={() => window.location.reload()}
                        className="mt-4 px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700"
                    >
                        Refresh Page
                    </button>
                </div>
            </DashboardCard>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
