import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { DistributionList } from '../types';
import { MOCK_DISTRIBUTION_LISTS } from '../constants'; // For recipient options
import { BellAlertIcon, UsersIcon, SendIcon as ActualSendIcon } from './icons';

interface SendBreaksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendNotification: (breakIds: string, recipientListIds: string[], customMessage: string) => void;
  defaultBreakIds?: string; // Optional if pre-filled
}

const SendBreaksModal: React.FC<SendBreaksModalProps> = ({
  isOpen,
  onClose,
  onSendNotification,
  defaultBreakIds = '',
}) => {
  const [breakIds, setBreakIds] = useState(defaultBreakIds);
  const [selectedRecipientListIds, setSelectedRecipientListIds] = useState<string[]>([]);
  const [customMessage, setCustomMessage] = useState('');

  // Filter for relevant recipient lists
  const relevantRecipientLists = MOCK_DISTRIBUTION_LISTS.filter(
    list => list.id === 'dl_traders' || list.id === 'dl_ops'
  );

  useEffect(() => {
    if (isOpen) {
      setBreakIds(defaultBreakIds);
      setSelectedRecipientListIds([]);
      setCustomMessage('');
    }
  }, [isOpen, defaultBreakIds]);

  const handleListSelectionChange = (listId: string) => {
    setSelectedRecipientListIds(prev =>
      prev.includes(listId) ? prev.filter(id => id !== listId) : [...prev, listId]
    );
  };

  const handleSubmit = () => {
    if (!breakIds.trim()) {
      alert('Please enter the Break IDs to include in the notification.');
      return;
    }
    if (selectedRecipientListIds.length === 0) {
      alert('Please select at least one recipient team.');
      return;
    }
    onSendNotification(breakIds.trim(), selectedRecipientListIds, customMessage.trim());
    onClose(); 
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Send Break Notification" size="lg">
      <div className="space-y-6 text-sm">
        <div>
          <label htmlFor="break-ids" className="block font-semibold text-slate-700 mb-1">
            Break IDs (comma-separated)
          </label>
          <input
            type="text"
            id="break-ids"
            value={breakIds}
            onChange={(e) => setBreakIds(e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
            placeholder="e.g., EXC001, EXC003, EXC007"
          />
        </div>
        
        <div>
          <h4 className="font-semibold text-slate-700 mb-2 flex items-center">
            <UsersIcon className="w-5 h-5 mr-2 text-sky-600" />
            Select Recipient Teams
          </h4>
          <div className="space-y-2 p-2 bg-slate-50 border border-slate-200 rounded-md">
            {relevantRecipientLists.length > 0 ? relevantRecipientLists.map(list => (
              <div key={list.id} className="flex items-center">
                <input
                  type="checkbox"
                  id={`recipientlist-${list.id}`}
                  checked={selectedRecipientListIds.includes(list.id)}
                  onChange={() => handleListSelectionChange(list.id)}
                  className="h-4 w-4 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                />
                <label htmlFor={`recipientlist-${list.id}`} className="ml-2 text-slate-700">
                  {list.name}
                  {list.description && <span className="text-xs text-slate-500 ml-1">({list.description})</span>}
                </label>
              </div>
            )) : <p className="text-slate-500">No Trader/Ops distribution lists configured.</p>}
          </div>
        </div>

        <div>
          <label htmlFor="custom-message" className="block font-semibold text-slate-700 mb-1">
            Custom Message (Optional)
          </label>
          <textarea
            id="custom-message"
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
            rows={3}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
            placeholder="Add any specific instructions or context for the recipients..."
          />
        </div>

        <div className="mt-6 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 border-t pt-4">
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 transition-colors text-sm font-medium flex items-center justify-center"
          >
            <ActualSendIcon className="w-5 h-5 mr-2" /> Send Notification
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors text-sm font-medium"
          >
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default SendBreaksModal;
